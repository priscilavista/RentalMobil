import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

function importComponent(path) {
  return () => import(`./components/${path}.vue`);
}

const router = new VueRouter({
  mode: "history",
  routes: [
    //homepage
    {
      path: "/homepage",
      name: "Homepage",
      meta: { title: "Homepage" },
      component: importComponent("Homepage"),
    },
    //Login
    {
      path: "/login",
      name: "Login",
      meta: { title: "Login" },
      component: importComponent("Login"),
    },
    {
      path: "/dashboard",
      component: importComponent("DashboardLayout"),
      children: [
        //Dashboard
        {
          path: "/dashboard",
          name: "Dashboard",
          meta: { title: "Dashboard" },
          component: importComponent("Dashboard"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil
        {
          path: "/mobil",
          name: "Mobil",
          meta: { title: "Mobil" },
          component: importComponent("DataMaster/Mobil"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil sub menu 1
        {
          path: "/mobil/perusahaan",
          name: "Mobil Perusahaan",
          meta: { title: "Mobil Perusahaan" },
          component: importComponent("DataMaster/Mobil/AsetPerusahaan"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil sub menu 2
        {
          path: "/mobil/mitra",
          name: "Mobil Mitra",
          meta: { title: "Mobil Mitra" },
          component: importComponent("DataMaster/Mobil/AsetMitra"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil sub menu 3
        {
          path: "/mobil/ketersediaan",
          name: "Ketersediaan Mobil",
          meta: { title: "Ketersediaan Mobil" },
          component: importComponent("DataMaster/Mobil/Ketersediaan"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil sub menu 4
        {
          path: "/mobil/kontrakAkanHabis",
          name: "Mobil Kontrak Akan Habis",
          meta: { title: "Mobil Kontrak Akan Habis" },
          component: importComponent("DataMaster/Mobil/KontrakAkanHabis"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil sub menu 5
        {
          path: "/mobil/kontrakHabis",
          name: "Mobil Kontrak Habis",
          meta: { title: "Mobil Kontrak Habis" },
          component: importComponent("DataMaster/Mobil/KontrakHabis"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mobil sub menu 6
        {
          path: "/mobil/history",
          name: "Mobil History",
          meta: { title: "Mobil History" },
          component: importComponent("DataMaster/Mobil/HistoryMobil"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Brosur
        {
          path: "/brosur",
          name: "Brosur",
          meta: { title: "Brosur" },
          component: importComponent("DataMaster/Brosur"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Mitra
        {
          path: "/mitra",
          name: "Mitra",
          meta: { title: "Mitra" },
          component: importComponent("DataMaster/Mitra"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu mitra 1
        {
          path: "/mitra/data",
          name: "Data Mitra",
          meta: { title: "Data Mitra" },
          component: importComponent("DataMaster/Mitra/DataMitra"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu mitra 2
        {
          path: "/mitra/history",
          name: "History Mitra",
          meta: { title: "History Mitra" },
          component: importComponent("DataMaster/Mitra/HistoryMitra"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Promo
        {
          path: "/promo",
          name: "Promo",
          meta: { title: "Promo" },
          component: importComponent("DataMaster/Promo"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu promo 1
        {
          path: "/promo/aktif",
          name: "Promo Aktif",
          meta: { title: "Promo Aktif" },
          component: importComponent("DataMaster/Promo/PromoAktif"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu promo 2
        {
          path: "/promo/kadaluwarsa",
          name: "Promo Kadaluwarsa",
          meta: { title: "Promo Kadaluwarsa" },
          component: importComponent("DataMaster/Promo/PromoKadaluwarsa"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu promo 3
        {
          path: "/promo/history",
          name: "History Promo",
          meta: { title: "History Promo" },
          component: importComponent("DataMaster/Promo/HistoryPromo"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Pegawai
        {
          path: "/pegawai",
          name: "Pegawai",
          meta: { title: "Pegawai" },
          component: importComponent("DataMaster/Pegawai"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Jadwal Pegawai
        {
          path: "/jadwalPegawai",
          name: "JadwalPegawai",
          meta: { title: "JadwalPegawai" },
          component: importComponent("DataMaster/JadwalPegawai"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Driver
        {
          path: "/driver",
          name: "Driver",
          meta: { title: "Driver" },
          component: importComponent("DataMaster/Driver"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Customer
        {
          path: "/customer",
          name: "Customer",
          meta: { title: "Customer" },
          component: importComponent("DataMaster/Customer"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        // Transaksi
        {
          path: "/transaksi",
          name: "Transaksi",
          meta: { title: "Transaksi" },
          component: importComponent("Transaksi"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu transaksi 1
        {
          path: "/transaksi/berlangsung",
          name: "Transaksi Berlangsung",
          meta: { title: "Transaksi Berlangsung" },
          component: importComponent("Transaksi/TransaksiBerlangsung"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
        //sub menu transaksi 2
        {
          path: "/transaksi/history",
          name: "History Transaksi",
          meta: { title: "History Transaksi" },
          component: importComponent("Transaksi/HistoryTransaksi"),
          beforeEnter(to, from, next) {
            if (localStorage.getItem("token")) next();
            else next({ name: "Login" });
          },
        },
      ],
    },
    {
      path: "*",
      redirect: "/homepage",
    },
  ],
});

export default router;
