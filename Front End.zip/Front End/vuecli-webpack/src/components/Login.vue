<template>
  <v-main class="banner">
    <v-btn
      text
      large
      @click="moveHomepage"
      style="float: left; margin: auto; margin-top: 60px; margin-left: 70px"
      ><v-icon large color="#ffffff">mdi-chevron-left-circle</v-icon></v-btn
    >
    <v-card
      shaped
      class="rounded-card"
      style="margin-top: 12%; margin-left: 23.5%"
      width="800"
      height="450"
    >
      <v-row no-gutters>
        <v-col
          style="
            background-color: #ffffff;
            border-radius: 5% 0% 0% 1%;
            margin-bottom: -9.2%;
          "
        >
          <v-img
            contain
            height="180"
            width="180"
            style="margin-top: 35%; margin-left: 26%"
            :src="image"
          ></v-img>
        </v-col>

        <v-col style="margin-top: 10%; margin-right: 1.5%; margin-left: 1%">
          <v-card-title><h2 style="margin-left: 37.5%">LOGIN</h2></v-card-title>

          <v-card-text>
            <v-form ref="form" lazy-validation>
              <v-text-field
                label="Email"
                type="email"
                v-model="email"
                :rules="emailRules"
                required
              >
              </v-text-field>
              <v-text-field
                label="Password"
                v-model="password"
                type="password"
                :rules="passwordRules"
                counter
                required
              ></v-text-field>
            </v-form>
          </v-card-text>

          <v-card-actions style="margin-right: 35%">
            <v-spacer></v-spacer>
            <v-btn
              style="padding: 7.5%"
              class="mt-6 blue white--text"
              depressed
              color="primary"
              @click="submit"
              >Login</v-btn
            >
          </v-card-actions>

          <v-overlay :value="overlay">
            <v-progress-circular indeterminate size="64"></v-progress-circular>
          </v-overlay>
        </v-col>
      </v-row>
    </v-card>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>{{
      error_message
    }}</v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Login",

  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Atma Jogja Rental";
      },
    },
  },

  data() {
    return {
      snackbar: false,
      error_message: "",
      color: "",
      password: "",
      passwordRules: [(v) => !!v || "Password is Required"],
      email: "",
      emailRules: [
        (v) => !!v || "Email is Required",
        (v) => /.+@.+\..+/.test(v) || "Email must be valid",
      ],
      image: require("@/assets/logoajr.jpg"),
      overlay: false,
    };
  },

  methods: {
    moveHomepage() {
      this.$router.push({ path: "/homepage" });
    },
    submit() {
      if (this.$refs.form.validate()) {
        this.overlay = true;
        this.$http
          .post(this.$api + "/login", {
            email: this.email,
            password: this.password,
          })
          .then((response) => {
            if (response.data.data.status_pegawai == true) {
              localStorage.setItem("id", response.data.data.id_pegawai);
              localStorage.setItem(
                "namaPegawai",
                response.data.data.nama_pegawai
              );
              localStorage.setItem("email", response.data.data.email_pegawai);
              localStorage.setItem("password", this.password);
              localStorage.setItem("token", response.data.access_token);
              localStorage.setItem("jabatan", response.data.data.id_role);

              this.error_message =
                response.data.message +
                ", Welcome " +
                response.data.data.jabatan +
                " " +
                response.data.data.nama_pegawai;
              this.color = "green";
              this.overlay = false;
              this.snackbar = true;
              setTimeout(() => this.$router.push({ path: "/dashboard" }), 350);
            } else {
              this.error_message = "Sorry Your Account Has Been Disabled!";
              this.color = "red";
              this.overlay = false;
              this.snackbar = true;
            }
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.overlay = false;
            this.snackbar = true;
            // localStorage.removeItem("token");
          });
      }
    },

    clear() {
      this.$refs.form.reset();
    },
  },
};
</script>

<style>
.rounded-card {
  border-radius: 20px;
}

.banner {
  background-color: #003366;
}
</style>
