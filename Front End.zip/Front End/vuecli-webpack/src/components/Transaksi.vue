<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 160px; max-width: 1500px"
  >
    <v-container style="max-width: 900px">
      <v-row>
        <v-col>
          <v-card class="mx-auto" max-width="384">
            <v-card-text>
              <div>Sub Menu Transaksi</div>
              <p class="text-h5 text--primary">Data Transaksi</p>
              <p>(data)</p>
              <div class="text--primary">
                Menyediakan data transaksi yang sedang berlangsung
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveDataTransaksi"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="384">
            <v-card-text>
              <div>Sub Menu Transaksi</div>
              <p class="text-h5 text--primary">History Transaksi</p>
              <p>(history)</p>
              <div class="text--primary">
                Menyediakan data transaksi yang sudah selesai
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveHistoryTransaksi"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-main>
</template>

<script>
export default {
  name: "Transaksi",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Transaksi";
      },
    },
  },
  data() {
    return {};
  },
  methods: {
    moveDataTransaksi() {
      this.$router.push({ path: "/transaksi/berlangsung" });
    },
    moveHistoryTransaksi() {
      this.$router.push({ path: "/transaksi/history" });
    },
  },
  mounted() {
    localStorage.setItem("menu", "Transaksi");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
  },
};
</script>

<style scoped></style>
