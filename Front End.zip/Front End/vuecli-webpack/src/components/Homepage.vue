<template>
  <v-main>
    <v-container style="max-width: 1300px">
      <v-row>
        <v-col lg="6" style="margin-top: 12.5%">
          <div style="position: fixed; max-width: 600px; margin-left: -3%">
            <img
              height="180"
              width="180"
              src="./../assets/logoajr.jpg"
              alt=""
              style="margin-bottom: 25px"
            />

            <h2 class="intro-text">Welcome to Atma Jogja Rental</h2>
            <p class="description">
              We as the best rental in town will always provide the best service
              to customers. We provide many cars and drivers with good
              conditions at affordable prices.
            </p>
            <v-btn
              color="success"
              class="white--text"
              rounded
              @click="dialog = true"
              >Register Customer</v-btn
            >
            <v-btn
              color="indigo"
              class="white--text"
              rounded
              style="margin-left: 25px"
              @click="moveLogin"
              >Login Staff</v-btn
            >
          </div>
        </v-col>
        <v-col lg="6">
          <div style="margin-left: 15%">
            <img width="100%" src="./../assets/cars.jpg" alt="" />
            <img width="100%" src="./../assets/cars2.jpg" alt="" />
            <img width="100%" src="./../assets/cars3.jpg" alt="" />
          </div>
        </v-col>
      </v-row>
    </v-container>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline" style="text-align: center"
            >{{ formTitle }} Data Customer</span
          >
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              :rules="namaRules"
              v-model="form.nama_customer"
              label="Nama"
            ></v-text-field>
            <v-text-field
              :rules="alamatRules"
              v-model="form.alamat_customer"
              label="Alamat"
            ></v-text-field>
            <v-text-field
              :rules="ttlRules"
              type="date"
              v-model="form.tanggal_lahir_customer"
              label="Tanggal Lahir"
            ></v-text-field>
            <v-select
              :rules="genderRules"
              v-model="form.jenis_kelamin_customer"
              item-text="gender"
              item-value="gender"
              :items="genders"
              label="Jenis Kelamin"
              required
            ></v-select>
            <v-text-field
              :rules="emailRules"
              v-model="form.email_customer"
              label="Email"
            ></v-text-field>
            <v-text-field
              :rules="telpRules"
              v-model="form.no_telp_customer"
              label="Nomor Telepon"
              type="number"
            ></v-text-field>
            <v-text-field
              :rules="ktpRules"
              v-model="form.no_ktp_customer"
              label="Nomor KTP"
              type="number"
            ></v-text-field>
            <span class="mt-5" style="font-weight: bold">Dokumen Pendukung</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.dokumen_pendukung)"
              v-on:change="onImageChange"
              label="Image Input"
            />
            <span v-if="this.form.dokumen_pendukung != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.dokumen_pendukung"
              ></v-img> </span
            ><br /><br />
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="save">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom>{{
      error_message
    }}</v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Homepage",

  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Atma Jogja Rental";
      },
    },
  },

  data() {
    return {
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      dialog: false,
      image: require("@/assets/logoajr.jpg"),
      overlay: false,
      customer: new FormData(),
      form: {
        id_customer: null,
        nama_customer: null,
        alamat_customer: null,
        tanggal_lahir_customer: null,
        jenis_kelamin_customer: null,
        email_customer: null,
        no_telp_customer: null,
        no_ktp_customer: null,
        dokumen_pendukung: null,
      },
      genders: [{ gender: "Laki-laki" }, { gender: "Perempuan" }],
      namaRules: [(v) => !!v || "Nama is Required"],
      alamatRules: [(v) => !!v || "Alamat is Required"],
      ttlRules: [(v) => !!v || "Tanggal Lahir is Required"],
      genderRules: [(v) => !!v || "Jenis Kelamin is Required"],
      emailRules: [
        (v) => !!v || "Email is Required",
        (v) => /.+@.+\..+/.test(v) || "Email must be valid",
      ],
      telpRules: [
        (v) => !!v || "Nomor Telepon is Required",
        (v) => /^([0][8][0-9]{8,10})$/g.test(v) || "Phone Number must be valid",
      ],
      ktpRules: [
        (v) => !!v || "Nomor KTP is Required",
        (v) => /^([0-9]{16})$/g.test(v) || "Nomor KTP must be valid",
      ],
    };
  },

  methods: {
    moveLogin() {
      this.$router.push({ path: "/login" });
    },
    save() {
      this.customer.append("nama_customer", this.form.nama_customer);
      this.customer.append("alamat_customer", this.form.alamat_customer);
      this.customer.append(
        "tanggal_lahir_customer",
        this.form.tanggal_lahir_customer
      );
      this.customer.append(
        "jenis_kelamin_customer",
        this.form.jenis_kelamin_customer
      );
      this.customer.append("email_customer", this.form.email_customer);
      this.customer.append("no_telp_customer", this.form.no_telp_customer);
      this.customer.append("no_ktp_customer", this.form.no_ktp_customer);
      if (this.form.dokumen_pendukung != null) {
        this.customer.append("dokumen_pendukung", this.form.dokumen_pendukung);
      }

      var url = this.$api + "/customer/";
      this.load = true;
      this.$http
        .post(url, this.customer, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.updateTemp();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    updateTemp() {
      var url = this.$api + "/customerTemp";
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    onImageChange(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage(files[0]);
    },

    createImage(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.dokumen_pendukung = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    close() {
      this.resetForm();
      this.dialog = false;
    },
    cancel() {
      this.resetForm();
      this.dialog = false;
    },
    resetForm() {
      this.form = {
        id_customer: null,
        nama_customer: null,
        alamat_customer: null,
        tanggal_lahir_customer: null,
        jenis_kelamin_customer: null,
        email_customer: null,
        no_telp_customer: null,
        no_ktp_customer: null,
        dokumen_pendukung: null,
      };
    },
  },
};
</script>

<style>
.rounded-card {
  border-radius: 20px;
}

.banner {
  background-color: #003366;
}

.intro-text {
  font-size: 30px;
  font-weight: 800;
}
.description {
  font-size: 17px;
  margin: 20px 0px;
}
</style>
