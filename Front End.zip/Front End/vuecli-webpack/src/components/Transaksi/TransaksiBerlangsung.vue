<template>
  <v-main class="list" style="margin: auto; margin-top: 40px">
    <v-btn
      text
      large
      @click="moveTransaksi"
      style="float: left; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <v-btn
      color="success"
      dark
      large
      @click="moveKetersediaan"
      style="float: left; margin-left: 30px"
      >Ketersediaan Mobil</v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Data Transaksi Berlangsung</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>

        <v-btn
          color="success"
          dark
          @click="dialog = true"
          style="margin-right: 48px; margin-top: 20px"
          >Add Transaksi</v-btn
        >
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="transaksisB"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn
            v-if="item.verif_transaksi == false"
            small
            @click="verifTransaksi(item)"
            >verif transaksi</v-btn
          >
          <v-menu v-else offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandler(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="imageHandler(item)"
                      ><v-icon color="#E39348"
                        >mdi-credit-card-outline</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title
                    v-if="item.tanggal_pengembalian_mobil == null"
                    style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="pengembalianHandler(item)"
                      ><v-icon color="#2E7D32"
                        >mdi-garage-open-variant</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title
                    v-if="item.bukti_pembayaran != null"
                    style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="verifHandler(item)"
                      ><v-icon color="#2E7D32">mdi-cash-check</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="printHandler(item)"
                      ><v-icon color="#4B4B4B"
                        >mdi-printer-outline</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogRead"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <!-- <v-card-title style="float: none">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </v-card-title> -->
        <div mt="3">
          <p class="headline" style="text-align: center">Data Transaksi</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              label="ID Transaksi"
              v-model="form.id_transaksi"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_transaksi"
              label="Tanggal Transaksi"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_pegawai"
              label="Pegawai"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_customer"
              label="Customer"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_mobil"
              label="Mobil"
            ></v-text-field>
            <span v-if="form.id_driver != null">
              <v-text-field
                disabled
                v-model="form.nama_driver"
                label="Driver"
              ></v-text-field>
            </span>
            <span v-else>
              <v-text-field
                disabled
                v-model="blank"
                label="Driver"
              ></v-text-field>
            </span>
            <v-text-field
              disabled
              v-model="form.tanggal_mulai_sewa"
              label="Tanggal Mulai Sewa"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_selesai_sewa"
              label="Tanggal Selesai Sewa"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_pengembalian_mobil"
              label="Tanggal Pengembalian Mobil"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.durasi_sewa"
              label="Durasi Sewa"
            ></v-text-field>
            <span v-if="form.id_promo != null">
              <v-text-field
                disabled
                v-model="form.kode_promo"
                label="Kode Promo"
              ></v-text-field>
              <v-text-field
                disabled
                v-model="form.diskon_promo"
                label="Diskon Promo"
              ></v-text-field>
            </span>
            <span v-else>
              <v-text-field
                disabled
                v-model="blank"
                label="Kode Promo"
              ></v-text-field>
              <v-text-field
                disabled
                v-model="form.blank"
                label="Diskon Promo"
              ></v-text-field>
            </span>
            <v-text-field
              disabled
              v-model="form.subtotal_mobil"
              label="Total Biaya Mobil"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.subtotal_driver"
              label="Total Biaya Driver"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.denda_sewa"
              label="Denda Sewa"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.total_transaksi"
              label="Total Transaksi"
            ></v-text-field>
            <span class="mt-5" style="font-weight: bold">Bukti Pembayaran</span
            ><br />
            <span v-if="this.form.bukti_pembayaran != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.bukti_pembayaran"
              ></v-img>
              <br /><br
            /></span>
            <span v-if="form.status_pembayaran == 0">
              <v-text-field
                disabled
                v-model="belumLunas"
                label="Status Pembayaran"
              ></v-text-field>
            </span>
            <span v-else>
              <v-text-field
                disabled
                v-model="lunas"
                label="Status Pembayaran"
              ></v-text-field>
            </span>
            <span v-if="form.id_driver != null">
              <v-text-field
                disabled
                v-model="form.rating_driver"
                label="Rating Driver"
              ></v-text-field>
            </span>
            <span v-else>
              <v-text-field
                disabled
                v-model="blank"
                label="Rating Driver"
              ></v-text-field>
            </span>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline" style="text-align: center"
            >{{ formTitle }} Data Transaksi</span
          >
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              :rules="mulaiSewaRules"
              type="date"
              v-model="form.tanggal_mulai_sewa"
              label="Tanggal Mulai Sewa"
            ></v-text-field>
            <v-text-field
              :rules="waktuMulaiRules"
              type="time"
              v-model="form.waktu_mulai_sewa"
              label="Waktu Mulai Sewa"
            ></v-text-field>
            <v-text-field
              :rules="selesaiSewaRules"
              type="date"
              v-model="form.tanggal_selesai_sewa"
              label="Tanggal Selesai Sewa"
            ></v-text-field>
            <v-text-field
              :rules="waktuSelesaiRules"
              type="time"
              v-model="form.waktu_selesai_sewa"
              label="Waktu Selesai Sewa"
            ></v-text-field>
            <v-select
              :rules="pegawaiRules"
              v-model="form.temp_pegawai"
              :items="pegawai"
              label="Pegawai"
              required
            ></v-select>
            <v-select
              :rules="customerRules"
              v-model="form.temp_customer"
              :items="customer"
              label="Customer"
              required
            ></v-select>
            <v-select
              :rules="mobilRules"
              v-model="form.temp_mobil"
              :items="mobil"
              label="Mobil"
              required
            ></v-select>
            <v-select
              :rules="driverRules"
              v-model="form.temp_driver"
              :items="driver"
              label="Driver"
              required
            ></v-select>
            <v-select
              :rules="promoRules"
              v-model="form.kode_promo"
              :items="promo"
              label="Promo"
              required
            ></v-select>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="save">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogImage" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">Upload Bukti Pembayaran</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <span class="mt-5" style="font-weight: bold">Bukti Pembayaran</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.bukti_pembayaran)"
              v-on:change="onImageChange"
              label="Image Input"
            />
            <span v-if="this.form.bukti_pembayaran != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.bukti_pembayaran"
              ></v-img> </span
            ><br /><br />
          </v-container>
          <v-card-action>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" text @click="image">Upload</v-btn>
            <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
            <v-spacer></v-spacer>
          </v-card-action>
        </v-card-text>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogPrint" persistent max-width="800px">
      <v-card style="overflow-x: hidden">
        <span id="Receipt" class="mt-3">
          <v-card-title style="font-weight: bold"
            >Nota Transaksi Sewa Mobil</v-card-title
          >
          <v-card-text>
            <div style="border: solid 2px black">
              <table
                style="width: 88%; margin-left: 6%; border-collapse: collapse"
                class="black--text"
              >
                <thead>
                  <tr>
                    <th colspan="4" class="text-center">Atma Rental</th>
                  </tr>
                </thead>
                <thead style="border-bottom: 1px black solid">
                  <tr>
                    <td colspan="2" class="text-left">
                      {{ this.form.id_transaksi }}
                    </td>
                    <td colspan="2" class="text-right">
                      {{ this.form.tanggal_transaksi }}
                    </td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="text-left">Cust</td>
                    <td class="text-left">
                      {{ this.form.nama_customer }}
                    </td>
                    <td class="text-left">PRO:</td>
                    <td class="text-left">
                      {{ this.form.kode_promo }}
                    </td>
                  </tr>
                  <tr>
                    <td class="text-left">CS</td>
                    <td class="text-left">
                      {{ this.form.nama_pegawai }}
                    </td>
                  </tr>
                  <tr>
                    <td class="text-left">DRV</td>
                    <td class="text-left">
                      {{ this.form.nama_driver }}
                    </td>
                  </tr>
                </tbody>
                <thead style="border-top: 2px black solid">
                  <tr>
                    <th colspan="4" class="text-center">Nota Transaksi</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td class="text-left">Tgl Mulai</td>
                    <td class="text-left">
                      {{ this.form.tanggal_mulai_sewa }}
                    </td>
                  </tr>
                  <tr>
                    <td class="text-left">Tgl Selesai</td>
                    <td class="text-left">
                      {{ this.form.tanggal_selesai_sewa }}
                    </td>
                  </tr>
                  <tr>
                    <td class="text-left">Tgl Pengembalian</td>
                    <td class="text-left">
                      {{ this.form.tanggal_pengembalian_mobil }}
                    </td>
                  </tr>
                </tbody>
                <thead
                  style="
                    border-bottom: 1px black solid;
                    border-top: 1px black solid;
                  "
                >
                  <tr>
                    <th class="text-left">Item</th>
                    <th class="text-left">Satuan</th>
                    <th class="text-left">Durasi</th>
                    <th class="text-left">Sub Total</th>
                  </tr>
                </thead>
                <tbody style="border-bottom: 1px black solid">
                  <tr>
                    <td class="text-left">{{ this.form.nama_mobil }}</td>
                    <td class="text-left">{{ this.form.harga_sewa_mobil }}</td>
                    <td class="text-left">{{ this.form.durasi_sewa }}</td>
                    <td class="text-left">{{ this.form.subtotal_mobil }}</td>
                  </tr>
                  <tr>
                    <td v-if="this.form.nama_driver != null" class="text-left">
                      Driver {{ this.form.nama_driver }}
                    </td>
                    <td v-else>{{ this.kosong }}</td>
                    <td class="text-left">{{ this.form.tarif_driver }}</td>
                    <td v-if="this.form.nama_driver != null" class="text-left">
                      {{ this.form.durasi_sewa }}
                    </td>
                    <td v-else>{{ this.kosong }}</td>
                    <td class="text-left">{{ this.form.subtotal_driver }}</td>
                  </tr>
                  <tr>
                    <td colspan="3"></td>
                    <th class="text-left">
                      {{ this.form.subtotal }}
                    </th>
                  </tr>
                </tbody>
                <tbody>
                  <tr>
                    <td class="text-left">Cust</td>
                    <td class="text-left">CS</td>
                    <td class="text-left">Disc</td>
                    <td class="text-left">
                      {{ this.form.diskon }}
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2"></td>
                    <td class="text-left">Denda</td>
                    <td class="text-left">
                      {{ this.form.denda_sewa }}
                    </td>
                  </tr>
                  <tr>
                    <td colspan="2"></td>
                    <td class="text-left">Total</td>
                    <th class="text-left">
                      {{ this.form.total_transaksi }}
                    </th>
                  </tr>
                  <tr>
                    <td class="text-left">
                      {{ this.form.nama_customer }}
                    </td>
                    <td class="text-left">
                      {{ this.form.nama_pegawai }}
                    </td>
                    <td colspan="2"></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </v-card-text>
        </span>
      </v-card>
      <v-card>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="exportPDF">Print</v-btn>
          <v-btn color="blue darken-1" text @click="close">Close</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Apakah transaksi ini sudah terbayar? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="verifPembayaran"
            >Verif</v-btn
          >
          <v-btn color="blue darken-1" text @click="dialogConfirm = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirmMobil" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Apakah mobil sudah dikembalikan? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="pengembalianMobil"
            >Sudah</v-btn
          >
          <v-btn color="blue darken-1" text @click="dialogConfirmMobil = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
import html2PDF from "jspdf-html2canvas";
export default {
  name: "Transaksi",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Transaksi";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      blank: "-",
      kosong: null,
      lunas: "Terbayar",
      belumLunas: "Belum Terbayar",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogConfirm: false,
      dialogConfirmMobil: false,
      dialogRead: false,
      dialogImage: false,
      dialogPrint: false,
      temp: 0,
      headers: [
        {
          text: "ID Transaksi",
          align: "start",
          sortable: true,
          value: "id_transaksi",
        },
        { text: "Tanggal Transaksi", value: "tanggal_transaksi" },
        { text: "Durasi Sewa", value: "durasi_sewa" },
        { text: "Total Biaya Mobil", value: "subtotal_mobil" },
        { text: "Total Biaya Driver", value: "subtotal_driver" },
        { text: "Denda Sewa", value: "denda_sewa" },
        { text: "Total Transaksi", value: "total_transaksi" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      transaksi: new FormData(),
      transaksisB: [],
      form: {
        id_transaksi: null,
        id_promo: null,
        id_customer: null,
        id_pegawai: null,
        id_driver: null,
        id_mobil: null,
        kode_promo: null,
        temp_customer: null,
        temp_pegawai: null,
        temp_driver: null,
        temp_mobil: null,
        nama_customer: null,
        nama_pegawai: null,
        nama_driver: null,
        nama_mobil: null,
        diskon_promo: null,
        tanggal_transaksi: null,
        tanggal_mulai_sewa: null,
        waktu_mulai_sewa: null,
        tanggal_selesai_sewa: null,
        waktu_selesai_sewa: null,
        tanggal_pengembalian_mobil: null,
        durasi_sewa: null,
        subtotal_driver: null,
        subtotal_mobil: null,
        denda_sewa: null,
        total_transaksi: null,
        bukti_pembayaran: null,
        status_pembayaran: null,
        rating_driver: null,
        harga_sewa_mobil: null,
        tarif_driver: null,
        diskon: null,
        subtotal: null,
      },
      form_promo: {
        id_promo: null,
        kode_promo: null,
      },
      promo: [],
      form_pegawai: {
        id_pegawai: null,
        temp_pegawai: null,
      },
      pegawai: [],
      form_customer: {
        id_customer: null,
        temp_customer: null,
      },
      customer: [],
      form_mobil: {
        id_mobil: null,
        temp_mobil: null,
      },
      mobil: [],
      form_driver: {
        id_driver: null,
        temp_driver: null,
      },
      driver: [],
      deleteId: "",
      editId: "",
      // image: require("@/assets/car.png"),
      pegawaiRules: [(v) => !!v || "Pegawai is Required"],
      customerRules: [(v) => !!v || "Customer is Required"],
      mobilRules: [(v) => !!v || "Mobil is Required"],
      mulaiSewaRules: [(v) => !!v || "Tanggal Mulai Sewa is Required"],
      selesaiSewaRules: [(v) => !!v || "Tanggal Selesai Sewa is Required"],
      waktuMulaiRules: [(v) => !!v || "Waktu Mulai Sewa is Required"],
      waktuSelesaiRules: [(v) => !!v || "Waktu Selesai Sewa is Required"],
    };
  },
  methods: {
    moveKetersediaan() {
      this.$router.push({ path: "/mobil/ketersediaan" });
    },
    moveTransaksi() {
      this.$router.push({ path: "/transaksi" });
    },
    verifHandler(item) {
      this.editId = item.id_transaksi;
      this.dialogConfirm = true;
    },
    pengembalianHandler(item) {
      this.editId = item.id_transaksi;
      this.dialogConfirmMobil = true;
    },
    refreshPage() {
      if (localStorage.getItem("reloaded")) {
        // The page was just reloaded. Clear the value from local storage
        // so that it will reload the next time this page is visited.
        localStorage.removeItem("reloaded");
      } else {
        // Set a flag so that we know not to reload the page twice.
        localStorage.setItem("reloaded", "1");
        location.reload();
      }
    },
    readPromo() {
      var url = this.$api + "/promoAktif";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_promo.id_promo = temp.map((v) => v.id_promo);
        this.form_promo.kode_promo = temp.map((v) => v.kode_promo);
        for (let i = 0; i < this.form_promo.kode_promo.length; i++) {
          this.promo.push(this.form_promo.kode_promo[i]);
        }
      });
    },
    readPegawai() {
      var url = this.$api + "/pegawaiRead";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_pegawai.id_pegawai = temp.map((v) => v.id_pegawai);
        this.form_pegawai.temp_pegawai = temp.map((v) => v.temp_pegawai);
        for (let i = 0; i < this.form_pegawai.temp_pegawai.length; i++) {
          this.pegawai.push(this.form_pegawai.temp_pegawai[i]);
        }
      });
    },
    readCustomer() {
      var url = this.$api + "/customer";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_customer.id_customer = temp.map((v) => v.id_customer);
        this.form_customer.temp_customer = temp.map((v) => v.temp_customer);
        for (let i = 0; i < this.form_customer.temp_customer.length; i++) {
          this.customer.push(this.form_customer.temp_customer[i]);
        }
      });
    },
    readMobil() {
      var url = this.$api + "/mobil";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_mobil.id_mobil = temp.map((v) => v.id_mobil);
        this.form_mobil.temp_mobil = temp.map((v) => v.temp_mobil);
        for (let i = 0; i < this.form_mobil.temp_mobil.length; i++) {
          this.mobil.push(this.form_mobil.temp_mobil[i]);
        }
      });
    },
    readDriver() {
      var url = this.$api + "/driverRead";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_driver.id_driver = temp.map((v) => v.id_driver);
        this.form_driver.temp_driver = temp.map((v) => v.temp_driver);
        for (let i = 0; i < this.form_driver.temp_driver.length; i++) {
          this.driver.push(this.form_driver.temp_driver[i]);
        }
      });
    },
    //read data mitra
    readDataBerlangsung() {
      var url = this.$api + "/transaksiBerlangsung";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.transaksisB = response.data.data;
        });
    },
    save() {
      var tanggalMulai =
        this.form.tanggal_mulai_sewa + " " + this.form.waktu_mulai_sewa;
      this.transaksi.append("tanggal_mulai_sewa", tanggalMulai);
      var tanggalSelesai =
        this.form.tanggal_selesai_sewa + " " + this.form.waktu_selesai_sewa;
      this.transaksi.append("tanggal_selesai_sewa", tanggalSelesai);
      this.transaksi.append("temp_pegawai", this.form.temp_pegawai);
      this.transaksi.append("temp_customer", this.form.temp_customer);
      this.transaksi.append("temp_mobil", this.form.temp_mobil);
      if (this.form.temp_driver != null) {
        this.transaksi.append("temp_driver", this.form.temp_driver);
      }

      if (this.form.kode_promo != null) {
        this.transaksi.append("kode_promo", this.form.kode_promo);
      }

      var url = this.$api + "/transaksi/";
      this.load = true;
      this.$http
        .post(url, this.transaksi, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.readData();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    verifTransaksi(item) {
      var url = this.$api + "/transaksiVerifTransaksi/" + item.id_transaksi;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.readData();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    verifPembayaran() {
      var url = this.$api + "/transaksiVerifPembayaran/" + this.editId;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.readData();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    pengembalianMobil() {
      var url = this.$api + "/transaksiPengembalianMobil/" + this.editId;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.readData();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          console.log(error.response.data.message);
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    image() {
      let newData = {
        bukti_pembayaran: this.form.bukti_pembayaran,
      };

      var url = this.$api + "/transaksiImage/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    onImageChange(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage(files[0]);
    },

    createImage(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.bukti_pembayaran = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    readHandler(item) {
      this.form.id_transaksi = item.id_transaksi;
      this.form.id_promo = item.id_promo;
      this.form.id_customer = item.id_customer;
      this.form.id_pegawai = item.id_pegawai;
      this.form.id_driver = item.id_driver;
      this.form.id_mobil = item.id_mobil;
      this.form.kode_promo = item.kode_promo;
      this.form.temp_customer = item.temp_customer;
      this.form.temp_pegawai = item.temp_pegawai;
      this.form.temp_driver = item.temp_driver;
      this.form.temp_mobil = item.temp_mobil;
      this.form.nama_customer = item.nama_customer;
      this.form.nama_pegawai = item.nama_pegawai;
      this.form.nama_driver = item.nama_driver;
      this.form.nama_mobil = item.nama_mobil;
      this.form.diskon_promo = item.diskon_promo;
      this.form.tanggal_transaksi = item.tanggal_transaksi;
      this.form.tanggal_mulai_sewa = item.tanggal_mulai_sewa;
      this.form.tanggal_selesai_sewa = item.tanggal_selesai_sewa;
      this.form.tanggal_pengembalian_mobil = item.tanggal_pengembalian_mobil;
      this.form.durasi_sewa = item.durasi_sewa;
      this.form.subtotal_driver = item.subtotal_driver;
      this.form.subtotal_mobil = item.subtotal_mobil;
      this.form.denda_sewa = item.denda_sewa;
      this.form.total_transaksi = item.total_transaksi;
      this.form.bukti_pembayaran = item.bukti_pembayaran;
      this.form.status_pembayaran = item.status_pembayaran;
      this.form.rating_driver = item.rating_driver;
      this.dialogRead = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    imageHandler(item) {
      this.editId = item.id_transaksi;
      this.form.bukti_pembayaran = item.bukti_pembayaran;
      this.dialogImage = true;
    },
    printHandler(item) {
      this.form.id_transaksi = item.id_transaksi;
      this.form.id_promo = item.id_promo;
      this.form.id_customer = item.id_customer;
      this.form.id_pegawai = item.id_pegawai;
      this.form.id_driver = item.id_driver;
      this.form.id_mobil = item.id_mobil;
      this.form.kode_promo = item.kode_promo;
      this.form.temp_customer = item.temp_customer;
      this.form.temp_pegawai = item.temp_pegawai;
      this.form.temp_driver = item.temp_driver;
      this.form.temp_mobil = item.temp_mobil;
      this.form.nama_customer = item.nama_customer;
      this.form.nama_pegawai = item.nama_pegawai;
      this.form.nama_driver = item.nama_driver;
      this.form.nama_mobil = item.nama_mobil;
      this.form.diskon_promo = item.diskon_promo;
      this.form.tanggal_transaksi = item.tanggal_transaksi;
      this.form.tanggal_mulai_sewa = item.tanggal_mulai_sewa;
      this.form.tanggal_selesai_sewa = item.tanggal_selesai_sewa;
      this.form.tanggal_pengembalian_mobil = item.tanggal_pengembalian_mobil;
      this.form.durasi_sewa = item.durasi_sewa;
      this.form.subtotal_driver = item.subtotal_driver;
      this.form.subtotal_mobil = item.subtotal_mobil;
      this.form.denda_sewa = item.denda_sewa;
      this.form.total_transaksi = item.total_transaksi;
      this.form.bukti_pembayaran = item.bukti_pembayaran;
      this.form.status_pembayaran = item.status_pembayaran;
      this.form.rating_driver = item.rating_driver;
      this.form.harga_sewa_mobil = item.harga_sewa_mobil;
      this.form.tarif_driver = item.tarif_driver;
      this.form.diskon = item.diskon;
      this.form.subtotal = item.subtotal;
      this.dialogPrint = true;
    },
    close() {
      this.dialog = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogConfirmMobil = false;
      this.dialogRead = false;
      this.dialogImage = false;
      this.dialogPrint = false;
      this.resetForm();
      this.readDataBerlangsung();
    },
    cancel() {
      this.resetForm();
      this.readDataBerlangsung();
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogConfirmMobil = false;
      this.dialogImage = false;
      this.dialogRead = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_transaksi: null,
        id_promo: null,
        id_customer: null,
        id_pegawai: null,
        id_driver: null,
        id_mobil: null,
        kode_promo: null,
        temp_customer: null,
        temp_pegawai: null,
        temp_driver: null,
        temp_mobil: null,
        nama_customer: null,
        nama_pegawai: null,
        nama_driver: null,
        nama_mobil: null,
        diskon_promo: null,
        tanggal_transaksi: null,
        tanggal_mulai_sewa: null,
        waktu_mulai_sewa: null,
        tanggal_selesai_sewa: null,
        waktu_selesai_sewa: null,
        tanggal_pengembalian_mobil: null,
        durasi_sewa: null,
        subtotal_driver: null,
        subtotal_mobil: null,
        denda_sewa: null,
        total_transaksi: null,
        bukti_pembayaran: null,
        status_pembayaran: null,
        rating_driver: null,
        harga_sewa_mobil: null,
        tarif_driver: null,
        diskon: null,
        subtotal: null,
      };
    },

    exportPDF() {
      var report;
      var reportName = "";

      report = document.getElementById("Receipt");
      reportName = "Receipt_" + this.form.id_transaksi;

      html2PDF(report, {
        jsPDF: {
          format: "a4",
        },
        margin: {
          top: 0,
          right: 0,
          bottom: 0,
          left: -2.5,
        },
        html2canvas: {
          scrollX: 0,
          scrollY: 0,
        },

        imageType: "image/jpeg",
        output: reportName + ".pdf",
      });

      this.close();
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Transaksi");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readDataBerlangsung();
    this.readPromo();
    this.readPegawai();
    this.readCustomer();
    this.readMobil();
    this.readDriver();
  },
};
</script>

<style scoped></style>
