<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 160px; max-width: 1500px"
  >
    <v-container style="max-width: 900px">
      <v-row>
        <v-col>
          <v-card class="mx-auto" max-width="384">
            <v-card-text>
              <div>Sub Menu Mitra</div>
              <p class="text-h5 text--primary">Data Mitra</p>
              <p>(data)</p>
              <div class="text--primary">Menyediakan data mitra</div>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="deep-purple accent-4" @click="moveDataMitra">
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="384">
            <v-card-text>
              <div>Sub Menu Mitra</div>
              <p class="text-h5 text--primary">History Mitra</p>
              <p>(history)</p>
              <div class="text--primary">
                Menyediakan data mitra yang sudah dihapus
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveHistoryMitra"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-main>
</template>

<script>
export default {
  name: "Mitra",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Mitra";
      },
    },
  },
  data() {
    return {};
  },
  methods: {
    moveDataMitra() {
      this.$router.push({ path: "/mitra/data" });
    },
    moveHistoryMitra() {
      this.$router.push({ path: "/mitra/history" });
    },
  },
  mounted() {
    localStorage.setItem("menu", "Mitra");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
  },
};
</script>

<style scoped></style>
