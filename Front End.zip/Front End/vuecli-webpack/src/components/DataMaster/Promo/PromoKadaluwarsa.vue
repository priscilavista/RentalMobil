<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-btn
      text
      large
      @click="movePromo"
      style="float: left; margin-left: -30px; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Data Promo Kadaluwarsa</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="promosR"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-menu offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandler(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="editHandler(item)"
                      ><v-icon color="#E39348">mdi-pencil</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="deleteHandler(item.id_promo)"
                      ><v-icon color="#C94141"
                        >mdi-account-remove</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogRead"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <div mt="3">
          <p class="headline" style="text-align: center">Data Promo</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              label="ID"
              v-model="form.id_promo"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.kode_promo"
              label="Kode"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.jenis_promo"
              label="Jenis"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.keterangan_promo"
              label="Keterangan"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_mulai_berlaku"
              label="Tanggal Mulai Berlaku"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_terakhir_berlaku"
              label="Tanggal Terakhir Berlaku"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">{{ formTitle }} Data Promo</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              :rules="kodeRules"
              v-model="form.kode_promo"
              label="Kode"
            ></v-text-field>
            <v-text-field
              :rules="jenisRules"
              v-model="form.jenis_promo"
              label="Jenis"
            ></v-text-field>
            <v-text-field
              :rules="keteranganRules"
              v-model="form.keterangan_promo"
              label="Keterangan"
            ></v-text-field>
            <v-text-field
              :rules="mulaiRules"
              type="date"
              v-model="form.tanggal_mulai_berlaku"
              label="Tanggal Mulai Berlaku"
            ></v-text-field>
            <v-text-field
              :rules="akhirRules"
              type="date"
              v-model="form.tanggal_terakhir_berlaku"
              label="Tanggal Terakhir Berlaku"
            ></v-text-field>
            <v-text-field
              :rules="diskonRules"
              v-model="form.diskon_promo"
              label="Diskon Promo"
              type="number"
              suffix="%"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Anda Yakin ingin menghapus data ini? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="deleteData">Delete</v-btn>
          <v-btn color="blue darken-1" text @click="dialogConfirm = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Promo",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Promo";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogConfirm: false,
      dialogRead: false,
      temp: 0,
      headers: [
        {
          text: "Kode",
          align: "start",
          sortable: true,
          value: "kode_promo",
        },
        { text: "Jenis", value: "jenis_promo" },
        { text: "Keterangan", value: "keterangan_promo" },
        { text: "Tanggal Mulai Berlaku", value: "tanggal_mulai_berlaku" },
        { text: "Tanggal Terakhir Berlaku", value: "tanggal_terakhir_berlaku" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      promo: new FormData(),
      promosR: [],
      form: {
        id_promo: null,
        kode_promo: null,
        jenis_promo: null,
        keterangan_promo: null,
        tanggal_mulai_berlaku: null,
        tanggal_terakhir_berlaku: null,
      },
      deleteId: "",
      editId: "",
      kodeRules: [(v) => !!v || "Kode is Required"],
      jenisRules: [(v) => !!v || "Jenis is Required"],
      keteranganRules: [(v) => !!v || "Keterangan is Required"],
      mulaiRules: [(v) => !!v || "Tanggal Mulai is Required"],
      akhirRules: [(v) => !!v || "Tanggal Terakhir is Required"],
      diskonRules: [(v) => !!v || "Diskon is Required"],
    };
  },
  methods: {
    movePromo() {
      this.$router.push({ path: "/promo" });
    },
    setForm() {
      if (this.inputType !== "Tambah") {
        this.update();
      } else {
        this.save();
      }
    },
    readDataKadaluwarsa() {
      var url = this.$api + "/promoKadaluwarsa";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.promosR = response.data.data;
        });
    },
    //ubah data mitra
    update() {
      let newData = {
        kode_promo: this.form.kode_promo,
        jenis_promo: this.form.jenis_promo,
        keterangan_promo: this.form.keterangan_promo,
        tanggal_mulai_berlaku: this.form.tanggal_mulai_berlaku,
        tanggal_terakhir_berlaku: this.form.tanggal_terakhir_berlaku,
        diskon_promo: this.form.diskon_promo,
      };

      var url = this.$api + "/promo/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataKadaluwarsa();
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //menghapus data
      var url = this.$api + "/promoDelete/" + this.deleteId;
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataKadaluwarsa();
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Edit";
      this.editId = item.id_promo;
      this.form.kode_promo = item.kode_promo;
      this.form.jenis_promo = item.jenis_promo;
      this.form.keterangan_promo = item.keterangan_promo;
      this.form.tanggal_mulai_berlaku = item.tanggal_mulai_berlaku;
      this.form.tanggal_terakhir_berlaku = item.tanggal_terakhir_berlaku;
      this.form.diskon_promo = item.diskon_promo;
      this.dialog = true;
    },
    readHandler(item) {
      this.form.id_promo = item.id_promo;
      this.form.kode_promo = item.kode_promo;
      this.form.jenis_promo = item.jenis_promo;
      this.form.keterangan_promo = item.keterangan_promo;
      this.form.tanggal_mulai_berlaku = item.tanggal_mulai_berlaku;
      this.form.tanggal_terakhir_berlaku = item.tanggal_terakhir_berlaku;
      this.dialogRead = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.readDataKadaluwarsa();
    },
    cancel() {
      this.resetForm();
      this.readDataKadaluwarsa();
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_promo: null,
        kode_promo: null,
        jenis_promo: null,
        keterangan_promo: null,
        tanggal_mulai_berlaku: null,
        tanggal_terakhir_berlaku: null,
        diskon_promo: null,
      };
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Promo");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readDataKadaluwarsa();
  },
};
</script>

<style scoped></style>
