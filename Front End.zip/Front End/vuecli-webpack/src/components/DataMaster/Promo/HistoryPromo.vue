<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-btn
      text
      large
      @click="movePromo"
      style="float: left; margin-left: -30px; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Deleted Data Promo</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="promosD"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn small class="mr-2" @click="recoverData(item)">Recover</v-btn>
        </template>
      </v-data-table>
    </v-card>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Promo",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Promo";
      },
    },
  },
  data() {
    return {
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      temp: 0,
      headers: [
        {
          text: "Kode",
          align: "start",
          sortable: true,
          value: "kode_promo",
        },
        { text: "Jenis", value: "jenis_promo" },
        { text: "Keterangan", value: "keterangan_promo" },
        { text: "Tanggal Mulai Berlaku", value: "tanggal_mulai_berlaku" },
        { text: "Tanggal Terakhir Berlaku", value: "tanggal_terakhir_berlaku" },
        { text: "Actions", value: "actions" },
      ],
      promosD: [],
    };
  },
  methods: {
    movePromo() {
      this.$router.push({ path: "/promo" });
    },
    readDataRemove() {
      var url = this.$api + "/promoRemove";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.promosD = response.data.data;
        });
    },
    recoverData(item) {
      var url = this.$api + "/promoRecover/" + item.id_promo;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.close();
          this.readDataRemove();
        });
    },
    close() {
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.readDataRemove();
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Promo");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readDataRemove();
  },
};
</script>

<style scoped></style>
