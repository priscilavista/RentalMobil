<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-btn
      text
      large
      @click="moveMobil"
      style="float: left; margin-left: -30px; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Data Mobil Habis Kontrak</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="mobilsR"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-menu offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandlerM(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="editHandler(item)"
                      ><v-icon color="#E39348">mdi-pencil</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="deleteHandler(item.id_mobil)"
                      ><v-icon color="#C94141"
                        >mdi-account-remove</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogReadM"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <div mt="3">
          <p class="headline" style="text-align: center">Data Mobil</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              v-model="form.kategori_aset_mobil"
              label="Kategori Aset"
            ></v-text-field>
            <v-text-field
              disabled
              label="ID Mobil"
              v-model="form.id_mobil"
            ></v-text-field>
            <v-text-field
              disabled
              label="Nama Mobil"
              v-model="form.nama_mobil"
            ></v-text-field>
            <v-text-field
              disabled
              label="ID Mitra"
              v-model="form.id_mitra"
            ></v-text-field>
            <v-text-field
              disabled
              label="Nama Mitra"
              v-model="form.nama_mitra"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tipe_mobil"
              label="Tipe Mobil"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.jenis_transmisi_mobil"
              label="Jenis Transmisi"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.jenis_bahan_bakar_mobil"
              label="Jenis Bahan Bakar"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.volume_bahan_bakar_mobil"
              label="Volume Bahan Bakar"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.warna_mobil"
              label="Warna Mobil"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.kapasitas_penumpang_mobil"
              label="Kapasitas Penumpang"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.fasilitas_mobil"
              label="Fasilitas"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.plat_nomor_mobil"
              label="Plat Nomor"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nomor_stnk_mobil"
              label="Nomor STNK"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.periode_kontrak_mulai_mobil"
              label="Tanggal Mulai Kontrak"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.periode_kontrak_akhir_mobil"
              label="Tanggal Selesai Kontrak"
            ></v-text-field
            ><v-text-field
              disabled
              v-model="form.tanggal_terakhir_servis_mobil"
              label="Tanggal Terakhir Service"
            ></v-text-field
            ><v-text-field
              disabled
              v-model="form.harga_sewa_mobil"
              label="Harga Sewa"
            ></v-text-field
            ><v-text-field
              disabled
              v-model="form.status_mobil"
              label="Status Mobil"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">{{ formTitle }} Data Mobil</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-select
              :rules="kategoriRules"
              v-model="form.kategori_aset_mobil"
              item-text="aset"
              item-value="aset"
              :items="kategori"
              label="Kategori Aset Mobil"
              required
            ></v-select>
            <v-text-field
              :rules="namaRules"
              label="Nama Mobil"
              v-model="form.nama_mobil"
            ></v-text-field>
            <span v-if="form.kategori_aset_mobil == 'Perusahaan'">
              <v-select
                v-model="form.temp_mitra"
                :items="mitra"
                label="Mitra"
                disabled
              ></v-select>
            </span>
            <span v-else>
              <v-select
                :rules="mitraRules"
                v-model="form.temp_mitra"
                :items="mitra"
                label="Mitra"
                required
              ></v-select>
            </span>
            <v-text-field
              :rules="tipeRules"
              v-model="form.tipe_mobil"
              label="Tipe Mobil"
            ></v-text-field>
            <v-text-field
              :rules="transmisiRules"
              v-model="form.jenis_transmisi_mobil"
              label="Jenis Transmisi"
            ></v-text-field>
            <v-text-field
              :rules="jenisBahanBakarRules"
              v-model="form.jenis_bahan_bakar_mobil"
              label="Jenis Bahan Bakar"
            ></v-text-field>
            <v-text-field
              :rules="volumeBahanBakarRules"
              v-model="form.volume_bahan_bakar_mobil"
              label="Volume Bahan Bakar"
              type="number"
              suffix=" L"
            ></v-text-field>
            <v-text-field
              :rules="warnaRules"
              v-model="form.warna_mobil"
              label="Warna Mobil"
            ></v-text-field>
            <v-text-field
              :rules="kapasitasRules"
              v-model="form.kapasitas_penumpang_mobil"
              label="Kapasitas Penumpang"
              type="number"
            ></v-text-field>
            <v-text-field
              :rules="fasilitasRules"
              v-model="form.fasilitas_mobil"
              label="Fasilitas"
            ></v-text-field>
            <v-text-field
              :rules="platRules"
              v-model="form.plat_nomor_mobil"
              label="Plat Nomor"
            ></v-text-field>
            <v-text-field
              :rules="stnkRules"
              v-model="form.nomor_stnk_mobil"
              label="Nomor STNK"
              type="number"
            ></v-text-field>
            <span v-if="form.kategori_aset_mobil == 'Perusahaan'">
              <v-text-field
                type="date"
                v-model="form.periode_kontrak_mulai_mobil"
                label="Tanggal Mulai Kontrak"
                disabled
              ></v-text-field>
            </span>
            <span v-else>
              <v-text-field
                :rules="kontrakMulaiRules"
                type="date"
                v-model="form.periode_kontrak_mulai_mobil"
                label="Tanggal Mulai Kontrak"
              ></v-text-field>
            </span>
            <span v-if="form.kategori_aset_mobil == 'Perusahaan'">
              <v-text-field
                type="date"
                v-model="form.periode_kontrak_akhir_mobil"
                label="Tanggal Selesai Kontrak"
                disabled
              ></v-text-field>
            </span>
            <span v-else>
              <v-text-field
                :rules="kontrakAkhirRules"
                type="date"
                v-model="form.periode_kontrak_akhir_mobil"
                label="Tanggal Selesai Kontrak"
              ></v-text-field>
            </span>
            <v-text-field
              :rules="servisRules"
              type="date"
              v-model="form.tanggal_terakhir_servis_mobil"
              label="Tanggal Terakhir Service"
            ></v-text-field
            ><v-text-field
              :rules="hargaRules"
              v-model="form.harga_sewa_mobil"
              label="Harga Sewa"
              type="number"
              prefix="Rp "
            ></v-text-field
            ><v-select
              v-model="form.status_mobil"
              item-text="st"
              item-value="st"
              :items="status"
              label="Status"
              required
            ></v-select>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Anda Yakin ingin menghapus data ini? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="deleteData">Delete</v-btn>
          <v-btn color="blue darken-1" text @click="dialogConfirm = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Mobil",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Mobil";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogConfirm: false,
      dialogRead: false,
      dialogImage: false,
      temp: 0,
      headers: [
        {
          text: "Nama",
          align: "start",
          sortable: true,
          value: "nama_mobil",
        },
        { text: "Mitra", value: "nama_mitra" },
        { text: "Tipe", value: "tipe_mobil" },
        { text: "Plat Nomor", value: "plat_nomor_mobil" },
        { text: "Akhir Kontrak", value: "periode_kontrak_akhir_mobil" },
        { text: "Harga Sewa", value: "harga_sewa_mobil" },
        { text: "Status", value: "status_mobil" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      kategori: [{ aset: "Perusahaan" }, { aset: "Mitra" }],
      status: [{ st: "Available" }, { st: "Unvailable" }],
      mobil: new FormData(),
      mobilsR: [],
      form: {
        id_mobil: null,
        id_mitra: null,
        nama_mobil: null,
        tipe_mobil: null,
        jenis_transmisi_mobil: null,
        jenis_bahan_bakar_mobil: null,
        volume_bahan_bakar_mobil: null,
        warna_mobil: null,
        kapasitas_penumpang_mobil: null,
        fasilitas_mobil: null,
        plat_nomor_mobil: null,
        nomor_stnk_mobil: null,
        kategori_aset_mobil: null,
        periode_kontrak_mulai_mobil: "",
        periode_kontrak_akhir_mobil: "",
        tanggal_terakhir_servis_mobil: null,
        harga_sewa_mobil: null,
        status_mobil: null,
        status_mobil2: null,
        nama_mitra: null,
        temp_mitra: "",
        gambar_mobil: null,
      },
      form_mitra: {
        id_mitra: null,
        temp_mitra: null,
      },
      mitra: [],
      deleteId: "",
      editId: "",
      mitraRules: [(v) => !!v || "Mitra is Required"],
      namaRules: [(v) => !!v || "Nama is Required"],
      tipeRules: [(v) => !!v || "Tipe is Required"],
      transmisiRules: [(v) => !!v || "Jenis Transmisi is Required"],
      jenisBahanBakarRules: [(v) => !!v || "Jenis Bahan Bakar is Required"],
      volumeBahanBakarRules: [
        (v) => !!v || "Volume Bahan Bakar is Required",
        (v) => (!!v && v) > 0 || "Volume Bahan Bakar Cannot Be 0 or Less",
      ],
      warnaRules: [(v) => !!v || "Warna is Required"],
      kapasitasRules: [
        (v) => !!v || "Kapasitas Penumpang is Required",
        (v) => (!!v && v) > 0 || "Kapasitas Penumpang Cannot Be 0 or Less",
      ],
      fasilitasRules: [(v) => !!v || "Fasilitas is Required"],
      platRules: [(v) => !!v || "Plat Nomor is Required"],
      stnkRules: [(v) => !!v || "Nomor STNK is Required"],
      kategoriRules: [(v) => !!v || "Kategori Aset is Required"],
      kontrakMulaiRules: [(v) => !!v || "Tanggal Kontrak Mulai is Required"],
      kontrakAkhirRules: [(v) => !!v || "Tanggal Kontrak Akhir is Required"],
      servisRules: [(v) => !!v || "Tanggal Terakhir Servis is Required"],
      hargaRules: [
        (v) => !!v || "Harga Sewa is Required",
        (v) => (!!v && v) > 0 || "Harga Sewa Cannot Be 0 or Less",
      ],
    };
  },
  methods: {
    moveMobil() {
      this.$router.push({ path: "/mobil" });
    },
    setForm() {
      if (this.inputType !== "Tambah") {
        this.update();
      } else {
        this.save();
      }
    },
    readMitra() {
      var url = this.$api + "/mitraRead";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_mitra.id_mitra = temp.map((v) => v.id_mitra);
        this.form_mitra.temp_mitra = temp.map((v) => v.temp_mitra);
        for (let i = 0; i < this.form_mitra.temp_mitra.length; i++) {
          this.mitra.push(this.form_mitra.temp_mitra[i]);
        }
      });
    },
    readDataKadaluwarsa() {
      var url = this.$api + "/mobilKadaluwarsa";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.mobilsR = response.data.data;
        });
    },
    updateTemp() {
      var url = this.$api + "/mobilTemp";
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.readDataM();
          this.readDataP();
          this.readDataKadaluwarsa();
          this.readDataAvailable();
          this.readDataAkanHabisKontrak();
          this.readDataRemove();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //ubah data mitra
    update() {
      let newData = {
        temp_mitra: this.form.temp_mitra,
        nama_mobil: this.form.nama_mobil,
        tipe_mobil: this.form.tipe_mobil,
        jenis_transmisi_mobil: this.form.jenis_transmisi_mobil,
        jenis_bahan_bakar_mobil: this.form.jenis_bahan_bakar_mobil,
        volume_bahan_bakar_mobil: this.form.volume_bahan_bakar_mobil,
        warna_mobil: this.form.warna_mobil,
        kapasitas_penumpang_mobil: this.form.kapasitas_penumpang_mobil,
        fasilitas_mobil: this.form.fasilitas_mobil,
        plat_nomor_mobil: this.form.plat_nomor_mobil,
        nomor_stnk_mobil: this.form.nomor_stnk_mobil,
        kategori_aset_mobil: this.form.kategori_aset_mobil,
        periode_kontrak_mulai_mobil: this.form.periode_kontrak_mulai_mobil,
        periode_kontrak_akhir_mobil: this.form.periode_kontrak_akhir_mobil,
        tanggal_terakhir_servis_mobil: this.form.tanggal_terakhir_servis_mobil,
        status_mobil: this.form.status_mobil,
        harga_sewa_mobil: this.form.harga_sewa_mobil,
      };

      var url = this.$api + "/mobil/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readDataM();
          this.readDataP();
          this.readDataAvailable();
          this.readDataKadaluwarsa();
          this.readDataAkanHabisKontrak();
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //menghapus data
      var url = this.$api + "/mobilDelete/" + this.deleteId;
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readDataM();
          this.readDataP();
          this.readDataAvailable();
          this.readDataKadaluwarsa();
          this.readDataAkanHabisKontrak();
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Edit";
      this.editId = item.id_mobil;
      this.form.id_mitra = item.id_mitra;
      this.form.nama_mitra = item.nama_mitra;
      this.form.nama_mobil = item.nama_mobil;
      this.form.tipe_mobil = item.tipe_mobil;
      this.form.jenis_transmisi_mobil = item.jenis_transmisi_mobil;
      this.form.jenis_bahan_bakar_mobil = item.jenis_bahan_bakar_mobil;
      this.form.volume_bahan_bakar_mobil = item.volume_bahan_bakar_mobil;
      this.form.warna_mobil = item.warna_mobil;
      this.form.kapasitas_penumpang_mobil = item.kapasitas_penumpang_mobil;
      this.form.fasilitas_mobil = item.fasilitas_mobil;
      this.form.plat_nomor_mobil = item.plat_nomor_mobil;
      this.form.nomor_stnk_mobil = item.nomor_stnk_mobil;
      this.form.kategori_aset_mobil = item.kategori_aset_mobil;
      this.form.periode_kontrak_mulai_mobil = item.periode_kontrak_mulai_mobil;
      this.form.periode_kontrak_akhir_mobil = item.periode_kontrak_akhir_mobil;
      this.form.tanggal_terakhir_servis_mobil =
        item.tanggal_terakhir_servis_mobil;
      this.form.harga_sewa_mobil = item.harga_sewa_mobil;
      this.form.status_mobil = item.status_mobil;
      this.form.temp_mitra = item.temp_mitra;
      this.dialog = true;
    },
    readHandlerM(item) {
      this.form.id_mobil = item.id_mobil;
      this.form.id_mitra = item.id_mitra;
      this.form.nama_mitra = item.nama_mitra;
      this.form.nama_mobil = item.nama_mobil;
      this.form.tipe_mobil = item.tipe_mobil;
      this.form.jenis_transmisi_mobil = item.jenis_transmisi_mobil;
      this.form.jenis_bahan_bakar_mobil = item.jenis_bahan_bakar_mobil;
      this.form.volume_bahan_bakar_mobil = item.volume_bahan_bakar_mobil;
      this.form.warna_mobil = item.warna_mobil;
      this.form.kapasitas_penumpang_mobil = item.kapasitas_penumpang_mobil;
      this.form.fasilitas_mobil = item.fasilitas_mobil;
      this.form.plat_nomor_mobil = item.plat_nomor_mobil;
      this.form.nomor_stnk_mobil = item.nomor_stnk_mobil;
      this.form.kategori_aset_mobil = item.kategori_aset_mobil;
      this.form.periode_kontrak_mulai_mobil = item.periode_kontrak_mulai_mobil;
      this.form.periode_kontrak_akhir_mobil = item.periode_kontrak_akhir_mobil;
      this.form.tanggal_terakhir_servis_mobil =
        item.tanggal_terakhir_servis_mobil;
      this.form.harga_sewa_mobil = item.harga_sewa_mobil;
      this.form.status_mobil = item.status_mobil;
      this.form.temp_mitra = item.temp_mitra;
      this.dialogReadM = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogReadM = false;
      this.dialogReadP = false;
      this.dialogImage = false;
      this.readDataM();
      this.readDataP();
      this.readDataAvailable();
      this.readDataKadaluwarsa();
      this.readDataAkanHabisKontrak();
      this.readDataRemove();
    },
    cancel() {
      this.resetForm();
      this.readDataM();
      this.readDataP();
      this.readDataAvailable();
      this.readDataKadaluwarsa();
      this.readDataAkanHabisKontrak();
      this.readDataRemove();
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogReadM = false;
      this.dialogReadP = false;
      this.dialogImage = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_mobil: null,
        id_mitra: null,
        nama_mobil: null,
        tipe_mobil: null,
        jenis_transmisi_mobil: null,
        jenis_bahan_bakar_mobil: null,
        volume_bahan_bakar_mobil: null,
        warna_mobil: null,
        kapasitas_penumpang_mobil: null,
        fasilitas_mobil: null,
        plat_nomor_mobil: null,
        nomor_stnk_mobil: null,
        kategori_aset_mobil: null,
        periode_kontrak_mulai_mobil: "",
        periode_kontrak_akhir_mobil: "",
        tanggal_terakhir_servis_mobil: null,
        harga_sewa_mobil: null,
        status_mobil: null,
        status_mobil2: null,
        nama_mitra: null,
        temp_mitra: "",
        gambar_mobil: null,
      };
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Mobil");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readDataKadaluwarsa();
    this.updateTemp();
    this.readMitra();
  },
};
</script>

<style scoped></style>
