<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-btn
      text
      large
      @click="moveMobil"
      style="float: left; margin-left: -30px; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Deleted Data Mobil</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="mobilsD"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn small class="mr-2" @click="recoverData(item)">Recover</v-btn>
        </template>
      </v-data-table>
    </v-card>
  </v-main>
</template>

<script>
export default {
  name: "Mobil",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Mobil";
      },
    },
  },
  data() {
    return {
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      temp: 0,
      headers: [
        {
          text: "Nama",
          align: "start",
          sortable: true,
          value: "nama_mobil",
        },
        { text: "Mitra", value: "nama_mitra" },
        { text: "Tipe", value: "tipe_mobil" },
        { text: "Plat Nomor", value: "plat_nomor_mobil" },
        { text: "Akhir Kontrak", value: "periode_kontrak_akhir_mobil" },
        { text: "Harga Sewa", value: "harga_sewa_mobil" },
        { text: "Status", value: "status_mobil" },
        { text: "Actions", value: "actions" },
      ],
      mobilsD: [],
    };
  },
  methods: {
    moveMobil() {
      this.$router.push({ path: "/mobil" });
    },
    readDataRemove() {
      var url = this.$api + "/mobilRemove";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.mobilsD = response.data.data;
        });
    },
    recoverData(item) {
      var url = this.$api + "/mobilRecover/" + item.id_mobil;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.close();
          this.readDataM();
          this.readDataP();
          this.readDataAvailable();
          this.readDataKadaluwarsa();
          this.readDataAkanHabisKontrak();
          this.readDataRemove();
        });
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Mobil");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readDataRemove();
  },
};
</script>

<style scoped></style>
