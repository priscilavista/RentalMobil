<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <h5 style="font-size: 30px">Data Jadwal Pegawai</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>

        <v-btn
          color="success"
          dark
          @click="dialogAdd = true"
          style="margin-right: 48px; margin-top: 20px"
          >Add Jadwal Pegawai</v-btn
        >
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="jadwalPegawais"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <!-- <v-btn small class="mr-2" @click="editHandler(item)"
            ><v-icon color="#F2C031">mdi-pencil</v-icon></v-btn
          >
          <v-btn small @click="deleteHandler(item.id)">delete</v-btn> -->
          <v-menu offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandler(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="editHandler(item)"
                      ><v-icon color="#E39348">mdi-pencil</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn
                      small
                      @click="
                        deleteHandler(item.id_pegawai, item.id_jadwal_pegawai)
                      "
                      ><v-icon color="#C94141"
                        >mdi-account-remove</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogRead"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <!-- <v-card-title style="float: none">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </v-card-title> -->
        <div mt="3">
          <p class="headline" style="text-align: center">Data Jadwal Pegawai</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              label="Hari"
              v-model="form.hari"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.shift"
              label="Shift"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_role"
              label="Role"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.id_pegawai"
              label="ID Pegawai"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_pegawai"
              label="Nama Pegawai"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogAdd" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">{{ formTitle }} Data Jadwal Pegawai</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-select
              :rules="jadwalRules"
              v-model="form.temp_jadwal_pegawai"
              :items="jadwal_pegawai"
              label="Jadwal"
              required
            ></v-select>
            <v-select
              :rules="pegawaiRules"
              v-model="form.temp_pegawai"
              :items="pegawai"
              label="Pegawai"
              required
            ></v-select>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogUpdate" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">{{ formTitle }} Data Jadwal Pegawai</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-select
              v-model="form.temp_jadwal_pegawai"
              :items="jadwal_pegawai"
              label="Jadwal"
              disabled
            ></v-select>
            <v-select
              :rules="pegawaiRules"
              v-model="form.temp_pegawai"
              :items="pegawai"
              label="Pegawai"
              required
            ></v-select>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Anda Yakin ingin menghapus data ini? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="deleteData">Delete</v-btn>
          <v-btn color="blue darken-1" text @click="dialogConfirm = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Jadwal Pegawai",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Jadwal Pegawai";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialogAdd: false,
      dialogUpdate: false,
      dialogConfirm: false,
      dialogRead: false,
      temp: 0,
      headers: [
        {
          text: "Hari",
          align: "start",
          sortable: true,
          value: "hari",
        },
        { text: "Shift", value: "shift" },
        { text: "Role", value: "nama_role" },
        { text: "Pegawai", value: "nama_pegawai" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      jadwalPegawai: new FormData(),
      jadwalPegawais: [],
      form: {
        id_pegawai: null,
        nama_pegawai: null,
        id_jadwal_pegawai: null,
        hari: null,
        shift: null,
        nama_role: null,
        temp_pegawai: null,
        temp_jadwal_pegawai: null,
      },
      form_pegawai: {
        id_pegawai: null,
        nama_pegawai: null,
        temp_pegawai: null,
        id_role: null,
      },
      pegawai: [],
      form_jadwal_pegawai: {
        id_jadwal_pegawai: null,
        temp_jadwal_pegawai: null,
      },
      jadwal_pegawai: [],
      deleteId: "",
      editIdP: "",
      editIdJP: "",
      jadwalRules: [(v) => !!v || "Jadwal is Required"],
      pegawaiRules: [(v) => !!v || "Pegawai is Required"],
    };
  },
  methods: {
    setForm() {
      if (this.inputType !== "Tambah") {
        this.update();
      } else {
        this.save();
      }
    },
    readPegawai() {
      var url = this.$api + "/pegawaiRead";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_pegawai.id_pegawai = temp.map((v) => v.id_pegawai);
        this.form_pegawai.nama_pegawai = temp.map((v) => v.nama_pegawai);
        this.form_pegawai.temp_pegawai = temp.map((v) => v.temp_pegawai);
        this.form_pegawai.id_role = temp.map((v) => v.id_role);
        for (let i = 0; i < this.form_pegawai.temp_pegawai.length; i++) {
          if (this.form_pegawai.id_role[i] != 1) {
            this.pegawai.push(this.form_pegawai.temp_pegawai[i]);
          }
        }
      });
    },
    readJadwal() {
      var url = this.$api + "/jadwalPegawai";
      this.$http.get(url).then((response) => {
        // this.role = response.data.data;
        let temp = response.data.data;
        this.form_jadwal_pegawai.id_jadwal_pegawai = temp.map(
          (v) => v.id_jadwal_pegawai
        );
        this.form_jadwal_pegawai.temp_jadwal_pegawai = temp.map(
          (v) => v.temp_jadwal_pegawai
        );
        for (
          let i = 0;
          i < this.form_jadwal_pegawai.temp_jadwal_pegawai.length;
          i++
        ) {
          this.jadwal_pegawai.push(
            this.form_jadwal_pegawai.temp_jadwal_pegawai[i]
          );
        }
      });
    },
    //read data mitra
    readData() {
      var url = this.$api + "/detailJadwalPegawaiRead";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.jadwalPegawais = response.data.data;
        });
    },
    save() {
      this.jadwalPegawai.append("temp_pegawai", this.form.temp_pegawai);
      this.jadwalPegawai.append(
        "temp_jadwal_pegawai",
        this.form.temp_jadwal_pegawai
      );

      var url = this.$api + "/detailJadwalPegawai/";
      this.load = true;
      this.$http
        .post(url, this.jadwalPegawai, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.updateTemp();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //ubah data mitra
    update() {
      let newData = {
        temp_pegawai: this.form.temp_pegawai,
        temp_jadwal_pegawai: this.form.temp_jadwal_pegawai,
      };

      var url =
        this.$api +
        "/detailJadwalPegawai/" +
        this.editIdP +
        "/" +
        this.editIdJP;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //menghapus data
      var url =
        this.$api +
        "/detailJadwalPegawai/" +
        this.deleteIdP +
        "/" +
        this.deleteIdJP;
      this.load = true;
      this.$http
        .delete(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Edit";
      this.editIdP = item.id_pegawai;
      this.editIdJP = item.id_jadwal_pegawai;
      this.form.nama_pegawai = item.nama_pegawai;
      this.form.id_jadwal_pegawai = item.id_jadwal_pegawai;
      this.form.hari = item.hari;
      this.form.shift = item.shift;
      this.form.nama_role = item.nama_role;
      this.form.temp_pegawai = item.temp_pegawai;
      this.form.temp_jadwal_pegawai = item.temp_jadwal_pegawai;
      this.dialogUpdate = true;
    },
    readHandler(item) {
      this.form.id_pegawai = item.id_pegawai;
      this.form.nama_pegawai = item.nama_pegawai;
      this.form.id_jadwal_pegawai = item.id_jadwal_pegawai;
      this.form.hari = item.hari;
      this.form.shift = item.shift;
      this.form.nama_role = item.nama_role;
      this.dialogRead = true;
    },
    deleteHandler(idP, idJP) {
      this.deleteIdP = idP;
      this.deleteIdJP = idJP;
      this.dialogConfirm = true;
    },
    close() {
      this.dialogAdd = false;
      this.dialogUpdate = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.readData();
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialogAdd = false;
      this.dialogUpdate = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_pegawai: null,
        nama_pegawai: null,
        id_jadwal_pegawai: null,
        hari: null,
        shift: null,
        nama_role: null,
        temp_pegawai: null,
        temp_jadwal_pegawai: null,
      };
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Jadwal Pegawai");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readData();
    this.readPegawai();
    this.readJadwal();
  },
};
</script>

<style scoped></style>
