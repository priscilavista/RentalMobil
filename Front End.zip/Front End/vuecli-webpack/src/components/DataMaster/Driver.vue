<template>
  <v-main class="list" style="margin: auto; margin-top: 60px">
    <h5 style="font-size: 30px">Data Driver</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>

        <v-btn
          color="success"
          dark
          @click="dialog = true"
          style="margin-right: 48px; margin-top: 20px"
          >Add Driver</v-btn
        >
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="drivers"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <!-- <v-btn small class="mr-2" @click="editHandler(item)"
            ><v-icon color="#F2C031">mdi-pencil</v-icon></v-btn
          >
          <v-btn small @click="deleteHandler(item.id)">delete</v-btn> -->
          <v-menu offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandler(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="imageHandler(item)"
                      ><v-icon color="#E39348">mdi-image</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="uploadHandler(item)"
                      ><v-icon color="#E39348"
                        >mdi-folder-upload-outline</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="editHandler(item)"
                      ><v-icon color="#E39348">mdi-pencil</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="deleteHandler(item.id_driver)"
                      ><v-icon color="#C94141"
                        >mdi-account-remove</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <br />
    <br />
    <br />
    <h5 style="font-size: 30px">Deleted Data</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="driversR"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn small class="mr-2" @click="recoverData(item)">Recover</v-btn>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogRead"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <!-- <v-card-title style="float: none">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </v-card-title> -->
        <div mt="3">
          <p class="headline" style="text-align: center">Data Driver</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              label="ID"
              v-model="form.id_driver"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_driver"
              label="Nama"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.alamat_driver"
              label="Alamat"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_lahir_driver"
              label="Tanggal Lahir"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.jenis_kelamin_driver"
              label="Jenis Kelamin"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.email_driver"
              label="Email"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.no_telp_driver"
              label="Nomor Telepon"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.bahasa_driver"
              label="Bahasa"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tarif_driver"
              label="Tarif"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.status_driver"
              label="Status"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">{{ formTitle }} Data Driver</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              :rules="namaRules"
              v-model="form.nama_driver"
              label="Nama"
            ></v-text-field>
            <v-text-field
              :rules="alamatRules"
              v-model="form.alamat_driver"
              label="Alamat"
            ></v-text-field>
            <v-text-field
              :rules="ttlRules"
              type="date"
              v-model="form.tanggal_lahir_driver"
              label="Tanggal Lahir"
            ></v-text-field>
            <v-select
              :rules="genderRules"
              v-model="form.jenis_kelamin_driver"
              item-text="gender"
              item-value="gender"
              :items="genders"
              label="Jenis Kelamin"
              required
            ></v-select>
            <v-text-field
              :rules="emailRules"
              v-model="form.email_driver"
              label="Email"
            ></v-text-field>
            <v-text-field
              :rules="telpRules"
              v-model="form.no_telp_driver"
              label="Nomor Telepon"
              type="number"
            ></v-text-field>
            <v-select
              :rules="bahasaRules"
              v-model="form.bahasa_driver"
              item-text="bhs"
              item-value="bhs"
              :items="bahasa"
              label="Bahasa"
              required
            ></v-select>
            <v-text-field
              :rules="tarifRules"
              v-model="form.tarif_driver"
              label="Tarif"
              type="numer"
              prefix="Rp "
            ></v-text-field>
            <v-select
              v-model="form.status_driver"
              item-text="st"
              item-value="st"
              :items="status"
              label="Status"
              required
            ></v-select>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogUpload" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">Upload Berkas Driver</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <span class="mt-5" style="font-weight: bold">Berkas SIM</span><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.berkas_sim_driver)"
              v-on:change="onImageChange1"
              label="Image Input"
            />
            <span v-if="this.form.berkas_sim_driver != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.berkas_sim_driver"
              ></v-img> </span
            ><br /><br />
            <span class="mt-5" style="font-weight: bold"
              >Berkas Surat Bebas Napza</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.berkas_surat_bebasnapza_driver)"
              v-on:change="onImageChange2"
              label="Image Input"
            />
            <span v-if="this.form.berkas_surat_bebasnapza_driver != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.berkas_surat_bebasnapza_driver"
              ></v-img> </span
            ><br /><br />
            <span class="mt-5" style="font-weight: bold"
              >Berkas Surat Kesehatan Jiwa</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.berkas_surat_kesjiwa_driver)"
              v-on:change="onImageChange3"
              label="Image Input"
            />
            <span v-if="this.form.berkas_surat_kesjiwa_driver != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.berkas_surat_kesjiwa_driver"
              ></v-img> </span
            ><br /><br />
            <span class="mt-5" style="font-weight: bold"
              >Berkas Surat Kesehatan Jasmani</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.berkas_surat_kesjasmani_driver)"
              v-on:change="onImageChange4"
              label="Image Input"
            />
            <span v-if="this.form.berkas_surat_kesjasmani_driver != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.berkas_surat_kesjasmani_driver"
              ></v-img> </span
            ><br /><br />
            <span class="mt-5" style="font-weight: bold">Berkas SKCK</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.berkas_skck_driver)"
              v-on:change="onImageChange5"
              label="Image Input"
            />
            <span v-if="this.form.berkas_skck_driver != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.berkas_skck_driver"
              ></v-img> </span
            ><br /><br />
          </v-container>
          <v-card-action>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" text @click="upload">Upload</v-btn>
            <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
            <v-spacer></v-spacer>
          </v-card-action>
        </v-card-text>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogImage" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <span class="headline">Upload Foto Driver</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <span class="mt-5" style="font-weight: bold">Foto Driver</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.foto_driver)"
              v-on:change="onImageChange"
              label="Image Input"
            />
            <span v-if="this.form.foto_driver != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.foto_driver"
              ></v-img> </span
            ><br /><br />
          </v-container>
          <v-card-action>
            <v-spacer></v-spacer>
            <v-btn color="blue darken-1" text @click="image">Upload</v-btn>
            <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
            <v-spacer></v-spacer>
          </v-card-action>
        </v-card-text>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Anda Yakin ingin menghapus data ini? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="deleteData">Delete</v-btn>
          <v-btn color="blue darken-1" text @click="dialogConfirm = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Driver",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Driver";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogConfirm: false,
      dialogRead: false,
      dialogUpload: false,
      dialogImage: false,
      temp: 0,
      headers: [
        {
          text: "Nama",
          align: "start",
          sortable: true,
          value: "nama_driver",
        },
        { text: "Alamat", value: "alamat_driver" },
        // { text: "Tanggal Lahir", value: "tanggal_lahir_driver" },
        // { text: "Jenis Kelamin", value: "jenis_kelamin_driver" },
        { text: "Email", value: "email_driver" },
        { text: "Nomor Telepon", value: "no_telp_driver" },
        // { text: "Bahasa", value: "bahasa_driver" },
        { text: "Tarif", value: "tarif_driver" },
        { text: "Status", value: "status_driver" },
        // { text: "Foto driver", value: "foto_driver" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      genders: [{ gender: "Laki-laki" }, { gender: "Perempuan" }],
      bahasa: [{ bhs: "Indonesia" }, { bhs: "Inggris" }],
      status: [{ st: "Available" }, { st: "Unvailable" }],
      driver: new FormData(),
      drivers: [],
      driversR: [],
      form: {
        id_driver: null,
        nama_driver: null,
        alamat_driver: null,
        tanggal_lahir_driver: null,
        jenis_kelamin_driver: null,
        email_driver: null,
        no_telp_driver: null,
        bahasa_driver: null,
        tarif_driver: null,
        status_driver: "Available",
        foto_driver: null,
        berkas_sim_driver: null,
        berkas_surat_bebasnapza_driver: null,
        berkas_surat_kesjiwa_driver: null,
        berkas_surat_kesjasmani_driver: null,
        berkas_skck_driver: null,
      },
      deleteId: "",
      editId: "",
      namaRules: [(v) => !!v || "Nama is Required"],
      alamatRules: [(v) => !!v || "Alamat is Required"],
      ttlRules: [(v) => !!v || "Tanggal Lahir is Required"],
      genderRules: [(v) => !!v || "Jenis Kelamin is Required"],
      emailRules: [
        (v) => !!v || "Email is Required",
        (v) => /.+@.+\..+/.test(v) || "Email must be valid",
      ],
      telpRules: [
        (v) => !!v || "Nomor Telepon is Required",
        (v) => /^([0][8][0-9]{8,10})$/g.test(v) || "Phone Number must be valid",
      ],
      bahasaRules: [(v) => !!v || "Bahasa is Required"],
      tarifRules: [
        (v) => !!v || "Tarif is Required",
        (v) => (!!v && v) > 0 || "Tarif Cannot Be 0 or Less",
      ],
    };
  },
  methods: {
    setForm() {
      if (this.inputType !== "Tambah") {
        this.update();
      } else {
        this.save();
      }
    },
    refreshPage() {
      if (localStorage.getItem("reloaded")) {
        // The page was just reloaded. Clear the value from local storage
        // so that it will reload the next time this page is visited.
        localStorage.removeItem("reloaded");
      } else {
        // Set a flag so that we know not to reload the page twice.
        localStorage.setItem("reloaded", "1");
        location.reload();
      }
    },
    //read data mitra
    readData() {
      var url = this.$api + "/driverRead";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.drivers = response.data.data;
        });
    },
    readDataRemove() {
      var url = this.$api + "/driverRemove";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.driversR = response.data.data;
        });
    },
    save() {
      this.driver.append("nama_driver", this.form.nama_driver);
      this.driver.append("alamat_driver", this.form.alamat_driver);
      this.driver.append(
        "tanggal_lahir_driver",
        this.form.tanggal_lahir_driver
      );
      this.driver.append(
        "jenis_kelamin_driver",
        this.form.jenis_kelamin_driver
      );
      this.driver.append("email_driver", this.form.email_driver);
      this.driver.append("no_telp_driver", this.form.no_telp_driver);
      this.driver.append("bahasa_driver", this.form.bahasa_driver);
      this.driver.append("tarif_driver", this.form.tarif_driver);
      //   this.driver.append("foto_driver", this.form.foto_driver);

      var url = this.$api + "/driver/";
      this.load = true;
      this.$http
        .post(url, this.driver, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.updateTemp();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    updateTemp() {
      var url = this.$api + "/driverTemp";
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.readData();
          this.readDataRemove(); // baca data
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //ubah data mitra
    update() {
      let newData = {
        nama_driver: this.form.nama_driver,
        alamat_driver: this.form.alamat_driver,
        tanggal_lahir_driver: this.form.tanggal_lahir_driver,
        jenis_kelamin_driver: this.form.jenis_kelamin_driver,
        email_driver: this.form.email_driver,
        no_telp_driver: this.form.no_telp_driver,
        bahasa_driver: this.form.bahasa_driver,
        tarif_driver: this.form.tarif_driver,
        status_driver: this.form.status_driver,
        foto_driver: this.form.foto_driver,
      };

      var url = this.$api + "/driver/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //menghapus data
      var url = this.$api + "/driverDelete/" + this.deleteId;
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    recoverData(item) {
      var url = this.$api + "/driverRecover/" + item.id_driver;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
        });
    },
    onImageChange(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage(files[0]);
    },

    createImage(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.foto_driver = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    onImageChange1(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage1(files[0]);
    },

    createImage1(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.berkas_sim_driver = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    onImageChange2(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage2(files[0]);
    },

    createImage2(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.berkas_surat_bebasnapza_driver = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    onImageChange3(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage3(files[0]);
    },

    createImage3(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.berkas_surat_kesjiwa_driver = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    onImageChange4(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage4(files[0]);
    },

    createImage4(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.berkas_surat_kesjasmani_driver = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    onImageChange5(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage5(files[0]);
    },

    createImage5(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.berkas_skck_driver = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    upload() {
      let newData = {
        berkas_sim_driver: this.form.berkas_sim_driver,
        berkas_surat_bebasnapza_driver:
          this.form.berkas_surat_bebasnapza_driver,
        berkas_surat_kesjiwa_driver: this.form.berkas_surat_kesjiwa_driver,
        berkas_surat_kesjasmani_driver:
          this.form.berkas_surat_kesjasmani_driver,
        berkas_skck_driver: this.form.berkas_skck_driver,
      };

      var url = this.$api + "/driverBerkas/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    image() {
      let newData = {
        foto_driver: this.form.foto_driver,
      };

      var url = this.$api + "/driverImage/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    imageHandler(item) {
      this.editId = item.id_driver;
      this.form.foto_driver = item.foto_driver;
      this.dialogImage = true;
    },
    uploadHandler(item) {
      this.editId = item.id_driver;
      this.form.berkas_sim_driver = item.berkas_sim_driver;
      this.form.berkas_surat_bebasnapza_driver =
        item.berkas_surat_bebas_napza_driver;
      this.form.berkas_surat_kesjiwa_driver = item.berkas_surat_kesjiwa_driver;
      this.form.berkas_surat_kesjasmani_driver =
        item.berkas_surat_kesjasmani_driver;
      this.form.berkas_skck_driver = item.berkas_skck_driver;
      this.dialogUpload = true;
    },
    editHandler(item) {
      this.inputType = "Edit";
      this.editId = item.id_driver;
      this.form.nama_driver = item.nama_driver;
      this.form.alamat_driver = item.alamat_driver;
      this.form.tanggal_lahir_driver = item.tanggal_lahir_driver;
      this.form.jenis_kelamin_driver = item.jenis_kelamin_driver;
      this.form.email_driver = item.email_driver;
      this.form.no_telp_driver = item.no_telp_driver;
      this.form.bahasa_driver = item.bahasa_driver;
      this.form.tarif_driver = item.tarif_driver;
      this.form.status_driver = item.status_driver;
      this.form.foto_driver = item.foto_driver;
      this.dialog = true;
    },
    readHandler(item) {
      this.form.id_driver = item.id_driver;
      this.form.nama_driver = item.nama_driver;
      this.form.alamat_driver = item.alamat_driver;
      this.form.tanggal_lahir_driver = item.tanggal_lahir_driver;
      this.form.jenis_kelamin_driver = item.jenis_kelamin_driver;
      this.form.email_driver = item.email_driver;
      this.form.no_telp_driver = item.no_telp_driver;
      this.form.bahasa_driver = item.bahasa_driver;
      this.form.tarif_driver = item.tarif_driver;
      this.form.status_driver = item.status_driver;
      this.form.foto_driver = item.foto_driver;
      this.dialogRead = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.dialogImage = false;
      this.dialogUpload = false;
      this.readData();
      this.readDataRemove();
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.readDataRemove();
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.dialogUpload = false;
      this.dialogImage = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_driver: null,
        nama_driver: null,
        alamat_driver: null,
        tanggal_lahir_driver: null,
        jenis_kelamin_driver: null,
        email_driver: null,
        no_telp_driver: null,
        bahasa_driver: null,
        tarif_driver: null,
        status_driver: "Available",
        foto_driver: null,
        berkas_sim_driver: null,
        berkas_surat_bebasnapza_driver: null,
        berkas_surat_kesjiwa_driver: null,
        berkas_surat_kesjasmani_driver: null,
        berkas_skck_driver: null,
      };
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Driver");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readData();
    this.readDataRemove();
    this.updateTemp();
  },
};
</script>

<style scoped></style>
