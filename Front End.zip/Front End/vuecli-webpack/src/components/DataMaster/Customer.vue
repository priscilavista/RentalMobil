<template>
  <v-main class="list" style="margin: auto; margin-top: 60px">
    <h5 style="font-size: 30px">Data Customer</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>

        <v-btn
          color="success"
          dark
          @click="dialog = true"
          style="margin-right: 48px; margin-top: 20px"
          >Add Customer</v-btn
        >
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="customers"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <!-- <v-btn small class="mr-2" @click="editHandler(item)"
            ><v-icon color="#F2C031">mdi-pencil</v-icon></v-btn
          >
          <v-btn small @click="deleteHandler(item.id)">delete</v-btn> -->
          <v-menu offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandler(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="editHandler(item)"
                      ><v-icon color="#E39348">mdi-pencil</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="printHandler(item)"
                      ><v-icon color="#4B4B4B"
                        >mdi-printer-outline</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogRead"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <!-- <v-card-title style="float: none">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </v-card-title> -->
        <div mt="3">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              label="ID"
              v-model="form.id_customer"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_customer"
              label="Nama"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.alamat_customer"
              label="Alamat"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.tanggal_lahir_customer"
              label="Tanggal Lahir"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.jenis_kelamin_customer"
              label="Jenis Kelamin"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.email_customer"
              label="Email"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.no_telp_customer"
              label="Nomor Telepon"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.no_ktp_customer"
              label="Nomor KTP"
            ></v-text-field>
            <span class="mt-5" style="font-weight: bold">Dokumen Pendukung</span
            ><br />
            <span v-if="this.form.dokumen_pendukung != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.dokumen_pendukung"
              ></v-img>
              <br /><br
            /></span>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline" style="text-align: center"
            >{{ formTitle }} Data Customer</span
          >
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              :rules="namaRules"
              v-model="form.nama_customer"
              label="Nama"
            ></v-text-field>
            <v-text-field
              :rules="alamatRules"
              v-model="form.alamat_customer"
              label="Alamat"
            ></v-text-field>
            <v-text-field
              :rules="ttlRules"
              type="date"
              v-model="form.tanggal_lahir_customer"
              label="Tanggal Lahir"
            ></v-text-field>
            <v-select
              :rules="genderRules"
              v-model="form.jenis_kelamin_customer"
              item-text="gender"
              item-value="gender"
              :items="genders"
              label="Jenis Kelamin"
              required
            ></v-select>
            <v-text-field
              :rules="emailRules"
              v-model="form.email_customer"
              label="Email"
            ></v-text-field>
            <v-text-field
              :rules="telpRules"
              v-model="form.no_telp_customer"
              label="Nomor Telepon"
              type="number"
            ></v-text-field>
            <v-text-field
              :rules="ktpRules"
              v-model="form.no_ktp_customer"
              label="Nomor KTP"
              type="number"
            ></v-text-field>
            <span class="mt-5" style="font-weight: bold">Dokumen Pendukung</span
            ><br />
            <input
              class="mt-2"
              type="file"
              :state="Boolean(this.form.dokumen_pendukung)"
              v-on:change="onImageChange"
              label="Image Input"
            />
            <span v-if="this.form.dokumen_pendukung != null">
              <v-img
                class="mt-5"
                height="250"
                :src="this.form.dokumen_pendukung"
              ></v-img> </span
            ><br /><br />
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogPrint" persistent max-width="800px">
      <span id="KartuCustomer">
        <v-card color="#245399">
          <v-container>
            <v-row>
              <v-col>
                <v-card-title
                  style="color: #e6a20f; font-weight: bold; margin-top: 20px"
                  >ATMA JOGJA RENTAL</v-card-title
                >
                <v-img
                  contain
                  height="250"
                  width="250"
                  :src="image"
                  style="margin-bottom: 30px"
                ></v-img>
              </v-col>

              <v-col>
                <!-- <v-row>
                  <v-text
                    style="
                      color: #ffffff;
                      float: right !important;
                      margin-top: 65px;
                      font-weight: bold;
                      font-size: 30px;
                    "
                  >
                    {{ this.form.nama_customer }}
                  </v-text>
                </v-row> -->
                <!-- 
                <v-text>
                  <div
                    style="
                      color: #ffffff;
                      float: right !important;
                      margin-top: 3px;
                      font-size: 19px;
                    "
                  >
                    {{ this.form.id_customer }}
                  </div>
                </v-text> -->

                <v-card-text
                  class="text-right"
                  style="
                    color: #ffffff;
                    float: right !important;
                    margin-top: 65px;
                    font-weight: bold;
                    font-size: 30px;
                  "
                  >{{ this.form.nama_customer }}</v-card-text
                >

                <v-card-text
                  class="text-right"
                  style="
                    color: #ffffff;
                    float: right !important;
                    font-size: 19px;
                  "
                  >{{ this.form.id_customer }}</v-card-text
                >

                <v-card-text
                  class="text-right"
                  style="
                    color: #ffffff;
                    float: right !important;
                    margin-top: 30px;
                    font-size: 16px;
                    padding-top: 0;
                    padding-bottom: 0;
                  "
                  >Mobile: {{ this.form.no_telp_customer }}</v-card-text
                >
                <v-card-text
                  class="text-right"
                  style="
                    color: #ffffff;
                    float: right !important;
                    font-size: 16px;
                    padding-top: 0;
                    padding-bottom: 0;
                  "
                  >Address: {{ this.form.alamat_customer }}</v-card-text
                >
                <v-card-text
                  class="text-right"
                  style="
                    color: #ffffff;
                    float: right !important;
                    font-size: 16px;
                    padding-top: 0;
                    padding-bottom: 0;
                  "
                  >Email: {{ this.form.email_customer }}</v-card-text
                >
              </v-col>
            </v-row>
            <v-row> </v-row>
          </v-container>
        </v-card>
      </span>
      <v-card>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="exportPDF">Print</v-btn>
          <v-btn color="blue darken-1" text @click="close">Close</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
import html2PDF from "jspdf-html2canvas";
export default {
  name: "Customer",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Customer";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogConfirm: false,
      dialogRead: false,
      dialogPrint: false,
      temp: 0,
      headers: [
        {
          text: "Nama",
          align: "start",
          sortable: true,
          value: "nama_customer",
        },
        { text: "Alamat", value: "alamat_customer" },
        // { text: "Tanggal Lahir", value: "tanggal_lahir_customer" },
        // { text: "Jenis Kelamin", value: "jenis_kelamin_customer" },
        { text: "Email", value: "email_customer" },
        { text: "Nomor Telepon", value: "no_telp_customer" },
        { text: "Nomor KTP", value: "no_ktp_customer" },
        // { text: "Foto driver", value: "foto_driver" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      genders: [{ gender: "Laki-laki" }, { gender: "Perempuan" }],
      customer: new FormData(),
      customers: [],
      form: {
        id_customer: null,
        nama_customer: null,
        alamat_customer: null,
        tanggal_lahir_customer: null,
        jenis_kelamin_customer: null,
        email_customer: null,
        no_telp_customer: null,
        no_ktp_customer: null,
        dokumen_pendukung: null,
      },
      deleteId: "",
      editId: "",
      image: require("@/assets/car.png"),
      namaRules: [(v) => !!v || "Nama is Required"],
      alamatRules: [(v) => !!v || "Alamat is Required"],
      ttlRules: [(v) => !!v || "Tanggal Lahir is Required"],
      genderRules: [(v) => !!v || "Jenis Kelamin is Required"],
      emailRules: [
        (v) => !!v || "Email is Required",
        (v) => /.+@.+\..+/.test(v) || "Email must be valid",
      ],
      telpRules: [
        (v) => !!v || "Nomor Telepon is Required",
        (v) => /^([0][8][0-9]{8,10})$/g.test(v) || "Phone Number must be valid",
      ],
      ktpRules: [
        (v) => !!v || "Nomor KTP is Required",
        (v) => /^([0-9]{16})$/g.test(v) || "Nomor KTP must be valid",
      ],
    };
  },
  methods: {
    refreshPage() {
      if (localStorage.getItem("reloaded")) {
        // The page was just reloaded. Clear the value from local storage
        // so that it will reload the next time this page is visited.
        localStorage.removeItem("reloaded");
      } else {
        // Set a flag so that we know not to reload the page twice.
        localStorage.setItem("reloaded", "1");
        location.reload();
      }
    },
    setForm() {
      if (this.inputType !== "Tambah") {
        this.update();
      } else {
        this.save();
      }
    },
    //read data mitra
    readData() {
      var url = this.$api + "/customer";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.customers = response.data.data;
        });
    },
    save() {
      this.customer.append("nama_customer", this.form.nama_customer);
      this.customer.append("alamat_customer", this.form.alamat_customer);
      this.customer.append(
        "tanggal_lahir_customer",
        this.form.tanggal_lahir_customer
      );
      this.customer.append(
        "jenis_kelamin_customer",
        this.form.jenis_kelamin_customer
      );
      this.customer.append("email_customer", this.form.email_customer);
      this.customer.append("no_telp_customer", this.form.no_telp_customer);
      this.customer.append("no_ktp_customer", this.form.no_ktp_customer);
      if (this.form.dokumen_pendukung != null) {
        this.customer.append("dokumen_pendukung", this.form.dokumen_pendukung);
      }

      var url = this.$api + "/customer/";
      this.load = true;
      this.$http
        .post(url, this.customer, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.updateTemp();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    updateTemp() {
      var url = this.$api + "/customerTemp";
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.readData();
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //ubah data mitra
    update() {
      let newData = {
        nama_customer: this.form.nama_customer,
        alamat_customer: this.form.alamat_customer,
        tanggal_lahir_customer: this.form.tanggal_lahir_customer,
        jenis_kelamin_customer: this.form.jenis_kelamin_customer,
        email_customer: this.form.email_customer,
        no_telp_customer: this.form.no_telp_customer,
        no_ktp_customer: this.form.no_ktp_customer,
        dokumen_pendukung: this.form.dokumen_pendukung,
      };

      var url = this.$api + "/customer/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.resetForm();
          this.inputType = "Tambah";
          this.refreshPage();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    onImageChange(e) {
      const files = e.target.files || e.dataTransfer.files;
      if (!files.length) {
        return;
      }
      this.createImage(files[0]);
    },

    createImage(file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        this.form.dokumen_pendukung = e.target.result;
      };
      reader.readAsDataURL(file);
    },
    editHandler(item) {
      this.inputType = "Edit";
      this.editId = item.id_customer;
      this.form.nama_customer = item.nama_customer;
      this.form.alamat_customer = item.alamat_customer;
      this.form.tanggal_lahir_customer = item.tanggal_lahir_customer;
      this.form.jenis_kelamin_customer = item.jenis_kelamin_customer;
      this.form.email_customer = item.email_customer;
      this.form.no_telp_customer = item.no_telp_customer;
      this.form.no_ktp_customer = item.no_ktp_customer;
      this.form.dokumen_pendukung = item.dokumen_pendukung;
      this.dialog = true;
    },
    readHandler(item) {
      this.form.id_customer = item.id_customer;
      this.form.nama_customer = item.nama_customer;
      this.form.alamat_customer = item.alamat_customer;
      this.form.tanggal_lahir_customer = item.tanggal_lahir_customer;
      this.form.jenis_kelamin_customer = item.jenis_kelamin_customer;
      this.form.email_customer = item.email_customer;
      this.form.no_telp_customer = item.no_telp_customer;
      this.form.no_ktp_customer = item.no_ktp_customer;
      this.form.dokumen_pendukung = item.dokumen_pendukung;
      this.dialogRead = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    printHandler(item) {
      this.form.id_customer = item.id_customer;
      this.form.nama_customer = item.nama_customer;
      this.form.alamat_customer = item.alamat_customer;
      this.form.email_customer = item.email_customer;
      this.form.no_telp_customer = item.no_telp_customer;
      this.dialogPrint = true;
    },
    close() {
      this.dialog = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.dialogPrint = false;
      this.resetForm();
      this.readData();
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_customer: null,
        nama_customer: null,
        alamat_customer: null,
        tanggal_lahir_customer: null,
        jenis_kelamin_customer: null,
        email_customer: null,
        no_telp_customer: null,
        no_ktp_customer: null,
        dokumen_pendukung: null,
      };
    },

    exportPDF() {
      var report;
      var reportName = "";

      report = document.getElementById("KartuCustomer");
      reportName = "KartuCustomer_" + this.form.id_customer;

      html2PDF(report, {
        jsPDF: {
          format: "a4",
        },
        margin: {
          top: 0,
          right: 0,
          bottom: 0,
          left: -2.5,
        },
        html2canvas: {
          scrollX: 0,
          scrollY: 0,
        },

        imageType: "image/jpeg",
        output: reportName + ".pdf",
      });

      this.close();
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Customer");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readData();
    this.updateTemp();
  },
};
</script>

<style scoped></style>
