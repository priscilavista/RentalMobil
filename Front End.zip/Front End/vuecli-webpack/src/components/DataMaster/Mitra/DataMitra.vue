<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-btn
      text
      large
      @click="moveMitra"
      style="float: left; margin-left: -30px; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Data Mitra</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>

        <v-btn
          color="success"
          dark
          @click="dialog = true"
          style="margin-right: 48px; margin-top: 20px"
          >Add Mitra</v-btn
        >
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="mitras"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <!-- <v-btn small class="mr-2" @click="editHandler(item)"
            ><v-icon color="#F2C031">mdi-pencil</v-icon></v-btn
          >
          <v-btn small @click="deleteHandler(item.id)">delete</v-btn> -->
          <v-menu offset-y style="float: left">
            <template v-slot:activator="{ on, attrs }">
              <span v-bind="attrs" v-on="on" style="cursor: pointer">
                <v-chip link color="#E7C913">
                  <v-icon>mdi-circle-edit-outline</v-icon>
                </v-chip>
              </span>
            </template>
            <v-list width="90" class="py-0" style="margin-top: 20px">
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title style="color: #000000" link>
                    <v-btn small @click="readHandler(item)"
                      ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="editHandler(item)"
                      ><v-icon color="#E39348">mdi-pencil</v-icon></v-btn
                    ></v-list-item-title
                  >
                  <v-list-item-title style="color: #000000; margin-top: 10px"
                    ><v-btn small @click="deleteHandler(item.id_mitra)"
                      ><v-icon color="#C94141"
                        >mdi-account-remove</v-icon
                      ></v-btn
                    ></v-list-item-title
                  >
                </v-list-item-content>
              </v-list-item>
            </v-list>
          </v-menu>
        </template>
      </v-data-table>
    </v-card>

    <v-dialog
      v-model="dialogRead"
      persistent
      max-width="600px"
      style="padding: 20px; padding-top: 20px"
    >
      <v-card>
        <!-- <v-card-title style="float: none">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </v-card-title> -->
        <div mt="3">
          <p class="headline" style="text-align: center">Data Mitra</p>
        </div>

        <v-card-text>
          <v-container>
            <v-text-field
              disabled
              label="ID"
              v-model="form.id_mitra"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.nama_mitra"
              label="Nama"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.no_ktp_mitra"
              label="Nomor KTP"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.alamat_mitra"
              label="Alamat"
            ></v-text-field>
            <v-text-field
              disabled
              v-model="form.no_telp_mitra"
              label="Nomor Telepon"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="cancel">Close</v-btn>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialog" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">{{ formTitle }} Data Mitra</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              :rules="namaRules"
              v-model="form.nama_mitra"
              label="Nama"
              required
            ></v-text-field>
            <v-text-field
              :rules="ktpRules"
              v-model="form.no_ktp_mitra"
              label="Nomor KTP"
              required
              type="number"
            ></v-text-field>
            <v-text-field
              :rules="alamatRules"
              v-model="form.alamat_mitra"
              label="Alamat"
              required
            ></v-text-field>
            <v-text-field
              :rules="telpRules"
              v-model="form.no_telp_mitra"
              label="Nomor Telepon"
              required
              type="number"
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setForm">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogConfirm" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline"></span>
        </v-card-title>
        <v-card-text> Anda Yakin ingin menghapus data ini? </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="deleteData">Delete</v-btn>
          <v-btn color="blue darken-1" text @click="dialogConfirm = false"
            >Cancel</v-btn
          >
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Mitra",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Mitra";
      },
    },
  },
  data() {
    return {
      inputType: "Tambah",
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      dialog: false,
      dialogConfirm: false,
      dialogRead: false,
      temp: 0,
      headers: [
        {
          text: "Nama",
          align: "start",
          sortable: true,
          value: "nama_mitra",
        },
        { text: "Nomor KTP", value: "no_ktp_mitra" },
        { text: "Alamat", value: "alamat_mitra" },
        { text: "Nomor Telepon", value: "no_telp_mitra" },
        { text: "Actions", value: "actions" },
      ],
      menus: [{ title: "Check" }, { title: "Edit" }, { title: "Delete" }],
      mitra: new FormData(),
      mitras: [],
      form: {
        id_mitra: null,
        nama_mitra: null,
        no_ktp_mitra: null,
        alamat_mitra: null,
        no_telp_mitra: null,
      },
      deleteId: "",
      editId: "",
      namaRules: [(v) => !!v || "Nama is Required"],
      ktpRules: [
        (v) => !!v || "Nomor KTP is Required",
        (v) => /^([0-9]{16})$/g.test(v) || "Nomor KTP must be valid",
      ],
      alamatRules: [(v) => !!v || "Alamat is Required"],
      telpRules: [
        (v) => !!v || "Nomor Telepon is Required",
        (v) => /^([0][8][0-9]{8,10})$/g.test(v) || "Phone Number must be valid",
      ],
    };
  },
  methods: {
    moveMitra() {
      this.$router.push({ path: "/mitra" });
    },
    setForm() {
      if (this.inputType !== "Tambah") {
        this.update();
      } else {
        this.save();
      }
    },
    //read data mitra
    readData() {
      var url = this.$api + "/mitraRead";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.mitras = response.data.data;
        });
    },
    save() {
      this.mitra.append("nama_mitra", this.form.nama_mitra);
      this.mitra.append("no_ktp_mitra", this.form.no_ktp_mitra);
      this.mitra.append("alamat_mitra", this.form.alamat_mitra);
      this.mitra.append("no_telp_mitra", this.form.no_telp_mitra);

      var url = this.$api + "/mitra/";
      this.load = true;
      this.$http
        .post(url, this.mitra, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.close();
          this.updateTemp();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    updateTemp() {
      var url = this.$api + "/mitraTemp";
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.readData();
          this.readDataRemove(); // baca data
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //ubah data mitra
    update() {
      let newData = {
        nama_mitra: this.form.nama_mitra,
        no_ktp_mitra: this.form.no_ktp_mitra,
        alamat_mitra: this.form.alamat_mitra,
        no_telp_mitra: this.form.no_telp_mitra,
      };

      var url = this.$api + "/mitra/" + this.editId;
      this.load = true;
      this.$http
        .put(url, newData, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    //hapus data produk
    deleteData() {
      //menghapus data
      var url = this.$api + "/mitraDelete/" + this.deleteId;
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = false;
          this.close();
          this.readData(); // baca data
          this.readDataRemove();
          this.resetForm();
          this.inputType = "Tambah";
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    editHandler(item) {
      this.inputType = "Edit";
      this.editId = item.id_mitra;
      this.form.nama_mitra = item.nama_mitra;
      this.form.no_ktp_mitra = item.no_ktp_mitra;
      this.form.alamat_mitra = item.alamat_mitra;
      this.form.no_telp_mitra = item.no_telp_mitra;
      this.dialog = true;
    },
    readHandler(item) {
      this.form.id_mitra = item.id_mitra;
      this.form.nama_mitra = item.nama_mitra;
      this.form.no_ktp_mitra = item.no_ktp_mitra;
      this.form.alamat_mitra = item.alamat_mitra;
      this.form.no_telp_mitra = item.no_telp_mitra;
      this.dialogRead = true;
    },
    deleteHandler(id) {
      this.deleteId = id;
      this.dialogConfirm = true;
    },
    close() {
      this.dialog = false;
      this.inputType = "Tambah";
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.readData();
    },
    cancel() {
      this.resetForm();
      this.readData();
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.inputType = "Tambah";
    },
    resetForm() {
      this.form = {
        id_mitra: null,
        nama_mitra: null,
        no_ktp_mitra: null,
        alamat_mitra: null,
        no_telp_mitra: null,
      };
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Mitra");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readData();
  },
};
</script>

<style scoped></style>
