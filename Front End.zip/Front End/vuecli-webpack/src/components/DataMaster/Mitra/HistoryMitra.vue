<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-btn
      text
      large
      @click="moveMitra"
      style="float: left; margin-left: -30px; margin-top: -30px"
      ><v-icon large color="#1B3963">mdi-chevron-left-circle</v-icon></v-btn
    >
    <br /><br />
    <br />
    <h5 style="font-size: 30px">Deleted Data</h5>

    <v-card>
      <v-card-title style="margin-top: 25px">
        <v-text-field
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
          style="margin-left: 30px"
        >
        </v-text-field>

        <v-spacer></v-spacer>
      </v-card-title>

      <v-data-table
        :headers="headers"
        :items="mitrasR"
        :search="search"
        style="margin-left: 30px"
      >
        <template v-slot:[`item.actions`]="{ item }">
          <v-btn small class="mr-2" @click="recoverData(item)">Recover</v-btn>
        </template>
      </v-data-table>
    </v-card>

    <v-snackbar v-model="snackbar" :color="color" timeout="2000" bottom
      >{{ error_message }}
    </v-snackbar>
  </v-main>
</template>

<script>
export default {
  name: "Mitra",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Mitra";
      },
    },
  },
  data() {
    return {
      load: false,
      snackbar: false,
      error_message: "",
      color: "",
      search: null,
      temp: 0,
      headers: [
        {
          text: "Nama",
          align: "start",
          sortable: true,
          value: "nama_mitra",
        },
        { text: "Nomor KTP", value: "no_ktp_mitra" },
        { text: "Alamat", value: "alamat_mitra" },
        { text: "Nomor Telepon", value: "no_telp_mitra" },
        { text: "Actions", value: "actions" },
      ],
      mitrasR: [],
    };
  },
  methods: {
    moveMitra() {
      this.$router.push({ path: "/mitra" });
    },
    readDataRemove() {
      var url = this.$api + "/mitraRemove";
      this.$http
        .get(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.mitrasR = response.data.data;
        });
    },
    updateTemp() {
      var url = this.$api + "/mitraTemp";
      this.load = true;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.color = "green";
          this.snackbar = true;
          this.load = true;
          this.readData();
          this.readDataRemove(); // baca data
          this.resetForm();
        })
        .catch((error) => {
          this.error_message = error.response.data.message;
          this.color = "red";
          this.snackbar = true;
          this.load = false;
        });
    },
    recoverData(item) {
      var url = this.$api + "/mitraRecover/" + item.id_mitra;
      this.$http
        .put(url, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then((response) => {
          this.error_message = response.data.message;
          this.close();
          this.readDataRemove();
        });
    },
    close() {
      this.dialog = false;
      this.dialogConfirm = false;
      this.dialogRead = false;
      this.readDataRemove();
    },
  },
  computed: {
    formTitle() {
      return this.inputType;
    },
  },
  mounted() {
    localStorage.setItem("menu", "Mitra");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.readDataRemove();
  },
};
</script>

<style scoped></style>
