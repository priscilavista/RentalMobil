<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 60px; max-width: 1500px"
  >
    <v-container>
      <v-row>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Mobil</div>
              <p class="text-h5 text--primary">Mobil Perusahaan</p>
              <p>(data)</p>
              <div class="text--primary">
                Menyediakan data aset: <br />
                Mobil Perusahaan
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveAsetPerusahaan"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Mobil</div>
              <p class="text-h5 text--primary">Mobil Mitra</p>
              <p>(data)</p>
              <div class="text--primary">
                Menyediakan data aset: <br />
                Mobil Mitra
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="deep-purple accent-4" @click="moveAsetMitra">
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Mobil</div>
              <p class="text-h5 text--primary">Ketersediaan Mobil</p>
              <p>(informasi)</p>
              <div class="text--primary">
                Menyediakan informasi mengenai <br />
                ketersediaan mobil
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveKetersediaan"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
      <v-row>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Mobil</div>
              <p class="text-h5 text--primary">Akan Habis Kontrak</p>
              <p>(pengingat)</p>
              <div class="text--primary">
                Sebagai pengingat kontrak mobil mitra <br />yang akan habis
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveAkanHabisKontrak"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Mobil</div>
              <p class="text-h5 text--primary">Habis Kontrak</p>
              <p>(informasi)</p>
              <div class="text--primary">
                Menyediakan informasi mobil mitra <br />
                yang masa kontrak sudah habis
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="moveHabisKontrak"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Mobil</div>
              <p class="text-h5 text--primary">History Mobil</p>
              <p>(history)</p>
              <div class="text--primary">
                Menyediakan informasi mengenai <br />
                data mobil yang sudah dihapus
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="deep-purple accent-4" @click="moveHistory">
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-main>
</template>

<script>
export default {
  name: "Mobil",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Mobil";
      },
    },
  },
  data() {
    return {};
  },
  methods: {
    moveAsetPerusahaan() {
      this.$router.push({ path: "/mobil/perusahaan" });
    },
    moveAsetMitra() {
      this.$router.push({ path: "/mobil/mitra" });
    },
    moveKetersediaan() {
      this.$router.push({ path: "/mobil/ketersediaan" });
    },
    moveAkanHabisKontrak() {
      this.$router.push({ path: "/mobil/kontrakAkanHabis" });
    },
    moveHabisKontrak() {
      this.$router.push({ path: "/mobil/kontrakHabis" });
    },
    moveHistory() {
      this.$router.push({ path: "/mobil/history" });
    },
  },
  mounted() {
    localStorage.setItem("menu", "Mobil");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
  },
};
</script>

<style scoped></style>
