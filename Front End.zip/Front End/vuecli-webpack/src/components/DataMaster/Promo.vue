<template>
  <v-main
    class="list"
    style="margin: auto; margin-top: 160px; max-width: 1500px"
  >
    <v-container>
      <v-row>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Promo</div>
              <p class="text-h5 text--primary">Data Promo Aktif</p>
              <p>(data)</p>
              <div class="text--primary">Menyediakan data promo aktif</div>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="deep-purple accent-4" @click="movePromoAktif">
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Promo</div>
              <p class="text-h5 text--primary">Data Promo Kadaluwarsa</p>
              <p>(data)</p>
              <div class="text--primary">
                Menyediakan data promo kadaluwarsa
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn
                text
                color="deep-purple accent-4"
                @click="movePromoKadaluwarsa"
              >
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
        <v-col>
          <v-card class="mx-auto" max-width="344">
            <v-card-text>
              <div>Sub Menu Promo</div>
              <p class="text-h5 text--primary">History Promo</p>
              <p>(history)</p>
              <div class="text--primary">
                Menyediakan data promo yang sudah dihapus
              </div>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="deep-purple accent-4" @click="moveHistory">
                For Access
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
  </v-main>
</template>

<script>
export default {
  name: "Promo",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Promo";
      },
    },
  },
  data() {
    return {};
  },
  methods: {
    movePromoAktif() {
      this.$router.push({ path: "/promo/aktif" });
    },
    movePromoKadaluwarsa() {
      this.$router.push({ path: "/promo/kadaluwarsa" });
    },
    moveHistory() {
      this.$router.push({ path: "/promo/history" });
    },
  },
  mounted() {
    localStorage.setItem("menu", "Promo");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
  },
};
</script>

<style scoped></style>
