<template>
  <div class="dashboard">
    <v-navigation-drawer v-model="drawer" app>
      <div class="">
        <v-sheet color="#ffffff" class="pa-4">
          <div class="text-center mt-4">
            <v-avatar class="mb-4" color="grey darken-1" size="94">
              <v-img aspect-ratio="30" :src="img" />
            </v-avatar>

            <h3>{{ pegawaiLogin }}</h3>
          </div>
        </v-sheet>

        <v-divider></v-divider>

        <v-list dense class="fullheight" style="margin-top: -10px">
          <span v-if="jabatan == 1">
            <v-list-item
              v-for="item in routeM"
              :key="item.title"
              link
              tag="router-link"
              :to="item.to"
              color="#1B3963"
              style="margin-top: 10px"
            >
              <v-list-item-icon>
                <v-icon v-text="item.icon"></v-icon>
              </v-list-item-icon>
              <v-list-item-content style="text-align: left">
                <v-list-item-title>{{ item.title }}</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </span>
          <span v-if="jabatan == 2">
            <v-list-item
              v-for="item in routeA"
              :key="item.title"
              link
              tag="router-link"
              :to="item.to"
              color="#1B3963"
              style="margin-top: 10px"
            >
              <v-list-item-icon>
                <v-icon v-text="item.icon"></v-icon>
              </v-list-item-icon>
              <v-list-item-content style="text-align: left">
                <v-list-item-title>{{ item.title }}</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </span>
          <span v-if="jabatan == 3">
            <v-list-item
              v-for="item in routeCS"
              :key="item.title"
              link
              tag="router-link"
              :to="item.to"
              color="#1B3963"
              style="margin-top: 10px"
            >
              <v-list-item-icon>
                <v-icon v-text="item.icon"></v-icon>
              </v-list-item-icon>
              <v-list-item-content style="text-align: left">
                <v-list-item-title>{{ item.title }}</v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </span>
        </v-list>
      </div>
    </v-navigation-drawer>
    <v-app-bar app elevate-on-scroll elevation="4" color="#1B3963">
      <v-app-bar-nav-icon
        @click.stop="drawer = !drawer"
        color="#ffffff"
      ></v-app-bar-nav-icon>
      <h3
        style="
          color: #ffffff;
          font-family: arial;
          font-size: 24px;
          margin-top: 2px;
          margin-left: 10px;
        "
      >
        {{ menuTitle }}
      </h3>
      <v-spacer />

      <v-spacer />
      <v-menu offset-y>
        <template v-slot:activator="{ on, attrs }">
          <span
            v-bind="attrs"
            v-on="on"
            style="cursor: pointer"
            class="mx-5 mr-10"
          >
            <v-chip link color="#ffffff">
              <v-icon>mdi-dots-horizontal</v-icon>
            </v-chip>
          </span>
        </template>
        <v-list
          width="250"
          class="py-0"
          style="margin-top: 20px; background-color: #eeeeee"
        >
          <v-list-item>
            <v-list-item-content>
              <!-- <v-list-item-title style="color: #000000" link>
                <v-btn small @click="readHandler(item)"
                  ><v-icon color="#08959D">mdi-eye-outline</v-icon></v-btn
                ></v-list-item-title
              > -->
              <v-list-item-title style="color: #000000; margin-top: 5px">
                <v-btn text @click="dialogChangePassword = true"
                  >Change Password</v-btn
                ></v-list-item-title
              >

              <v-list-item-title
                style="color: #000000; margin-top: 5px; margin-bottom: 5px"
              >
                <v-btn text @click="dialogLogout = true"
                  >Logout</v-btn
                ></v-list-item-title
              >
              <!-- <v-list-item-title style="color: #000000; margin-top: 10px"
                ><v-btn small @click="dialogLogout = true"
                  >Logout</v-btn
                ></v-list-item-title
              > -->
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-app-bar>
    <div class="fullheight pa-5">
      <router-view></router-view>
    </div>

    <v-dialog v-model="dialogChangePassword" persistent max-width="600px">
      <v-card>
        <v-card-title>
          <!-- <v-spacer></v-spacer> -->
          <span class="headline">Change Password</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              v-model="form.email"
              label="Email"
              :rules="emailRules"
              required
            ></v-text-field>
            <v-text-field
              v-model="form.oldPassword"
              label="Old Password"
              :rules="passwordRules"
              counter
              required
            ></v-text-field>
            <v-text-field
              v-model="form.newPassword"
              label="New Password"
              :rules="passwordRules"
              counter
              required
            ></v-text-field>
          </v-container>
        </v-card-text>
        <v-card-action>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="savePassword">Save</v-btn>
          <v-btn color="blue darken-1" text @click="cancel">Cancel</v-btn>
          <v-spacer></v-spacer>
        </v-card-action>
      </v-card>
    </v-dialog>

    <v-dialog v-model="dialogLogout" persistent max-width="400px">
      <v-card>
        <v-card-title>
          <span class="headline">Logout!</span>
        </v-card-title>

        <v-card-text>Are You Sure to Logout?</v-card-text>

        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="setLogout()">Yes</v-btn>
          <v-btn color="blue darken-1" text @click="dialogLogout = false"
            >No</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-snackbar v-model="snackbar" :color="color" timeout="750" bottom>{{
      error_message
    }}</v-snackbar>
  </div>
</template>

<script>
export default {
  name: "Dashboard",
  data() {
    return {
      menuTitle: localStorage.getItem("menu"),
      jabatan: localStorage.getItem("jabatan"),
      pegawaiLogin: localStorage.getItem("namaPegawai"),
      emailLogin: localStorage.getItem("email"),
      passwordLogin: localStorage.getItem("password"),
      dialogLogout: false,
      dialogChangePassword: false,
      error_message: "",
      color: "",
      snackbar: false,
      drawer: true,
      img: require("@/assets/logoajr.jpg"),
      routeA: [
        { title: "Dashboard", icon: "mdi-home", to: "/dashboard" },
        { title: "Mobil", icon: "mdi-car", to: "/mobil" },
        { title: "Mitra", icon: "mdi-handshake", to: "/mitra" },
        { title: "Pegawai", icon: "mdi-account-tie", to: "/pegawai" },
        { title: "Driver", icon: "mdi-card-account-details", to: "/driver" },
      ],
      routeM: [
        { title: "Dashboard", icon: "mdi-home", to: "/dashboard" },
        {
          title: "Brosur",
          icon: "mdi-file-document-multiple-outline",
          to: "/brosur",
        },
        { title: "Promo", icon: "mdi-sale", to: "/promo" },
        {
          title: "Jadwal Pegawai",
          icon: "mdi-calendar-clock",
          to: "/jadwalPegawai",
        },
      ],
      routeCS: [
        { title: "Dashboard", icon: "mdi-home", to: "/dashboard" },
        { title: "Customer", icon: "mdi-account-group", to: "/customer" },
        { title: "Transaksi", icon: "mdi-cash-multiple", to: "/transaksi" },
      ],
      menus: [
        { title: "Change Password", icon: "mdi-key" },
        { title: "Logout", icon: "mdi-logout" },
      ],
      emailRules: [
        (v) => !!v || "Email is Required",
        (v) => /.+@.+\..+/.test(v) || "Email must be valid",
      ],
      passwordRules: [(v) => !!v || "Password is Required"],
      form: {
        email: "",
        oldPassword: "",
        newPassword: "",
      },
    };
  },
  methods: {
    setLogout() {
      this.error_message = "Thank You";
      this.color = "green";
      this.snackbar = true;
      setTimeout(() => this.logout(), 750);
    },

    logout() {
      localStorage.removeItem("id");
      localStorage.removeItem("password");
      localStorage.removeItem("jabatan");
      localStorage.removeItem("email");
      localStorage.removeItem("namaPegawai");
      this.dialogLogout = false;
      this.$router.push({ path: "/login" });
    },

    cancel() {
      this.resetForm();
      this.dialogChangePassword = false;
    },

    close() {
      this.dialogChangePassword = false;
      this.dialogLogout = false;
    },

    savePassword() {
      if (this.form.email != localStorage.getItem("email")) {
        this.error_message = "Email Doesn't Match";
        this.color = "red";
        this.snackbar = true;
      } else if (this.form.oldPassword != localStorage.getItem("password")) {
        this.error_message = "Old Password Doesn't Match";
        this.color = "red";
        this.snackbar = true;
      } else {
        let newData = {
          password_pegawai: this.form.newPassword,
        };
        var url = this.$api + "/pegawaiEditPass/" + localStorage.getItem("id");
        this.load = true;
        this.$http
          .put(url, newData, {
            headers: {
              Authorization: "Bearer " + localStorage.getItem("token"),
            },
          })
          .then((response) => {
            this.error_message = response.data.message;
            this.color = "green";
            this.snackbar = true;
            this.load = false;
            this.close();
            localStorage.removeItem("password");
            localStorage.setItem("password", this.form.newPassword);
            this.resetForm();
          })
          .catch((error) => {
            this.error_message = error.response.data.message;
            this.color = "red";
            this.snackbar = true;
            this.load = false;
          });
      }
    },

    resetForm() {
      this.form = {
        email: null,
        oldPassword: null,
        newPassword: null,
      };
    },
  },
};
</script>

<style scoped>
.fullheight {
  min-height: 74.5vh !important;
}
</style>
