<template>
  <v-main>
    <div class="dashboard" style="margin-top: 138px">
      <br />
      <v-card
        elevation="2"
        class="rounded-lg"
        style="
          max-width: 1500px;
          max-height: 1500px;
          margin: auto;
          margin-top: -60px;
          padding-top: 20px;
          padding-left: 30px;
          padding-right: 30px;
          padding-bottom: 35px;
        "
        color="#1B3963"
      >
        <div>
          <v-col lg="4" style="margin-left: -12px">
            <v-alert dense text type="success" style="font-size: 14px">
              Login Successfully! Welcome to <v-spacer /><strong
                >Atma Jogja Rental</strong
              >
            </v-alert>
          </v-col>
          <v-row>
            <v-col lg="12" cols="6">
              <v-row>
                <v-col
                  lg="4"
                  cols="6"
                  v-for="(item, index) in activityLog"
                  :key="index"
                >
                  <v-card elevation="2" class="rounded-lg">
                    <v-card-text
                      class="d-flex justify-space-between align-center"
                    >
                      <div>
                        <strong style="font-size: 16px; float: left">{{
                          item.title
                        }}</strong>
                        <br />
                        <span style="font-size: 14px"
                          >Penanggung Jawab:
                          <strong>{{ item.pj }}</strong></span
                        >
                      </div>
                      <v-avatar
                        size="60"
                        :color="item.color"
                        style="border: 3px solid #444"
                      >
                        <span style="color: white">{{ item.amount }} +</span>
                      </v-avatar>
                    </v-card-text>
                    <v-card-actions class="d-flex justify-space-between">
                    </v-card-actions>
                  </v-card>
                </v-col>
              </v-row>
            </v-col>
          </v-row>
        </div>
      </v-card>
    </div>
  </v-main>
</template>

<script>
export default {
  name: "Dashboard",
  watch: {
    $route: {
      immediate: true,
      handler() {
        document.title = "Dashboard";
      },
    },
  },
  data() {
    return {
      activityLog: [
        {
          title: "Total Mobil",
          amount: localStorage.getItem("mobilCount"),
          icon: "mdi-account",
          color: "cyan lighten-1",
          pj: "Admin",
        },
        {
          title: "Total Mitra",
          amount: localStorage.getItem("mitraCount"),
          icon: "mdi-account-group-outline",
          color: "green darken-2",
          pj: "Admin",
        },
        {
          title: "Total Pegawai",
          amount: localStorage.getItem("pegawaiCount"),
          icon: "mdi-account-group-outline",
          color: "blue-grey darken-1",
          pj: "Admin",
        },
        {
          title: "Total Driver",
          amount: localStorage.getItem("driverCount"),
          icon: "mdi-account-group-outline",
          color: "deep-orange darken-1",
          pj: "Admin",
        },
        {
          title: "Total Customer",
          amount: localStorage.getItem("customerCount"),
          icon: "mdi-account-group-outline",
          color: "deep-purple darken-1",
          pj: "Customer Service",
        },
        {
          title: "Total Transaksi",
          amount: localStorage.getItem("transaksiCount"),
          icon: "mdi-account-group-outline",
          color: "brown darken-1",
          pj: "Customer Service",
        },
      ],
    };
  },
  methods: {
    countDataMobil() {
      this.$http
        .get(this.$api + "/mobilCount", {
          // headers: {
          //   Authorization: "Bearer " + localStorage.getItem("token"),
          // },
        })
        .then((response) => {
          localStorage.setItem("mobilCount", response.data.data);
        });
    },
    countDataMitra() {
      this.$http
        .get(this.$api + "/mitraCount", {
          // headers: {
          //   Authorization: "Bearer " + localStorage.getItem("token"),
          // },
        })
        .then((response) => {
          localStorage.setItem("mitraCount", response.data.data);
        });
    },
    countDataPegawai() {
      this.$http
        .get(this.$api + "/pegawaiCount", {
          // headers: {
          //   Authorization: "Bearer " + localStorage.getItem("token"),
          // },
        })
        .then((response) => {
          localStorage.setItem("pegawaiCount", response.data.data);
        });
    },
    countDataDriver() {
      this.$http
        .get(this.$api + "/driverCount", {
          // headers: {
          //   Authorization: "Bearer " + localStorage.getItem("token"),
          // },
        })
        .then((response) => {
          localStorage.setItem("driverCount", response.data.data);
        });
    },
    countDataCustomer() {
      this.$http
        .get(this.$api + "/customerCount", {
          // headers: {
          //   Authorization: "Bearer " + localStorage.getItem("token"),
          // },
        })
        .then((response) => {
          localStorage.setItem("customerCount", response.data.data);
        });
    },
    countDataTransaksi() {
      this.$http
        .get(this.$api + "/transaksiCount", {
          // headers: {
          //   Authorization: "Bearer " + localStorage.getItem("token"),
          // },
        })
        .then((response) => {
          localStorage.setItem("transaksiCount", response.data.data);
        });
    },
  },

  mounted() {
    localStorage.setItem("menu", "Dashboard");
    if (localStorage.getItem("reloaded")) {
      // The page was just reloaded. Clear the value from local storage
      // so that it will reload the next time this page is visited.
      localStorage.removeItem("reloaded");
    } else {
      // Set a flag so that we know not to reload the page twice.
      localStorage.setItem("reloaded", "1");
      location.reload();
    }
    this.countDataMobil();
    this.countDataMitra();
    this.countDataPegawai();
    this.countDataDriver();
    this.countDataCustomer();
    this.countDataTransaksi();
  },
};
</script>

<style scoped>
/* .overlap-icon {
  position: absolute;
  top: -33px;
  text-align: center;
  padding-top: 12px;
} */
</style>
