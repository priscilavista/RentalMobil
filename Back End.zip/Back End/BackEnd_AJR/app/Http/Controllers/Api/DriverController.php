<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Driver;
use Carbon\Carbon;

class DriverController extends Controller
{
    public function index()
    {
        $drivers = Driver::all();

        if (count($drivers)>0)
        {
            $drivers = Driver::orderBy('tanggal_mendaftar_driver')->orderBy('number_driver')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $drivers
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function read()
    {
        $drivers = Driver::all();

        if (count($drivers)>0)
        {
            $drivers = Driver::where('status_driver2', true)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $drivers
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function remove()
    {
        $drivers = Driver::all();

        if (count($drivers)>0)
        {
            $drivers = Driver::where('status_driver2', false)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $drivers
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $driver = Driver::where('id_driver',$id)->first();

        if (!is_null($driver))
        {
            return response([
                'message' => "Retrieve Driver Success",
                'data' => $driver
            ],200);
        }
        return response([
            'message' => "Driver Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'nama_driver' => 'required|string',
            'alamat_driver' => 'required|string',
            'tanggal_lahir_driver' => 'required|date',
            'jenis_kelamin_driver' => 'required',
            'email_driver' => 'required|email:rfc,dns|unique:driver',
            'no_telp_driver' => 'required|unique:driver|regex:/^([0][8][0-9]{8,11})$/u',
            'bahasa_driver' => 'required',
            'foto_driver' => 'nullable',
            'berkas_sim_driver' => 'nullable',
            'berkas_surat_bebasnapza_driver' => 'nullable',
            'berkas_surat_kesjiwa_driver' => 'nullable',
            'berkas_surat_kesjasmani_driver' => 'nullable',
            'berkas_skck_driver' => 'nullable',
            'tarif_driver' => 'required|numeric',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $storeData['status_driver'] = "Available";
        $storeData['status_driver2'] = true;
        $storeData['rating_performa_driver'] = 0;
        $storeData['password_driver'] = bcrypt($storeData['tanggal_lahir_driver']);   
        $storeData['tanggal_mendaftar_driver'] = Carbon::today()->format('Y-m-d');  

        $date = Carbon::today()->format('y-m-d');
        $year = Carbon::createFromFormat('y-m-d',$date)->format('y');
        $month = Carbon::createFromFormat('y-m-d',$date)->format('m');
        $day = Carbon::createFromFormat('y-m-d',$date)->format('d');
        $previousID = null;
        $previousID = Driver::select('id_driver')->where('tanggal_mendaftar_driver', $storeData['tanggal_mendaftar_driver'])->orderby('id_driver','desc')->first();
        if($previousID!=null)
        {
            $drv = Driver::where('tanggal_mendaftar_driver', $storeData['tanggal_mendaftar_driver'])->
                    orderBy('number_driver','desc')->first();
            
            // $temp = Driver::where('tanggal_mendaftar_driver', $storeData['tanggal_mendaftar_driver'])->count();
            $temp = $drv['number_driver'];
            $storeData['number_driver']  = $temp + 1;
            $generateID = 'DRV-'.$day.$month.$year.'00'.$storeData['number_driver'];
        }
        else
        {
            $storeData['number_driver'] = 1;
            $generateID = 'DRV-'.$day.$month.$year.'001';
        }
        
        $storeData['id_driver'] = $generateID;

        // if($request->foto_driver!=null)
        // {
        //     $file_image = time().'.'.$request->foto_driver->extension();
        //     $request->foto_driver->move(public_path('foto_driver'),$file_image);
        //     $path = "$file_image";
        //     $storeData['foto_driver'] = $path;
        // }

        // if($request->berkas_sim_driver!=null)
        // {
        //     $file_image = time().'.'.$request->berkas_sim_driver->extension();
        //     $request->berkas_sim_driver->move(public_path('berkas_sim_driver'),$file_image);
        //     $path = "$file_image";
        //     $storeData['berkas_sim_driver'] = $path;
        // }

        // if($request->berkas_surat_bebasnapza_driver!=null)
        // {
        //     $file_image = time().'.'.$request->berkas_surat_bebasnapza_driver->extension();
        //     $request->berkas_surat_bebasnapza_driver->move(public_path('berkas_surat_bebasnapza_driver'),$file_image);
        //     $path = "$file_image";
        //     $storeData['berkas_surat_bebasnapza_driver'] = $path;
        // }

        // if($request->berkas_surat_kesjiwa_driver!=null)
        // {
        //     $file_image = time().'.'.$request->berkas_surat_kesjiwa_driver->extension();
        //     $request->berkas_surat_kesjiwa_driver->move(public_path('berkas_surat_kesjiwa_driver'),$file_image);
        //     $path = "$file_image";
        //     $storeData['berkas_surat_kesjiwa_driver'] = $path;
        // }

        // if($request->berkas_surat_kesjasmani_driver!=null)
        // {
        //     $file_image = time().'.'.$request->berkas_surat_kesjasmani_driver->extension();
        //     $request->berkas_surat_kesjasmani_driver->move(public_path('berkas_surat_kesjasmani_driver'),$file_image);
        //     $path = "$file_image";
        //     $storeData['berkas_surat_kesjasmani_driver'] = $path;
        // }

        // if($request->berkas_skck_driver!=null)
        // {
        //     $file_image = time().'.'.$request->berkas_skck_driver->extension();
        //     $request->berkas_skck_driver->move(public_path('berkas_skck_driver'),$file_image);
        //     $path = "$file_image";
        //     $storeData['berkas_skck_driver'] = $path;
        // }

        $driver = Driver::create($storeData);
        return response([
            'message' => "Add Driver Success",
            'data' => $driver
        ],200);
    }

    public function temp(Request $request)
    {
        $driver = driver::all();
        if (count($driver)<0)
        {
            return response([
                'message' => "Driver Empty",
                'data' => null
            ],404);
        }

        $values = driver::where('temp_driver',null)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                driver::where('id_driver', $value['id_driver'])->update([
                    'temp_driver' => $value['id_driver'].'-'.$value['nama_driver']
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Update Driver Success",
        ],200);

    }

    public function destroy($id)
    {
        $driver = Driver::where('id_driver',$id)->first();

        if (is_null($driver))
        {
            return response([
                'message' => "Driver Not Found",
                'data' => null
            ],404);
        }

        if ($driver->delete())
        {
            return response([
                'message' => "Delete Driver Success",
                'data' => $driver
            ],200);
        }
        
        return response([
            'message' => "Delete Driver Failed",
            'data' => null
        ],400);
    }

    public function delete(Request $request, $id)
    {
        $driver = Driver::where('id_driver',$id)->first();
        if (is_null($driver))
        {
            return response([
                'message' => "Driver Not Found",
                'data' => null
            ],404);
        }

        Driver::where('id_driver', $id)->
        update([
            'status_driver2' => false
        ]);

        if ($driver->save())
        {
            return response([
                'message' => "Remove Driver Success",
                'data' => $driver
            ],200);
        }
        
        return response([
            'message' => "Remove Driver Failed",
            'data' => null
        ],400);
    }

    public function recover(Request $request, $id)
    {
        $driver = Driver::where('id_driver',$id)->first();
        if (is_null($driver))
        {
            return response([
                'message' => "Driver Not Found",
                'data' => null
            ],404);
        }

        Driver::where('id_driver', $id)->
        update([
            'status_driver2' => true
        ]);

        if ($driver->save())
        {
            return response([
                'message' => "Recover Driver Success",
                'data' => $driver
            ],200);
        }
        
        return response([
            'message' => "Recover Driver Failed",
            'data' => null
        ],400);
    }


    public function update(Request $request, $id)
    {
        $driver = Driver::where('id_driver',$id)->first();
        if (is_null($driver))
        {
            return response([
                'message' => "Driver Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'nama_driver' => 'required|string',
            'alamat_driver' => 'required|string',
            'tanggal_lahir_driver' => 'required|date',
            'jenis_kelamin_driver' => 'required',
            'email_driver' => ['required','email:rfc,dns', Rule::unique('driver')->ignore($id,'id_driver')],
            'no_telp_driver' => ['required','regex:/^([0][8][0-9]{8,11})$/u', Rule::unique('driver')->ignore($id, 'id_driver')],
            'bahasa_driver' => 'required',
            // 'foto_driver' => 'nullable',
            // 'berkas_sim_driver' => 'nullable',
            // 'berkas_surat_bebasnapza_driver' => 'nullable',
            // 'berkas_surat_kesjiwa_driver' => 'nullable',
            // 'berkas_surat_kesjasmani_driver' => 'nullable',
            // 'berkas_skck_driver' => 'nullable',
            'tarif_driver' => 'required|numeric',
            'status_driver' => 'required',
            // 'rating_performa_driver' => 'required|numeric',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        Driver::where('id_driver', $id)->
        update([
            'nama_driver' => $updateData['nama_driver'],
            'alamat_driver' => $updateData['alamat_driver'],
            'tanggal_lahir_driver' => $updateData['tanggal_lahir_driver'],
            'jenis_kelamin_driver' => $updateData['jenis_kelamin_driver'],
            'no_telp_driver' => $updateData['no_telp_driver'],
            'bahasa_driver' => $updateData['bahasa_driver'],
            'tarif_driver' => $updateData['tarif_driver'],
            'nama_driver' => $updateData['nama_driver'],
            'status_driver' => $updateData['status_driver'],
            'email_driver' => $updateData['email_driver'],
        ]);

        if ($driver->save())
        {
            return response([
                'message' => "Update Driver Success",
                'data' => $driver
            ],200);
        }
        
        return response([
            'message' => "Update Driver Failed",
            'data' => null
        ],400);
    }

    public function uploadImage(Request $request, $id)
    {
        $driver = Driver::where('id_driver',$id)->first();
        if (is_null($driver))
        {
            return response([
                'message' => "Driver Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'foto_driver' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        Driver::where('id_driver', $id)->
        update([
            'foto_driver' => $updateData['foto_driver'],
        ]);

        if ($driver->save())
        {
            return response([
                'message' => "Update Image Success",
                'data' => $driver
            ],200);
        }
        
        return response([
            'message' => "Update Image Failed",
            'data' => null
        ],400);
    }

    public function uploadBerkas(Request $request, $id)
    {
        $driver = Driver::where('id_driver',$id)->first();
        if (is_null($driver))
        {
            return response([
                'message' => "Driver Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'berkas_sim_driver' => 'nullable|string',
            'berkas_surat_bebasnapza_driver' => 'nullable|string',
            'berkas_surat_kesjiwa_driver' => 'nullable|string',
            'berkas_surat_kesjasmani_driver' => 'nullable|string',
            'berkas_skck_driver' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        Driver::where('id_driver', $id)->
        update([
            'berkas_sim_driver' => $updateData['berkas_sim_driver'],
            'berkas_surat_bebas_napza_driver' => $updateData['berkas_surat_bebasnapza_driver'],
            'berkas_surat_kesjiwa_driver' => $updateData['berkas_surat_kesjiwa_driver'],
            'berkas_surat_kesjasmani_driver' => $updateData['berkas_surat_kesjasmani_driver'],
            'berkas_skck_driver' => $updateData['berkas_skck_driver'],
        ]);

        if ($driver->save())
        {
            return response([
                'message' => "Update Berkas Success",
                'data' => $driver
            ],200);
        }
        
        return response([
            'message' => "Update Berkas Failed",
            'data' => null
        ],400);
    }

    public function editPassword(Request $request, $id)
    {
        $driver = Driver::where('id_driver',$id)->first();

        if(is_null($driver))
        {
            return response([
                'message' => 'Driver Not Found',
                'data' => null
            ], 404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData,
        [
            'password_driver' => 'required'
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $updateData['password_driver'] = bcrypt($request->password_driver);
        Driver::where('id_driver', $id)->
        update([
            'password_driver' => $updateData['password_driver']
        ]);

        if($driver->save())
        {
            return response(
                [
                    'message' => 'Password Has Been Updated',
                    'data' => $driver,
                ], 200);
        }

        return response(
            [
                'message' => 'Password Cannot Be Updated',
                'data' => null,
            ], 400);
    }

    public function count()
    {
        $drivers = Driver::all()->count();

        if ($drivers != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $drivers
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }
}
