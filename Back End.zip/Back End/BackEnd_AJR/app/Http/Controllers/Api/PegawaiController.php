<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Pegawai;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;


class PegawaiController extends Controller
{
    public function index()
    {
        $pegawais = Pegawai::all();

        if (count($pegawais)>0)
        {
            $pegawais = Pegawai::orderBy('tanggal_mendaftar_pegawai')->orderBy('number_pegawai')->get();

            return response([
                'message' => "Retrieve All Success",
                'data' => $pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function read()
    {
        $pegawais = Pegawai::all();

        if (count($pegawais)>0)
        {
            $pegawais = Pegawai::join('role', 'pegawai.id_role', '=', 'role.id_role')->
                    where('status_pegawai', true)->
                    select('pegawai.*','role.nama_role')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function remove()
    {
        $pegawais = Pegawai::all();

        if (count($pegawais)>0)
        {
            $pegawais = Pegawai::join('role', 'pegawai.id_role', '=', 'role.id_role')->
                    where('status_pegawai', false)->
                    select('pegawai.*','role.nama_role')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $pegawai = Pegawai::where('id_pegawai',$id)->first();

        if (!is_null($pegawai))
        {
            return response([
                'message' => "Retrieve Pegawai Success",
                'data' => $pegawai
            ],200);
        }
        return response([
            'message' => "Pegawai Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'id_role' => 'required',
            'nama_pegawai' => 'required|string', 
            'alamat_pegawai' => 'required|string',
            'tanggal_lahir_pegawai' => 'required|date',
            'jenis_kelamin_pegawai' => 'required',
            'email_pegawai' => 'required|email:rfc,dns|unique:pegawai',
            'no_telp_pegawai' => 'required|unique:pegawai|regex:/^([0][8][0-9]{8,11})$/u',
            'foto_pegawai' => 'nullable'
        ]);


        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $storeData['password_pegawai'] = bcrypt($storeData['tanggal_lahir_pegawai']); 
        $storeData['tanggal_mendaftar_pegawai'] = Carbon::today()->format('Y-m-d');  

        $date = Carbon::today()->format('y-m-d');
        $year = Carbon::createFromFormat('y-m-d',$date)->format('y');
        $month = Carbon::createFromFormat('y-m-d',$date)->format('m');
        $day = Carbon::createFromFormat('y-m-d',$date)->format('d');
        $previousID = null;
        $previousID = pegawai::select('id_pegawai')->where('tanggal_mendaftar_pegawai', $storeData['tanggal_mendaftar_pegawai'])->orderby('id_pegawai','desc')->first();
        if($previousID!=null)
        {
            $pgw = Pegawai::where('tanggal_mendaftar_pegawai', $storeData['tanggal_mendaftar_pegawai'])->
                    orderBy('number_pegawai','desc')->first();
            
            $temp = $pgw['number_pegawai'];
            $storeData['number_pegawai']  = $temp + 1;
            $generateID = 'PGW-'.$day.$month.$year.'000'.$storeData['number_pegawai'];
        }
        else
        {
            $storeData['number_pegawai'] = 1;
            $generateID = 'PGW-'.$day.$month.$year.'0001';
        }
        
        $storeData['id_pegawai'] = $generateID;
        $storeData['status_pegawai'] = true;

        if($request->foto_pegawai!=null)
        {
            $file_image = time().'.'.$request->foto_pegawai->extension();
            $request->foto_pegawai->move(public_path('foto_pegawai'),$file_image);
            $path = "$file_image";
            $storeData['foto_pegawai'] = $path;
        }

        $pegawai = Pegawai::create($storeData);
        return response([
            'message' => "Add Pegawai Success",
            'data' => $pegawai
        ],200);
    }

    public function temp(Request $request)
    {
        $pegawai = pegawai::all();
        if (count($pegawai)<0)
        {
            return response([
                'message' => "Pegawai Empty",
                'data' => null
            ],404);
        }

        $values = pegawai::where('temp_pegawai',null)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                pegawai::where('id_pegawai', $value['id_pegawai'])->update([
                    'temp_pegawai' => $value['id_pegawai'].'-'.$value['nama_pegawai']
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Update Pegawai Success",
        ],200);

    }

    public function destroy($id)
    {
        $pegawai = Pegawai::where('id_pegawai',$id)->first();

        if (is_null($pegawai))
        {
            return response([
                'message' => "Pegawai Not Found",
                'data' => null
            ],404);
        }

        if ($pegawai->delete())
        {
            return response([
                'message' => "Delete Pegawai Success",
                'data' => $pegawai
            ],200);
        }
        
        return response([
            'message' => "Delete Pegawai Failed",
            'data' => null
        ],400);
    }

    public function delete(Request $request, $id)
    {
        $pegawai = Pegawai::where('id_pegawai',$id)->first();
        if (is_null($pegawai))
        {
            return response([
                'message' => "Pegawai Not Found",
                'data' => null
            ],404);
        }

        Pegawai::where('id_pegawai', $id)->
        update([
            'status_pegawai' => false
        ]);

        if ($pegawai->save())
        {
            return response([
                'message' => "Remove Pegawai Success",
                'data' => $pegawai
            ],200);
        }
        
        return response([
            'message' => "Remove Pegawai Failed",
            'data' => null
        ],400);
    }

    public function recover(Request $request, $id)
    {
        $pegawai = Pegawai::where('id_pegawai',$id)->first();
        if (is_null($pegawai))
        {
            return response([
                'message' => "Pegawai Not Found",
                'data' => null
            ],404);
        }

        Pegawai::where('id_pegawai', $id)->
        update([
            'status_pegawai' => true
        ]);

        if ($pegawai->save())
        {
            return response([
                'message' => "Recover Pegawai Success",
                'data' => $pegawai
            ],200);
        }
        
        return response([
            'message' => "Recover Pegawai Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $pegawai = Pegawai::where('id_pegawai',$id)->first();
        if (is_null($pegawai))
        {
            return response([
                'message' => "Pegawai Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'id_role' => 'required',
            'nama_pegawai' => 'required|string',
            'alamat_pegawai' => 'required|string',
            'tanggal_lahir_pegawai' => 'required|date',
            'jenis_kelamin_pegawai' => 'required',
            'email_pegawai' => ['required','email:rfc,dns', Rule::unique('pegawai')->ignore($id, 'id_pegawai')],
            'no_telp_pegawai' => ['required','regex:/^([0][8][0-9]{8,11})$/u', Rule::unique('pegawai')->ignore($id, 'id_pegawai')],
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        Pegawai::where('id_pegawai', $id)->
        update([
            'id_role' => $updateData['id_role'],
            'nama_pegawai' => $updateData['nama_pegawai'],
            'alamat_pegawai' => $updateData['alamat_pegawai'],
            'tanggal_lahir_pegawai' => $updateData['tanggal_lahir_pegawai'],
            'jenis_kelamin_pegawai' => $updateData['jenis_kelamin_pegawai'],
            'email_pegawai' => $updateData['email_pegawai'],
            'no_telp_pegawai' => $updateData['no_telp_pegawai'],
            'temp_pegawai' => $id.'-'.$updateData['nama_pegawai']
        ]);


        if ($pegawai->save())
        {
            return response([
                'message' => "Update Pegawai Success",
                'data' => $pegawai
            ],200);
        }
        
        return response([
            'message' => "Update Pegawai Failed",
            'data' => null
        ],400);
    }

    public function editPassword(Request $request, $id)
    {
        $pegawai = Pegawai::where('id_pegawai',$id)->first();

        if(is_null($pegawai))
        {
            return response([
                'message' => 'Pegawai Not Found',
                'data' => null
            ], 404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData,
        [
            'password_pegawai' => 'required'
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $updateData['password_pegawai'] = bcrypt($request->password_pegawai);
        Pegawai::where('id_pegawai', $id)->
        update([
            'password_pegawai' => $updateData['password_pegawai']
        ]);

        if($pegawai->save())
        {
            return response(
                [
                    'message' => 'Password Has Been Updated',
                    'data' => $pegawai,
                ], 200);
        }

        return response(
            [
                'message' => 'Password Cannot Be Updated',
                'data' => null,
            ], 400);
    }

    public function count()
    {
        $pegawais = Pegawai::all()->count();

        if ($pegawais != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }

    public function uploadImage(Request $request, $id)
    {
        $pegawai = pegawai::where('id_pegawai',$id)->first();
        if (is_null($pegawai))
        {
            return response([
                'message' => "Pegawai Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'foto_pegawai' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        pegawai::where('id_pegawai', $id)->
        update([
            'foto_pegawai' => $updateData['foto_pegawai'],
        ]);

        if ($pegawai->save())
        {
            return response([
                'message' => "Update Image Success",
                'data' => $pegawai
            ],200);
        }
        
        return response([
            'message' => "Update Image Failed",
            'data' => null
        ],400);
    }
}
