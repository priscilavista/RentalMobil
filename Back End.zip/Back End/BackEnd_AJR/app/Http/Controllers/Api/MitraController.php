<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Mitra;

class MitraController extends Controller
{
    public function index()
    {
        $mitras = Mitra::all();

        if (count($mitras)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $mitras
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function read()
    {
        $mitras = Mitra::all();

        if (count($mitras)>0)
        {
            $mitras = Mitra::where('status_mitra', true)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mitras
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function remove()
    {
        $mitras = Mitra::all();

        if (count($mitras)>0)
        {
            $mitras = Mitra::where('status_mitra', false)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mitras
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $mitra = Mitra::find($id);

        if (!is_null($mitra))
        {
            return response([
                'message' => "Retrieve Mitra Success",
                'data' => $mitra
            ],200);
        }
        return response([
            'message' => "Mitra Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'nama_mitra' => 'required|string',
            'no_ktp_mitra' => 'required|unique:mitra|regex:/^([0-9]{16})$/u',
            'alamat_mitra' => 'required|string',
            'no_telp_mitra' => 'required|unique:mitra|regex:/^([0][8][0-9]{8,11})$/u',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $temp1 = $temp2 = null;
        // $temp1 = Mitra::where('no_ktp_mitra', $storeData['no_ktp_mitra'])->where('status_mitra', false)->first();
        // $temp2 = Mitra::where('no_telp_mitra', $storeData['no_telp_mitra'])->where('status_mitra', false)->first();

        // if ($temp1 != null and $temp2 !=null)
        // {
        //     return response([
        //         'message' => "Nomor KTP and Nomor Telepon is already registered in the system",
        //         'data' => null
        //     ],400);
        // }

        // if ($temp1 != null)
        // {
        //     return response([
        //         'message' => "Nomor KTP is already registered in the system",
        //         'data' => null
        //     ],400);
        // }

        // if ($temp2 != null)
        // {
        //     return response([
        //         'message' => "Nomor Telepon is already registered in the system",
        //         'data' => null
        //     ],400);
        // }

        $storeData['status_mitra'] = true;

        $mitra = Mitra::create($storeData);
        return response([
            'message' => "Add Mitra Success",
            'data' => $mitra
        ],200);
    }

    public function temp(Request $request)
    {
        $mitra = Mitra::all();
        if (count($mitra)<0)
        {
            return response([
                'message' => "Mitra Empty",
                'data' => null
            ],404);
        }

        $values = Mitra::where('temp_mitra',null)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                Mitra::where('id_mitra', $value['id_mitra'])->update([
                    'temp_mitra' => $value['id_mitra'].'-'.$value['nama_mitra']
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Update Mitra Success",
        ],200);

    }

    public function destroy($id)
    {
        $mitra = Mitra::find($id);

        if (is_null($mitra))
        {
            return response([
                'message' => "Mitra Not Found",
                'data' => null
            ],404);
        }

        if ($mitra->delete())
        {
            return response([
                'message' => "Delete Mitra Success",
                'data' => $mitra
            ],200);
        }
        
        return response([
            'message' => "Delete Mitra Failed",
            'data' => null
        ],400);
    }

    public function delete(Request $request, $id)
    {
        $mitra = Mitra::find($id);
        if (is_null($mitra))
        {
            return response([
                'message' => "Mitra Not Found",
                'data' => null
            ],404);
        }

        $mitra->status_mitra = false;

        if ($mitra->save())
        {
            return response([
                'message' => "Remove Mitra Success",
                'data' => $mitra
            ],200);
        }
        
        return response([
            'message' => "Remove Mitra Failed",
            'data' => null
        ],400);
    }

    public function recover(Request $request, $id)
    {
        $mitra = Mitra::find($id);
        if (is_null($mitra))
        {
            return response([
                'message' => "Mitra Not Found",
                'data' => null
            ],404);
        }

        $mitra->status_mitra = true;

        if ($mitra->save())
        {
            return response([
                'message' => "Recover Mitra Success",
                'data' => $mitra
            ],200);
        }
        
        return response([
            'message' => "Recover Mitra Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $mitra = Mitra::find($id);
        if (is_null($mitra))
        {
            return response([
                'message' => "Mitra Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'nama_mitra' => 'required|string',
            'no_ktp_mitra' => ['required','regex:/^([0-9]{16})$/u', Rule::unique('mitra')->ignore($id,'id_mitra')],
            'alamat_mitra' => 'required|string',
            'no_telp_mitra' => ['required','regex:/^([0][8][0-9]{8,11})$/u', Rule::unique('mitra')->ignore($id,'id_mitra')],
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        // $temp1 = $temp2 = null;
        // $temp1 = Mitra::where('no_ktp_mitra', $updateData['no_ktp_mitra'])->where('id_mitra', $id)->where('status_mitra', false)->first();
        // $temp2 = Mitra::where('no_telp_mitra', $updateData['no_telp_mitra'])->where('id_mitra', $id)->where('status_mitra', false)->first();

        // if ($temp1 != null and $temp2 !=null)
        // {
        //     return response([
        //         'message' => "Nomor KTP and Nomor Telepon is already registered in the system",
        //         'data' => null
        //     ],400);
        // }

        // if ($temp1 != null)
        // {
        //     return response([
        //         'message' => "Nomor KTP is already registered in the system",
        //         'data' => null
        //     ],400);
        // }

        // if ($temp2 != null)
        // {
        //     return response([
        //         'message' => "Nomor Telepon is already registered in the system",
        //         'data' => null
        //     ],400);
        // }

        $mitra->nama_mitra = $updateData['nama_mitra'];
        $mitra->no_ktp_mitra = $updateData['no_ktp_mitra'];
        $mitra->alamat_mitra = $updateData['alamat_mitra'];
        $mitra->no_telp_mitra = $updateData['no_telp_mitra'];
        $mitra->temp_mitra = $mitra['id_mitra'].'-'.$mitra['nama_mitra'];

        if ($mitra->save())
        {
            return response([
                'message' => "Update Mitra Success",
                'data' => $mitra
            ],200);
        }
        
        return response([
            'message' => "Update Mitra Failed",
            'data' => null
        ],400);
    }

    public function count()
    {
        $mitras = Mitra::all()->count();

        if ($mitras != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $mitras
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }
}
