<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Transaksi;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use DateTime;
use App\Models\Promo;
use App\Models\Pegawai;
use App\Models\Customer;
use App\Models\Mobil;
use App\Models\Driver;

class TransaksiController extends Controller
{
    public function index()
    {
        $transaksis = Transaksi::all();

        if (count($transaksis)>0)
        {
            $transaksis = Transaksi::orderBy('tanggal_transaksi')->orderBy('number_transaksi')->get();

            return response([
                'message' => "Retrieve All Success",
                'data' => $transaksis
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function readBerlangsung()
    {
        $transaksis = Transaksi::all();

        if (count($transaksis)>0)
        {
            $transaksis = Transaksi::leftjoin('promo', 'transaksi.id_promo', '=', 'promo.id_promo')->
                            join('customer', 'transaksi.id_customer', '=', 'customer.id_customer')->
                            join('pegawai', 'transaksi.id_pegawai', '=', 'pegawai.id_pegawai')->
                            leftjoin('driver', 'transaksi.id_driver', '=', 'driver.id_driver')->
                            join('mobil', 'transaksi.id_mobil', '=', 'mobil.id_mobil')->
                            orderBy('tanggal_transaksi')->orderBy('number_transaksi')->
                            where('tanggal_pengembalian_mobil', null)->
                            orWhere('status_pembayaran', false)->get();

            return response([
                'message' => "Retrieve All Success",
                'data' => $transaksis
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function readSelesai()
    {
        $transaksis = Transaksi::all();

        if (count($transaksis)>0)
        {
            $transaksis = Transaksi::leftjoin('promo', 'transaksi.id_promo', '=', 'promo.id_promo')->
                            join('customer', 'transaksi.id_customer', '=', 'customer.id_customer')->
                            join('pegawai', 'transaksi.id_pegawai', '=', 'pegawai.id_pegawai')->
                            leftjoin('driver', 'transaksi.id_driver', '=', 'driver.id_driver')->
                            join('mobil', 'transaksi.id_mobil', '=', 'mobil.id_mobil')->
                            orderBy('tanggal_transaksi')->orderBy('number_transaksi')->
                            where('tanggal_pengembalian_mobil', '!=', null)->
                            where('status_pembayaran', true)->get();

            return response([
                'message' => "Retrieve All Success",
                'data' => $transaksis
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $transaksi = Transaksi::find($id);

        if (!is_null($transaksi))
        {
            return response([
                'message' => "Retrieve Transaksi Success",
                'data' => $transaksi
            ],200);
        }
        return response([
            'message' => "Transaksi Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $storeData['tanggal_transaksi'] = Carbon::now()->format('Y-m-d H:i:s');
        $tanggal = Carbon::now()->format('Y-m-d');
        $validate = Validator::make($storeData, [
            'kode_promo' => 'nullable',
            'temp_customer' => 'required',
            'temp_pegawai' => 'required',
            'temp_driver' => 'nullable',
            'temp_mobil' => 'required',
            'tanggal_mulai_sewa' => 'required|date_format:Y-m-d H:i|after:tanggal_transaksi',
            'tanggal_selesai_sewa' => 'required|date_format:Y-m-d H:i|after:tanggal_mulai_sewa',
        ]);


        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        if($storeData['temp_driver'] != null)
        {
            $validate = Validator::make($storeData,
            [
                'tanggal_mulai_sewa' => 'required|date_format:Y-m-d H:i|after:tomorrow+1day',
            ]);

            if($validate->fails())
            {
                return response(['message' => $validate->errors()], 400);
            }
        }

        $pegawai = Pegawai::where('temp_pegawai',$storeData['temp_pegawai'])->first();
        $storeData['id_pegawai'] = $pegawai['id_pegawai'];

        $customer = Customer::where('temp_customer',$storeData['temp_customer'])->first();
        $storeData['id_customer'] = $customer['id_customer'];

        $mobil = Mobil::where('temp_mobil',$storeData['temp_mobil'])->first();
        $storeData['id_mobil'] = $mobil['id_mobil'];

        if($request->temp_driver != null)
        {
            $driver = Driver::where('temp_driver',$storeData['temp_driver'])->first();
            $storeData['id_driver'] = $driver['id_driver'];

            Driver::where('id_driver', $driver['id_driver'])->
            update([
                'status_driver' => 'Unavailable'
            ]);
        }

        Mobil::where('id_mobil', $mobil['id_mobil'])->
        update([
            'status_mobil' => 'Unavailable'
        ]);

        if($request->kode_promo != null)
        {
            $promo = Promo::where('kode_promo',$storeData['kode_promo'])->first();
            $storeData['id_promo'] = $promo['id_promo'];
        }

        $storeData['denda_sewa'] = 0; 
        $storeData['rating_driver'] = 0;
        $storeData['status_pembayaran'] = false;
        $storeData['cek_tanggal_transaksi'] = $tanggal;
        $storeData['verif_transaksi'] = false;

        $tgl2 = new DateTime(DateTime::createFromFormat('Y-m-d H:i', $storeData['tanggal_selesai_sewa'])->format('Y-m-d'));
        $tgl1 = new DateTime(DateTime::createFromFormat('Y-m-d H:i', $storeData['tanggal_mulai_sewa'])->format('Y-m-d'));
        $temp = $tgl2->diff($tgl1);
        $storeData['durasi_sewa'] = $temp->d;
        $storeData['subtotal_mobil'] = $mobil['harga_sewa_mobil']*$storeData['durasi_sewa'];
        if($request->temp_driver != null)
        {
            $storeData['subtotal_driver'] = $driver['tarif_driver']*$storeData['durasi_sewa'];
        }
        else
        {
            $storeData['subtotal_driver'] = 0;
        }
        $storeData['subtotal'] = $storeData['subtotal_mobil'] + $storeData['subtotal_driver'];
        if($request->kode_promo != null)
        {
            $storeData['diskon'] = ($storeData['subtotal_mobil'] + $storeData['subtotal_driver']) * ($promo['diskon_promo']/100);
            $storeData['total_transaksi'] = ($storeData['subtotal_mobil'] + $storeData['subtotal_driver']) * ((100-$promo['diskon_promo'])/100);
        }
        else{
            $storeData['diskon'] = 0;
            $storeData['total_transaksi'] = $storeData['subtotal_mobil'] + $storeData['subtotal_driver'];
        }

        $date = Carbon::today()->format('y-m-d');
        $year = Carbon::createFromFormat('y-m-d',$date)->format('y');
        $month = Carbon::createFromFormat('y-m-d',$date)->format('m');
        $day = Carbon::createFromFormat('y-m-d',$date)->format('d');
        $previous = null;
        $previous = Transaksi::where('cek_tanggal_transaksi', '=', $tanggal)->orderby('id_transaksi','desc')->first();
        if($previous!=null)
        {
            $trn = Transaksi::where('cek_tanggal_transaksi', '=', $tanggal)->
                    orderBy('number_transaksi','desc')->first();

            $temp = $trn['number_transaksi'];
            $storeData['number_transaksi']  = $temp + 1;
            if(is_null($storeData['id_driver']))
            {
                $generateID = 'TRN'.$year.$month.$day.'00'.'-00'.$storeData['number_transaksi'];
            }
            else{
                $generateID = 'TRN'.$year.$month.$day.'01'.'-00'.$storeData['number_transaksi'];
            }
            
        }
        else
        {
            $storeData['number_transaksi'] = 1;
            if(is_null($storeData['id_driver']))
            {
                $generateID = 'TRN'.$year.$month.$day.'00'.'-001';
            }
            else{
                $generateID = 'TRN'.$year.$month.$day.'01'.'-001';
            }
        }
        
        $storeData['id_transaksi'] = $generateID;

        $transaksi = Transaksi::create($storeData);
        return response([
            'message' => "Add Transaksi Success",
            'data' => $transaksi
        ],200);
    }

    public function destroy($id)
    {
        $transaksi = Transaksi::find($id);

        if (is_null($transaksi))
        {
            return response([
                'message' => "Transaksi Not Found",
                'data' => null
            ],404);
        }

        if ($transaksi->delete())
        {
            return response([
                'message' => "Delete Transaksi Success",
                'data' => $transaksi
            ],200);
        }
        
        return response([
            'message' => "Delete Transaksi Failed",
            'data' => null
        ],400);
    }

    public function uploadImage(Request $request, $id)
    {
        $transaksi = transaksi::where('id_transaksi',$id)->first();
        if (is_null($transaksi))
        {
            return response([
                'message' => "Transaksi Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'bukti_pembayaran' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        transaksi::where('id_transaksi', $id)->
        update([
            'bukti_pembayaran' => $updateData['bukti_pembayaran'],
        ]);

        if ($transaksi->save())
        {
            return response([
                'message' => "Update Image Success",
                'data' => $transaksi
            ],200);
        }
        
        return response([
            'message' => "Update Image Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $transaksi = Transaksi::where('id_transaksi',$id)->first();
        if (is_null($transaksi))
        {
            return response([
                'message' => "Transaksi Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'id_transaksi' => 'required|unique:transaksi', Rule::unique('transaksi')->ignore($transaksi),
            'id_promo' => 'required',
            'id_customer' => 'required',
            'id_pegawai' => 'required',
            'id_driver' => 'required',
            'id_mobil' => 'required',
            'tanggal_transaksi' => 'required|date',
            'tanggal_mulai_sewa' => 'required|date',
            'tanggal_selesai_sewa' => 'required|date',
            'tanggal_pengembalian_mobil' => 'required|date',
            'durasi_sewa' => 'required|numeric',
            'subtotal_mobil' => 'required|numeric',
            'subtotal_driver' => 'required|numeric',
            'total_transaksi' => 'required|numeric',
            'status_pembayaran' => 'required',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $transaksi->id_transaksi = $updateData['id_transaksi'];
        $transaksi->id_promo = $updateData['id_promo'];
        $transaksi->id_customer = $updateData['id_customer'];
        $transaksi->id_pegawai = $updateData['id_pegawai'];
        $transaksi->id_driver = $updateData['id_driver'];
        $transaksi->id_mobil = $updateData['id_mobil'];
        $transaksi->tanggal_transaksi = $updateData['tanggal_transaksi'];
        $transaksi->tanggal_mulai_sewa = $updateData['tanggal_mulai_sewa'];
        $transaksi->tanggal_selesai_sewa = $updateData['tanggal_selesai_sewa'];
        $transaksi->tanggal_pengembalian_mobil = $updateData['tanggal_pengembalian_mobil'];
        $transaksi->durasi_sewa = $updateData['durasi_sewa'];
        $transaksi->subtotal_mobil = $updateData['subtotal_mobil'];
        $transaksi->subtotal_driver = $updateData['subtotal_driver'];
        $transaksi->total_transaksi = $updateData['total_transaksi'];
        $transaksi->status_pembayaran = $updateData['status_pembayaran'];

        if ($transaksi->save())
        {
            return response([
                'message' => "Update Transaksi Success",
                'data' => $transaksi
            ],200);
        }
        
        return response([
            'message' => "Update Transaksi Failed",
            'data' => null
        ],400);
    }

    public function count()
    {
        $transaksis = Transaksi::all()->count();

        if ($transaksis != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $transaksis
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }

    public function verifTransaksi(Request $request, $id)
    {
        $transaksi = Transaksi::where('id_transaksi',$id)->first();
        if (is_null($transaksi))
        {
            return response([
                'message' => "Transaksi Not Found",
                'data' => null
            ],404);
        }

        Transaksi::where('id_transaksi', $id)->
        update([
            'verif_transaksi' => true,
        ]);

        if ($transaksi->save())
        {
            return response([
                'message' => "Verif Transaksi Success",
                'data' => $transaksi
            ],200);
        }
        
        return response([
            'message' => "Verif Transaksi Failed",
            'data' => null
        ],400);
    }

    public function verifPembayaran(Request $request, $id)
    {
        $transaksi = Transaksi::where('id_transaksi',$id)->first();
        if (is_null($transaksi))
        {
            return response([
                'message' => "Transaksi Not Found",
                'data' => null
            ],404);
        }

        Transaksi::where('id_transaksi', $id)->
        update([
            'status_pembayaran' => true,
        ]);

        if ($transaksi->save())
        {
            return response([
                'message' => "Verif Pembayaran Success",
                'data' => $transaksi
            ],200);
        }
        
        return response([
            'message' => "Verif Pembayaran Failed",
            'data' => null
        ],400);
    }

    public function pengembalianMobil(Request $request, $id)
    {
        $transaksi = Transaksi::where('id_transaksi',$id)->first();
        if (is_null($transaksi))
        {
            return response([
                'message' => "Transaksi Not Found",
                'data' => null
            ],404);
        }

        $tgl = Carbon::now()->format('Y-m-d H:i:s');
        $today = Carbon::now()->format('Y-m-d');
        // var_dump($today);
        // var_dump($transaksi['cek_tanggal_transaksi']);
        $selesai = Carbon::createFromFormat('Y-m-d H:i:s',$transaksi['tanggal_selesai_sewa'])->format('Y-m-d');
        if($today == $selesai && $tgl > $transaksi['tanggal_selesai_sewa'])
        {
            // $jam1 = new DateTime(DateTime::createFromFormat('Y-m-d H:i:s', $transaksi['tanggal_selesai_sewa'])->format('H:i:s'));
            // $jam2 = new DateTime(DateTime::createFromFormat('Y-m-d H:i:s', $tgl)->format('H:i:s'));
            $temp = Carbon::now()->diffInMinutes($transaksi['tanggal_selesai_sewa']);
            // $temp = $jam2->diffInMinutes($jam1);


            if($temp > 180)
            {
                $transaksi['denda_sewa'] = $transaksi['subtotal_mobil']/$transaksi['durasi_sewa'];
                if($transaksi['id_driver']!=null)
                {
                    $transaksi['denda_sewa'] = $transaksi['denda_sewa'] + ($transaksi['subtotal_driver']/$transaksi['durasi_sewa']);
                }
            }
        }
        else if($today > $selesai)
        {
            $temp = Carbon::now()->diffInDays($transaksi['tanggal_selesai_sewa']);
            $transaksi['denda_sewa'] = ($transaksi['subtotal_mobil']/$transaksi['durasi_sewa'])*$temp;
                if($transaksi['id_driver']!=null)
                {
                    $transaksi['denda_sewa'] = $transaksi['denda_sewa'] + (($transaksi['subtotal_driver']/$transaksi['durasi_sewa'])*$temp);
                }
        }

        $total = $transaksi['subtotal_mobil'] + $transaksi['subtotal_driver'] - $transaksi['diskon'] + $transaksi['denda_sewa'];
        var_dump($total);
        Transaksi::where('id_transaksi', $id)->
        update([
            'tanggal_pengembalian_mobil' => $tgl,
            'denda_sewa' => $transaksi['denda_sewa'],
            'total_transaksi' => $total,
        ]);

        Mobil::where('id_mobil', $transaksi['id_mobil'])->
        update([
            'status_mobil' => 'Available', 
        ]);

        if($transaksi['id_driver']!=null)
        {
            Driver::where('id_driver', $transaksi['id_driver'])->
            update([
                'status_driver' => 'Available', 
        ]);
        }

        if ($transaksi->save())
        {
            return response([
                'message' => "Verif Pembayaran Success",
                'data' => $transaksi
            ],200);
        }
        
        return response([
            'message' => "Verif Pembayaran Failed",
            'data' => null
        ],400);
    }
}
