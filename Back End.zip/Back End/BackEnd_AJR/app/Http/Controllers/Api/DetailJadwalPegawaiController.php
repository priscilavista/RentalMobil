<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Detail_Jadwal_Pegawai;
use App\Models\Pegawai;
use App\Models\Jadwal_Pegawai;
use Illuminate\Support\Facades\DB;

class DetailJadwalPegawaiController extends Controller
{
    public function index()
    {
        $detail_jadwal_pegawais = Detail_Jadwal_Pegawai::all();

        if (count($detail_jadwal_pegawais)>0)
        {       
            return response([
                'message' => "Retrieve All Success",
                'data' => $detail_jadwal_pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function read()
    {
        $detail_jadwal_pegawais = Detail_Jadwal_Pegawai::all();

        if (count($detail_jadwal_pegawais)>0)
        {
            $detail_jadwal_pegawais = DB::table('detail_jadwal_pegawai')->
                join('jadwal_pegawai', 'detail_jadwal_pegawai.id_jadwal_pegawai', '=', 'jadwal_pegawai.id_jadwal_pegawai')->
                join('pegawai', 'detail_jadwal_pegawai.id_pegawai', '=', 'pegawai.id_pegawai')->
                join('role', 'pegawai.id_role', '=', 'role.id_role')->
                orderBy('detail_jadwal_pegawai.id_jadwal_pegawai')->
                select('jadwal_pegawai.*','detail_jadwal_pegawai.*', 'pegawai.*', 'role.nama_role')->get();
                
            return response([
                'message' => "Retrieve All Success",
                'data' => $detail_jadwal_pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id_pegawai, $id_jadwal_pegawai)
    {
        $detail_jadwal_pegawai = DB::table('detail_jadwal_pegawai')->
                join('jadwal_pegawai', 'detail_jadwal_pegawai.id_jadwal_pegawai', '=', 'jadwal_pegawai.id_jadwal_pegawai')->
                join('pegawai', 'detail_jadwal_pegawai.id_pegawai', '=', 'pegawai.id_pegawai')->
                where('pegawai.id_pegawai', $id_pegawai)->
                where('jadwal_pegawai.id_jadwal_pegawai', $id_jadwal_pegawai)->
                select('jadwal_pegawai.hari','jadwal_pegawai.shift','pegawai.nama_pegawai')->get();

        if (!is_null($detail_jadwal_pegawai))
        {
            return response([
                'message' => "Retrieve Detail Jadwal Pegawai Success",
                'data' => $detail_jadwal_pegawai
            ],200);
        }
        return response([
            'message' => "Detail Jadwal Pegawai Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'temp_jadwal_pegawai' => 'required',
            'temp_pegawai' => 'required'
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $P = Pegawai::where('temp_pegawai',$updateData['temp_pegawai'])->first();
        $JP = Jadwal_Pegawai::where('temp_jadwal_pegawai',$updateData['temp_jadwal_pegawai'])->first();
        $updateData['id_pegawai'] = $P['id_pegawai'];
        $updateData['id_jadwal_pegawai'] = $JP['id_jadwal_pegawai'];

        if(!is_null(DB::table('detail_jadwal_pegawai')->
            join('pegawai', 'detail_jadwal_pegawai.id_pegawai', '=', 'pegawai.id_pegawai')->
            where('detail_jadwal_pegawai.id_pegawai',$updateData['id_pegawai'])->
            where('detail_jadwal_pegawai.id_jadwal_pegawai',$updateData['id_jadwal_pegawai'])->first()))
        {
            return response([
                'message' => "Add Detail Jadwal Pegawai Failed: Duplicate Data",
                'data' => null
            ],400);
        }

        if(DB::table('detail_jadwal_pegawai')->
                where('detail_jadwal_pegawai.id_pegawai',$updateData['id_pegawai'])->count()==6)
        {
            return response([
                'message' => "Add Detail Jadwal Pegawai Failed: Max 6",
                'data' => null
            ],400);  
        }

        // $count = DB::table('detail_jadwal_pegawai')->
        //             where('id_jadwal_pegawai', $updateData['id_jadwal_pegawai'])->count();

        // if($count == 2)
        // {
        //     return response([
        //         'message' => "Add Detail Jadwal Pegawai Failed: Shift is Filled",
        //         'data' => null
        //     ],400);
        // }
        
        // if($count == 1)
        // {
        //     $countA = DB::table('detail_jadwal_pegawai')->
        //                 join('pegawai', 'detail_jadwal_pegawai.id_pegawai', '=', 'pegawai.id_pegawai')->
        //                 where('id_jadwal_pegawai', $updateData['id_jadwal_pegawai'])->
        //                 where('pegawai.id_role', 2)->count();

        //     $countCS = DB::table('detail_jadwal_pegawai')->
        //                 join('pegawai', 'detail_jadwal_pegawai.id_pegawai', '=', 'pegawai.id_pegawai')->
        //                 where('id_jadwal_pegawai', $updateData['id_jadwal_pegawai'])->
        //                 where('pegawai.id_role', 3)->count();
            
        //     $pgwA = DB::table('pegawai')->
        //                 where('id_pegawai',$updateData['id_pegawai'])->
        //                 where('id_role', 2)->count();

        //     $pgwCS = DB::table('pegawai')->
        //                 where('id_pegawai',$updateData['id_pegawai'])->
        //                 where('id_role', 3)->count();

        //     if(($countA == $pgwA and $pgwA == 1)  or ($countCS == $pgwCS and $pgwCS == 1))
        //     {
        //         return response([
        //             'message' => "Add Detail Jadwal Pegawai Failed: Shift is Filled",
        //             'data' => null,
        //         ],400);
        //     }
        // }

        $detail_jadwal_pegawai = Detail_Jadwal_Pegawai::create($updateData);
            return response([
                'message' => "Add Detail Jadwal Pegawai Success",
                'data' => $detail_jadwal_pegawai,
            ],200);


    }

    public function destroy($id_pegawai, $id_jadwal_pegawai)
    {
        $detail_jadwal_pegawai = DB::table('detail_jadwal_pegawai')->
                where('id_pegawai', $id_pegawai)->
                where('id_jadwal_pegawai', $id_jadwal_pegawai)->first();

        if (is_null($detail_jadwal_pegawai))
        {
            return response([
                'message' => "Detail Jadwal Pegawai Not Found",
                'data' => null
            ],404);
        }

        DB::table('detail_jadwal_pegawai')->
        where('id_pegawai', $id_pegawai)->
        where('id_jadwal_pegawai', $id_jadwal_pegawai)->delete();

        return response([
            'message' => "Delete Detail Jadwal Pegawai Success",
            'data' => $detail_jadwal_pegawai
        ],200);
        
        if(!is_null(DB::table('detail_jadwal_pegawai')->
            where('id_pegawai', $id_pegawai)->
            where('id_jadwal_pegawai', $id_jadwal_pegawai)->first()))
        {
            return response([
            'message' => "Delete Detail Jadwal Pegawai Failed",
            'data' => null
            ],400);
        }
    }

    public function update(Request $request, $id_pegawai, $id_jadwal_pegawai)
    {
        $detail_jadwal_pegawai = DB::table('detail_jadwal_pegawai')->
                where('id_pegawai', $id_pegawai)->
                where('id_jadwal_pegawai', $id_jadwal_pegawai)->first();

        if (is_null($detail_jadwal_pegawai))
        {
            return response([
                'message' => "Detail Jadwal Pegawai Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $P = Pegawai::where('temp_pegawai',$updateData['temp_pegawai'])->first();
        $JP = Jadwal_Pegawai::where('temp_jadwal_pegawai',$updateData['temp_jadwal_pegawai'])->first();
        $updateData['id_pegawai'] = $P['id_pegawai'];
        $updateData['id_jadwal_pegawai'] = $JP['id_jadwal_pegawai'];

        if(!is_null(DB::table('detail_jadwal_pegawai')->
            join('pegawai', 'detail_jadwal_pegawai.id_pegawai', '=', 'pegawai.id_pegawai')->
            where('detail_jadwal_pegawai.id_pegawai',$updateData['id_pegawai'])->
            where('detail_jadwal_pegawai.id_jadwal_pegawai',$updateData['id_jadwal_pegawai'])->first()))
        {
            if($updateData['id_jadwal_pegawai'] == $id_jadwal_pegawai and $updateData['id_pegawai'] == $id_pegawai)
            {
                Detail_Jadwal_Pegawai::where('id_pegawai', $id_pegawai)->
                where('id_jadwal_pegawai', $id_jadwal_pegawai)->
                update([
                    'id_jadwal_pegawai' => $updateData['id_jadwal_pegawai'],
                    'id_pegawai' => $updateData['id_pegawai']
                ]);

                return response([
                    'message' => "Update Detail Jadwal Pegawai Success",
                    'data' => $detail_jadwal_pegawai
                ],200);
            }

            return response([
                'message' => "Update Detail Jadwal Pegawai Failed: Duplicate Data",
                'data' => null
            ],400);
            
        }

        if(DB::table('detail_jadwal_pegawai')->
                where('detail_jadwal_pegawai.id_pegawai',$updateData['id_pegawai'])->count()==6)
        {
            return response([
                'message' => "Update Detail Jadwal Pegawai Failed: Max 6",
                'data' => null
            ],400);  
        }

        Detail_Jadwal_Pegawai::where('id_pegawai', $id_pegawai)->
        where('id_jadwal_pegawai', $id_jadwal_pegawai)->
        update([
            'id_jadwal_pegawai' => $updateData['id_jadwal_pegawai'],
            'id_pegawai' => $updateData['id_pegawai']
        ]);

        return response([
            'message' => "Update Detail Jadwal Pegawai Success",
            'data' => $detail_jadwal_pegawai
        ],200);
    }

}
