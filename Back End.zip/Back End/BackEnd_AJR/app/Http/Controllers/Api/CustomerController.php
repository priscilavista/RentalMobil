<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Customer;
use Carbon\Carbon;

class CustomerController extends Controller
{
    public function index()
    {
        $customers = Customer::all();

        if (count($customers)>0)
        {
            $customers = Customer::orderBy('tanggal_mendaftar_customer')->orderBy('number_customer')->get();
            
            return response([
                'message' => "Retrieve All Success",
                'data' => $customers
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $customer = Customer::where('id_customer',$id)->first();

        if (!is_null($customer))
        {
            return response([
                'message' => "Retrieve Customer Success",
                'data' => $customer
            ],200);
        }
        return response([
            'message' => "Customer Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'nama_customer' => 'required|string',
            'alamat_customer' => 'required|string',
            'tanggal_lahir_customer' => 'required|date',
            'jenis_kelamin_customer' => 'required',
            'email_customer' => 'required|email:rfc,dns|unique:customer',
            'no_telp_customer' => 'required|unique:customer|regex:/^([0][8][0-9]{8,11})$/u',
            'no_ktp_customer' => 'required|unique:customer|numeric|regex:/^([0-9]{16})$/u',
            'dokumen_pendukung' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $storeData['password_customer'] = bcrypt($storeData['tanggal_lahir_customer']);   
        $storeData['tanggal_mendaftar_customer'] = Carbon::today()->format('Y-m-d');   
    
        $date = Carbon::today()->format('y-m-d');
        $year = Carbon::createFromFormat('y-m-d',$date)->format('y');
        $month = Carbon::createFromFormat('y-m-d',$date)->format('m');
        $day = Carbon::createFromFormat('y-m-d',$date)->format('d');
        $previousID = null;
        $previousID = Customer::select('id_customer')->where('tanggal_mendaftar_customer', $storeData['tanggal_mendaftar_customer'])->orderby('id_customer','desc')->first();
        if($previousID!=null)
        {
            $temp = Customer::where('tanggal_mendaftar_customer', $storeData['tanggal_mendaftar_customer'])->count();
            $storeData['number_customer']  = $temp + 1;
            $generateID = 'CUS'.$year.$month.$day.'-00'.$storeData['number_customer'];
        }
        else
        {
            $storeData['number_customer'] = 1;
            $generateID = 'CUS'.$year.$month.$day.'-001';
        }
        
        $storeData['id_customer'] = $generateID;
        if($request->dokumen_pendukung!=null)
        {
            $storeData['dokumen_pendukung'] = $request->dokumen_pendukung;
        }
        

        // if($request->dokumen_pendukung!=null)
        // {
        //     $file_image = time().'.'.$request->dokumen_pendukung->extension();
        //     $request->dokumen_pendukung->move(public_path('dokumen_pendukung'),$file_image);
        //     $path = "$file_image";
        //     $storeData['dokumen_pendukung'] = $path;
        // }
        
        $customer = Customer::create($storeData);
        return response([
            'message' => "Add Customer Success",
            'data' => $customer
        ],200);
    }

    public function temp(Request $request)
    {
        $customer = customer::all();
        if (count($customer)<0)
        {
            return response([
                'message' => "Customer Empty",
                'data' => null
            ],404);
        }

        $values = customer::where('temp_customer',null)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                customer::where('id_customer', $value['id_customer'])->update([
                    'temp_customer' => $value['id_customer'].'-'.$value['nama_customer']
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Update Customer Success",
        ],200);

    }

    public function destroy($id)
    {
        $customer = Customer::where('id_customer',$id)->first();

        if (is_null($customer))
        {
            return response([
                'message' => "Customer Not Found",
                'data' => null
            ],404);
        }

        if ($customer->delete())
        {
            return response([
                'message' => "Delete Customer Success",
                'data' => $customer
            ],200);
        }
        
        return response([
            'message' => "Delete Customer Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $customer = Customer::where('id_customer',$id)->first();
        if (is_null($customer))
        {
            return response([
                'message' => "Customer Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'nama_customer' => 'required|string',
            'alamat_customer' => 'required|string',
            'tanggal_lahir_customer' => 'required|date',
            'jenis_kelamin_customer' => 'required',
            'email_customer' => ['required', 'email:rfc,dns', Rule::unique('customer')->ignore($id,'id_customer')],
            'no_telp_customer' => ['required','regex:/^([0][8][0-9]{8,11})$/u', Rule::unique('customer')->ignore($id,'id_customer')],
            'no_ktp_customer' => ['required','regex:/^([0-9]{16})$/u', Rule::unique('customer')->ignore($id,'id_customer')],
            'dokumen_pendukung' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        Customer::where('id_customer', $id)->
        update([
            'nama_customer' => $updateData['nama_customer'],
            'alamat_customer' => $updateData['alamat_customer'],
            'tanggal_lahir_customer' => $updateData['tanggal_lahir_customer'],
            'jenis_kelamin_customer' => $updateData['jenis_kelamin_customer'],
            'email_customer' => $updateData['email_customer'],
            'no_telp_customer' => $updateData['no_telp_customer'],
            'no_ktp_customer' => $updateData['no_ktp_customer'],
            'dokumen_pendukung' => $updateData['dokumen_pendukung'],
        ]);
        
        if ($customer->save())
        {
            return response([
                'message' => "Update Customer Success",
                'data' => $customer
            ],200);
        }
        
        return response([
            'message' => "Update Customer Failed",
            'data' => null
        ],400);
    }



    public function editPassword(Request $request, $id)
    {
        $customer = Customer::where('id_customer',$id)->first();

        if(is_null($customer))
        {
            return response([
                'message' => 'Customer Not Found',
                'data' => null
            ], 404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData,
        [
            'password_customer' => 'required'
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $updateData['password_customer'] = bcrypt($request->password_customer);
        Customer::where('id_customer', $id)->
        update([
            'password_customer' => $updateData['password_customer']
        ]);

        if($customer->save())
        {
            return response(
                [
                    'message' => 'Password Has Been Updated',
                    'data' => $customer,
                ], 200);
        }

        return response(
            [
                'message' => 'Password Cannot Be Updated',
                'data' => null,
            ], 400);
    }

    public function count()
    {
        $customers = Customer::all()->count();

        if ($customers != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $customers
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }
}
