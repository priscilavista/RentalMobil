<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Jadwal_Pegawai;

class JadwalPegawaiController extends Controller
{
    public function index()
    {
        $jadwal_pegawais = Jadwal_Pegawai::all();

        if (count($jadwal_pegawais)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $jadwal_pegawais
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $jadwal_pegawai = Jadwal_Pegawai::find($id);

        if (!is_null($jadwal_pegawai))
        {
            return response([
                'message' => "Retrieve Jadwal Pegawai Success",
                'data' => $jadwal_pegawai
            ],200);
        }
        return response([
            'message' => "Jadwal Pegawai Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'hari' => 'required',
            'shift' => 'required',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $jadwal_pegawai = Jadwal_Pegawai::create($storeData);
        return response([
            'message' => "Add Jadwal Pegawai Success",
            'data' => $jadwal_pegawai
        ],200);
    }

    public function temp(Request $request)
    {
        $jadwal_pegawai = jadwal_pegawai::all();
        if (count($jadwal_pegawai)<0)
        {
            return response([
                'message' => "jadwal pegawai Empty",
                'data' => null
            ],404);
        }

        $values = jadwal_pegawai::where('temp_jadwal_pegawai',null)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                jadwal_pegawai::where('id_jadwal_pegawai', $value['id_jadwal_pegawai'])->update([
                    'temp_jadwal_pegawai' => $value['hari'].'-'.$value['shift']
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Update jadwal pegawai Success",
        ],200);

    }

    public function destroy($id)
    {
        $jadwal_pegawai = Jadwal_Pegawai::find($id);

        if (is_null($jadwal_pegawai))
        {
            return response([
                'message' => "Jadwal Pegawai Not Found",
                'data' => null
            ],404);
        }

        if ($jadwal_pegawai->delete())
        {
            return response([
                'message' => "Delete Jadwal Pegawai Success",
                'data' => $jadwal_pegawai
            ],200);
        }
        
        return response([
            'message' => "Delete Jadwal Pegawai Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $jadwal_pegawai = Jadwal_Pegawai::find($id);
        if (is_null($jadwal_pegawai))
        {
            return response([
                'message' => "Jadwal Pegawai Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'hari' => 'required',
            'shift' => 'required',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $jadwal_pegawai->hari = $updateData['hari'];
        $jadwal_pegawai->shift = $updateData['shift'];

        if ($jadwal_pegawai->save())
        {
            return response([
                'message' => "Update Jadwal Pegawai Success",
                'data' => $jadwal_pegawai
            ],200);
        }
        
        return response([
            'message' => "Update Jadwal Pegawai Failed",
            'data' => null
        ],400);
    }

}
