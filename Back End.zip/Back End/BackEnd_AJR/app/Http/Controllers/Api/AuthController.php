<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\User;

class AuthController extends Controller
{

    public function login(Request $request)
    {
        $loginData = $request->all();
        $email = $request->email;
        $password = $request->password;

        $validate = Validator::make($loginData, [
            'email' => 'required|email:rfc,dns',
            'password' => 'required'
        ]);

        if ($validate->fails())
            return response(['message' => $validate->errors()],400);

        $pegawai = User::where('email_pegawai',$email)->first();
        // $customer = Customer::where('email_customer',$email)->first();
        // $driver = Driver::where('email_driver',$email)->first();

        // if (!Auth::attempt($loginData))
        //     return response(['message' => 'Invalid Credentials'],401);

        // $user = Auth::User();
        $token = $pegawai->createToken('Authentication Token')->accessToken;

        if($pegawai != null)
        {
            $passwordPegawai = $pegawai['password_pegawai'];

            if(! Hash::check($password, $passwordPegawai))
            {
                return response(['message' => 'Invalid Password'],401); 
               
            }
            
            return response([
                'message' => 'Authenticated',
                'data' => $pegawai,
                'token' => $token,
            ]);
        } 
        else
        {
            return response(['message' => 'Invalid Credentials'],401); 
        }

        // return response([
        //     'message' => 'Authenticated',
        //     'user' => $user,
        //     'token_type' => "Bearer",
        //     'access_token' => $token
        // ]);
    }
}
