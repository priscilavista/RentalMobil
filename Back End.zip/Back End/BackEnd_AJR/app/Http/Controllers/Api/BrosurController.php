<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Brosur;
use App\Models\Mobil;

class BrosurController extends Controller
{
    public function index()
    {
        $brosurs = Brosur::with('mobil')->get();
        // $brosurs = Brosur::join('mobil', 'brosur.id_brosur', '=', 'mobil.id_brosur')->
        //             select('brosur.*', 'mobil.*')->get();

        if (count($brosurs)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $brosurs
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function indexBrosur()
    {
        $brosurs = Brosur::where('status_brosur',true)->get();

        if (count($brosurs)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $brosurs
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function read()
    {
        $brosurs = Brosur::with('mobil')->get();

        if (count($brosurs)>0)
        {
            $brosurs = brosur::where('status_brosur', true)->with('mobil')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $brosurs
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function remove()
    {
        $brosurs = brosur::all();

        if (count($brosurs)>0)
        {
            $brosurs = brosur::where('status_brosur', false)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $brosurs
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function mobil($id)
    {
        $brosurs = Mobil::where('id_brosur', $id)->get();

        if (count($brosurs)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $brosurs
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $brosur = Brosur::with('mobil')->find($id);

        if (!is_null($brosur))
        {
            return response([
                'message' => "Retrieve Brosur Success",
                'data' => $brosur
            ],200);
        }
        return response([
            'message' => "Brosur Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'nama_brosur' => 'required|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $storeData['status_brosur'] = true;

        $brosur = Brosur::create($storeData);
        return response([
            'message' => "Add Brosur Success",
            'data' => $brosur
        ],200);
    }

    public function destroy($id)
    {
        $brosur = Brosur::find($id);

        if (is_null($brosur))
        {
            return response([
                'message' => "Brosur Not Found",
                'data' => null
            ],404);
        }

        if ($brosur->delete())
        {
            return response([
                'message' => "Delete Brosur Success",
                'data' => $brosur
            ],200);
        }
        
        return response([
            'message' => "Delete Brosur Failed",
            'data' => null
        ],400);
    }

    public function delete(Request $request, $id)
    {
        $brosur = Brosur::find($id);
        if (is_null($brosur))
        {
            return response([
                'message' => "Brosur Not Found",
                'data' => null
            ],404);
        }

        $brosur->status_Brosur = false;

        if ($brosur->save())
        {
            return response([
                'message' => "Remove Brosur Success",
                'data' => $brosur
            ],200);
        }
        
        return response([
            'message' => "Remove Brosur Failed",
            'data' => null
        ],400);
    }

    public function deleteBinM(Request $request, $id)
    {
        $brosur = Mobil::where('id_brosur', $id)->get();
        if (count($brosur)==0)
        {
            return response([
                'message' => "Brosur Not Found in Any Car",
                'data' => null
            ],200);
        }

        $values = Mobil::where('id_brosur', $id)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                Mobil::where('id_mobil', $value['id_mobil'])->
                update([
                    'id_brosur' => null
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Remove Brosur Success",
            'data' => $brosur
        ],200);
    }

    public function recover(Request $request, $id)
    {
        $brosur = Brosur::find($id);
        if (is_null($brosur))
        {
            return response([
                'message' => "Brosur Not Found",
                'data' => null
            ],404);
        }

        $brosur->status_Brosur = true;

        if ($brosur->save())
        {
            return response([
                'message' => "Recover Brosur Success",
                'data' => $brosur
            ],200);
        }
        
        return response([
            'message' => "Recover Brosur Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $brosur = Brosur::find($id);
        if (is_null($brosur))
        {
            return response([
                'message' => "Brosur Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'nama_brosur' => 'required|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $brosur->nama_brosur = $updateData['nama_brosur'];

        if ($brosur->save())
        {
            return response([
                'message' => "Update Brosur Success",
                'data' => $brosur
            ],200);
        }
        
        return response([
            'message' => "Update Brosur Failed",
            'data' => null
        ],400);
    }

    public function count()
    {
        $brosurs = brosur::where('status_brosur', true)->count();

        if ($brosurs != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $brosurs
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }
}
