<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Promo;
use Carbon\Carbon;

class PromoController extends Controller
{
    public function index()
    {
        $promos = Promo::all();

        if (count($promos)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $promos
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function read()
    {
        $promos = Promo::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($promos)>0)
        {
            $promos = Promo::where('tanggal_terakhir_berlaku', '>=', $date)->where('status_promo', true)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $promos
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function readAktif()
    {
        $promos = Promo::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($promos)>0)
        {
            $promos = Promo::where('tanggal_mulai_berlaku', '<=', $date)->where('tanggal_terakhir_berlaku', '>=', $date)->where('status_promo', true)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $promos
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function kadaluwarsa()
    {
        $promos = Promo::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($promos)>0)
        {
            $promos = Promo::where('tanggal_terakhir_berlaku', '<', $date)->where('status_promo', true)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $promos
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function remove()
    {
        $promos = Promo::all();

        if (count($promos)>0)
        {
            $promos = Promo::where('status_promo', false)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $promos
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $promo = Promo::find($id);

        if (!is_null($promo))
        {
            return response([
                'message' => "Retrieve Promo Success",
                'data' => $promo
            ],200);
        }
        return response([
            'message' => "Promo Not Found",
            'data' => null
        ],404);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'kode_promo' => 'required|unique:Promo',
            'jenis_promo' => 'required',
            'keterangan_promo' => 'required',
            'tanggal_mulai_berlaku' => 'required|date',
            'tanggal_terakhir_berlaku' => 'required|date|after_or_equal:tanggal_mulai_berlaku',
            'diskon_promo' => 'required|numeric'
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $storeData['status_promo'] = 1;

        $promo = Promo::create($storeData);
        return response([
            'message' => "Add Promo Success",
            'data' => $promo
        ],200);
    }

    public function destroy($id)
    {
        $promo = Promo::find($id);

        if (is_null($promo))
        {
            return response([
                'message' => "Promo Not Found",
                'data' => null
            ],404);
        }

        if ($promo->delete())
        {
            return response([
                'message' => "Delete Promo Success",
                'data' => $promo
            ],200);
        }
        
        return response([
            'message' => "Delete Promo Failed",
            'data' => null
        ],400);
    }

    public function delete(Request $request, $id)
    {
        $promo = Promo::find($id);
        if (is_null($promo))
        {
            return response([
                'message' => "Promo Not Found",
                'data' => null
            ],404);
        }

        $promo->status_promo = false;

        if ($promo->save())
        {
            return response([
                'message' => "Remove Promo Success",
                'data' => $promo
            ],200);
        }
        
        return response([
            'message' => "Remove Promo Failed",
            'data' => null
        ],400);
    }

    public function recover(Request $request, $id)
    {
        $promo = Promo::find($id);
        if (is_null($promo))
        {
            return response([
                'message' => "Promo Not Found",
                'data' => null
            ],404);
        }

        $promo->status_promo = true;

        if ($promo->save())
        {
            return response([
                'message' => "Recover Promo Success",
                'data' => $promo
            ],200);
        }
        
        return response([
            'message' => "Recover Promo Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $promo = Promo::find($id);
        if (is_null($promo))
        {
            return response([
                'message' => "Promo Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'kode_promo' => ['required', Rule::unique('Promo')->ignore($id,'id_promo')],
            'jenis_promo' => 'required',
            'keterangan_promo' => 'required',
            'tanggal_mulai_berlaku' => 'required|date',
            'tanggal_terakhir_berlaku' => 'required|date|after_or_equal:tanggal_mulai_berlaku',
            'diskon_promo' => 'required|numeric'
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        $promo->kode_promo = $updateData['kode_promo'];
        $promo->jenis_promo = $updateData['jenis_promo'];
        $promo->keterangan_promo = $updateData['keterangan_promo'];
        $promo->tanggal_mulai_berlaku = $updateData['tanggal_mulai_berlaku'];
        $promo->tanggal_terakhir_berlaku = $updateData['tanggal_terakhir_berlaku'];
        $promo->diskon_promo = $updateData['diskon_promo'];

        if ($promo->save())
        {
            return response([
                'message' => "Update Promo Success",
                'data' => $promo
            ],200);
        }
        
        return response([
            'message' => "Update Promo Failed",
            'data' => null
        ],400);
    }

}
