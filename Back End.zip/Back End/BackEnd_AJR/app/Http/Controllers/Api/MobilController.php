<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Validator;
use App\Models\Mobil;
use App\Models\Mitra;
use Carbon\Carbon;

class MobilController extends Controller
{
    public function index()
    {
        $mobils = Mobil::where('status_mobil2', true)->get();

        if (count($mobils)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function indexForBrosur()
    {
        $mobils = Mobil::where('id_brosur',  null)->get();

        if (count($mobils)>0)
        {
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function readAllMitra()
    {
        $mitras = Mobil::all();

        if (count($mitras)>0)
        {
            $mitras = Mobil::join('mitra', 'mobil.id_mitra', '=', 'mitra.id_mitra')->
                            select('mitra.nama_mitra')->get();

            return response([
                'message' => "Retrieve All Success",
                'data' => $mitras
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function readM()
    {
        $mobils = Mobil::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($mobils)>0)
        {
            $mobils = Mobil::join('mitra', 'mobil.id_mitra', '=', 'mitra.id_mitra')->
                        where('periode_kontrak_akhir_mobil', '>=', $date)->where('status_mobil2', true)->
                        where('kategori_aset_mobil', "Mitra")->
                        select('mobil.*', 'mitra.nama_mitra', 'mitra.temp_mitra')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function readP()
    {
        $mobils = Mobil::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($mobils)>0)
        {
            $mobils = Mobil::where('status_mobil2', true)->
                        where('kategori_aset_mobil', "Perusahaan")->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function kadaluwarsa()
    {
        $mobils = Mobil::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($mobils)>0)
        {
            $mobils = Mobil::join('mitra', 'mobil.id_mitra', '=', 'mitra.id_mitra')->
                        where('periode_kontrak_akhir_mobil', '<', $date)->where('status_mobil2', true)->
                        where('kategori_aset_mobil', "Mitra")->
                        select('mobil.*', 'mitra.nama_mitra', 'mitra.temp_mitra')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function remove()
    {
        $mobils = Mobil::all();

        if (count($mobils)>0)
        {
            $mobils = Mobil::where('status_mobil2', false)->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function show($id)
    {
        $mobil = Mobil::find($id);

        if (!is_null($mobil))
        {
            return response([
                'message' => "Retrieve Mobil Success",
                'data' => $mobil
            ],200);
        }
        return response([
            'message' => "Mobil Not Found",
            'data' => null
        ],404);
    }

    public function readMitra($id)
    {
        $mitra = Mobil::find($id);

        if (!is_null($mitra))
        {
            $mitra = Mobil::join('mitra', 'mobil.id_mitra', '=', 'mitra.id_mitra')->
                            where('mobil.id_mobil',$id)->
                            select('mitra.nama_mitra')->first();

            return response([
                'message' => "Retrieve All Success",
                'data' => $mitra
            ],200);
        }
        return response([
            'message' => "Mitra Not Found",
            'data' => null
        ],400);
    }

    public function store(Request $request)
    {
        $storeData = $request->all();
        $validate = Validator::make($storeData, [
            'temp_mitra' => '',
            'nama_mobil' => 'required',
            'tipe_mobil' => 'required',
            'jenis_transmisi_mobil' => 'required',
            'jenis_bahan_bakar_mobil' => 'required',
            'volume_bahan_bakar_mobil' => 'required|numeric',
            'warna_mobil' => 'required',
            'kapasitas_penumpang_mobil' => 'required|numeric',
            'fasilitas_mobil' => 'required',
            'plat_nomor_mobil' => 'required|unique:mobil',
            'nomor_stnk_mobil' => 'required|unique:mobil|numeric',
            'kategori_aset_mobil' => 'required',
            'periode_kontrak_mulai_mobil' => '',
            'periode_kontrak_akhir_mobil' => '',
            'tanggal_terakhir_servis_mobil' => 'required|date',
            'gambar_mobil' => 'nullable',
            'harga_sewa_mobil' => 'required|numeric',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        if($storeData['periode_kontrak_akhir_mobil'] != null && $storeData['periode_kontrak_mulai_mobil'] != null)
        {
            $validate = Validator::make($storeData,
            [
                'periode_kontrak_mulai_mobil' => 'date',
                'periode_kontrak_akhir_mobil' => 'date|after:periode_kontrak_mulai_mobil',
            ]);

            if ($validate->fails())
            {
                return response(['message' => $validate->errors()],400);
            }
        }

        if($storeData['kategori_aset_mobil'] == 'Mitra' and (is_null($storeData['periode_kontrak_mulai_mobil']) or is_null($storeData['periode_kontrak_akhir_mobil'])))
        {
            return response([
                'message' => "Add Mobil Failed: The Periode Kontrak Mobil field is required",
                'data' => null
            ],400);
        }

        $storeData['status_mobil'] = "Available";
        $storeData['status_mobil2'] = true;

        if($storeData['temp_mitra'] != null)
        {
            $mitra = Mitra::where('temp_mitra',$storeData['temp_mitra'])->first();
            $storeData['id_mitra'] = $mitra['id_mitra'];
        }

        if($request->gambar_mobil!=null)
        {
            $file_image = time().'.'.$request->gambar_mobil->extension();
            $request->gambar_mobil->move(public_path('gambar_mobil'),$file_image);
            $path = "$file_image";
            $storeData['gambar_mobil'] = $path;
        }

        $mobil = Mobil::create($storeData);
        return response([
            'message' => "Add Mobil Success",
            'data' => $mobil
        ],200);
    }

    public function temp(Request $request)
    {
        $mobil = mobil::all();
        if (count($mobil)<0)
        {
            return response([
                'message' => "mobil Empty",
                'data' => null
            ],404);
        }

        $values = mobil::where('temp_mobil',null)->get();
        if(!empty($values))
        {
            foreach($values as $value) 
            {
                mobil::where('id_mobil', $value['id_mobil'])->update([
                    'temp_mobil' => $value['id_mobil'].'-'.$value['nama_mobil']
                ]);
                $value->save();
            }
        }

        return response([
            'message' => "Update Mitra Success",
        ],200);

    }

    public function destroy($id)
    {
        $mobil = Mobil::find($id);

        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        if ($mobil->delete())
        {
            return response([
                'message' => "Delete Mobil Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Delete Mobil Failed",
            'data' => null
        ],400);
    }

    public function delete(Request $request, $id)
    {
        $mobil = Mobil::find($id);
        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        $mobil->status_mobil2 = false;

        if ($mobil->save())
        {
            return response([
                'message' => "Remove Mobil Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Remove Mobil Failed",
            'data' => null
        ],400);
    }

    public function recover(Request $request, $id)
    {
        $mobil = Mobil::find($id);
        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        $mobil->status_mobil2 = true;

        if ($mobil->save())
        {
            return response([
                'message' => "Recover Mobil Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Recover Mobil Failed",
            'data' => null
        ],400);
    }

    public function update(Request $request, $id)
    {
        $mobil = Mobil::find($id);
        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'temp_mitra' => 'nullable',
            'nama_mobil' => 'required',
            'tipe_mobil' => 'required',
            'jenis_transmisi_mobil' => 'required',
            'jenis_bahan_bakar_mobil' => 'required',
            'volume_bahan_bakar_mobil' => 'required|numeric',
            'warna_mobil' => 'required',
            'kapasitas_penumpang_mobil' => 'required|numeric',
            'fasilitas_mobil' => 'required',
            'plat_nomor_mobil' => ['required', Rule::unique('mobil')->ignore($id,'id_mobil')],
            'nomor_stnk_mobil' => ['required','numeric', Rule::unique('mobil')->ignore($id,'id_mobil')],
            'kategori_aset_mobil' => 'required',
            'periode_kontrak_mulai_mobil' => 'nullable|date',
            'periode_kontrak_akhir_mobil' => 'nullable|date|after:periode_kontrak_mulai_mobil',
            'tanggal_terakhir_servis_mobil' => 'required|date',
            'status_mobil' => 'required',
            'harga_sewa_mobil' => 'required|numeric',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        if($updateData['kategori_aset_mobil'] == 'Mitra' and (is_null($updateData['periode_kontrak_mulai_mobil']) or is_null($updateData['periode_kontrak_akhir_mobil'])))
        {
            return response([
                'message' => "Add Mobil Failed: The Periode Kontrak Mobil field is required",
                'data' => null
            ],400);
        }

        if($request->temp_mobil !=null)
        {
            $mitra = Mitra::where('temp_mitra',$updateData['temp_mitra'])->first();
            $mobil->id_mitra = $mitra['id_mitra'];
        }

        if($request->periode_kontrak_mulai_mobil != null)
        {
            $mobil->periode_kontrak_mulai_mobil = $updateData['periode_kontrak_mulai_mobil'];
        }

        if($request-> periode_kontrak_akhir_mobil != null)
        {
            $mobil->periode_kontrak_akhir_mobil = $updateData['periode_kontrak_akhir_mobil'];
        }

        $mobil->nama_mobil = $updateData['nama_mobil'];
        $mobil->tipe_mobil = $updateData['tipe_mobil'];
        $mobil->jenis_transmisi_mobil = $updateData['jenis_transmisi_mobil'];
        $mobil->jenis_bahan_bakar_mobil = $updateData['jenis_bahan_bakar_mobil'];
        $mobil->volume_bahan_bakar_mobil = $updateData['volume_bahan_bakar_mobil'];
        $mobil->warna_mobil = $updateData['warna_mobil'];
        $mobil->kapasitas_penumpang_mobil = $updateData['kapasitas_penumpang_mobil'];
        $mobil->fasilitas_mobil = $updateData['fasilitas_mobil'];
        $mobil->plat_nomor_mobil = $updateData['plat_nomor_mobil'];
        $mobil->nomor_stnk_mobil = $updateData['nomor_stnk_mobil'];
        $mobil->kategori_aset_mobil = $updateData['kategori_aset_mobil'];
        $mobil->tanggal_terakhir_servis_mobil = $updateData['tanggal_terakhir_servis_mobil'];
        $mobil->status_mobil = $updateData['status_mobil'];
        $mobil->harga_sewa_mobil = $updateData['harga_sewa_mobil'];
        $mobil->temp_mobil = $id.'-'.$updateData['nama_mobil'];

        if ($mobil->save())
        {
            return response([
                'message' => "Update Mobil Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Update Mobil Failed",
            'data' => null
        ],400);
    }

    public function setBrosur(Request $request)
    {
        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'temp_mobil' => 'required',
        ]);

        $mobil = Mobil::where('temp_mobil',$updateData['temp_mobil'])->first();
        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        Mobil::where('id_mobil', $mobil['id_mobil'])->
        update([
            'id_brosur' => $updateData['id_brosur']
        ]);

        if ($mobil->save())
        {
            return response([
                'message' => "Update Brosur Mobil Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Update Brosur Mobil Failed",
            'data' => null
        ],400);
    }

    public function deleteBrosur(Request $request, $id)
    {
        $mobil = Mobil::find($id);
        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        $mobil->id_brosur = null;

        if ($mobil->save())
        {
            return response([
                'message' => "Delete Mobil Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Delete Mobil Failed",
            'data' => null
        ],400);
    }

    public function count()
    {
        $mobils = Mobil::all()->count();

        if ($mobils != 0)
        {
            return response([
                'message' => "Counting All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => 0
        ],400);
    }
    public function uploadImage(Request $request, $id)
    {
        $mobil = mobil::where('id_mobil',$id)->first();
        if (is_null($mobil))
        {
            return response([
                'message' => "Mobil Not Found",
                'data' => null
            ],404);
        }

        $updateData = $request->all();
        $validate = Validator::make($updateData, [
            'gambar_mobil' => 'nullable|string',
        ]);

        if ($validate->fails())
        {
            return response(['message' => $validate->errors()],400);
        }

        mobil::where('id_mobil', $id)->
        update([
            'gambar_mobil' => $updateData['gambar_mobil'],
        ]);

        if ($mobil->save())
        {
            return response([
                'message' => "Update Image Success",
                'data' => $mobil
            ],200);
        }
        
        return response([
            'message' => "Update Image Failed",
            'data' => null
        ],400);
    }

    public function kontrakAkanHabis()
    {
        $mobils = Mobil::all();
        $date = Carbon::now()->addDays(30)->format('Y-m-d');
        $date2 =  Carbon::now()->format('Y-m-d');

        if (count($mobils)>0)
        {
            $mobils = Mobil::join('mitra', 'mobil.id_mitra', '=', 'mitra.id_mitra')->
                        where('periode_kontrak_akhir_mobil', '>=', $date2)->
                        where('periode_kontrak_akhir_mobil', '<', $date)->
                        where('status_mobil2', true)->
                        where('kategori_aset_mobil', "Mitra")->
                        select('mobil.*', 'mitra.*')->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils,
                'date' => $date
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }

    public function available()
    {
        $mobils = Mobil::all();
        $date = Carbon::now()->format('Y-m-d');

        if (count($mobils)>0)
        {
            $mobils = Mobil::where(function($query) {
                            $query->where('kategori_aset_mobil', 'Perusahaan')
                            ->where('status_mobil2', true)
                            ->where('status_mobil', "Available");
                        })->
                        orWhere(function($query) {
                            $query->where('kategori_aset_mobil', 'Mitra')
                            ->where('status_mobil2', true)
                            ->where('status_mobil', "Available")
                            ->where('periode_kontrak_akhir_mobil', '>', Carbon::now()->format('Y-m-d'));
                        })->get();
            return response([
                'message' => "Retrieve All Success",
                'data' => $mobils
            ],200);
        }
        return response([
            'message' => "Empty",
            'data' => null
        ],400);
    }
}
