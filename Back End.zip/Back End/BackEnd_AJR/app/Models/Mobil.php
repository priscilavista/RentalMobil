<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mobil extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'mobil';
    protected $primaryKey = 'id_mobil';
    protected $fillable =
    [
        'id_mitra','id_brosur','nama_mobil','tipe_mobil','jenis_transmisi_mobil','jenis_bahan_bakar_mobil','volume_bahan_bakar_mobil','warna_mobil','kapasitas_penumpang_mobil','fasilitas_mobil','plat_nomor_mobil','nomor_stnk_mobil','kategori_aset_mobil','periode_kontrak_mulai_mobil','periode_kontrak_akhir_mobil','tanggal_terakhir_servis_mobil','gambar_mobil','status_mobil','harga_sewa_mobil', 'status_mobil2'
    ];

    public function brosur()
    {
        return $this->belongsTo(Brosur::class,'id_brosur');
    }
}
