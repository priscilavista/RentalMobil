<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Jadwal_Pegawai extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'jadwal_pegawai';
    protected $primaryKey = 'id_jadwal_pegawai';
    protected $fillable =
    [
        'hari', 'shift', 'temp_jadwal_pegawai'
    ];
}
