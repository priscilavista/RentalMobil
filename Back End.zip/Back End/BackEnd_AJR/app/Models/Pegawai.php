<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pegawai extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'pegawai';
    protected $fillable =
    [
        'id_pegawai','id_role','nama_pegawai','alamat_pegawai','tanggal_lahir_pegawai','jenis_kelamin_pegawai','email_pegawai','no_telp_pegawai','foto_pegawai','password_pegawai', 'tanggal_mendaftar_pegawai', 'number_pegawai', 'status_pegawai', 'temp_pegawai'
    ];
}
