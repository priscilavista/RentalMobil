<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'customer';
    protected $fillable =
    [
        'id_customer','nama_customer', 'alamat_customer', 'tanggal_lahir_customer', 'jenis_kelamin_customer', 'email_customer', 'no_telp_customer', 'no_ktp_customer', 'dokumen_pendukung', 'password_customer','tanggal_mendaftar_customer', 'number_customer', 'temp_customer'
    ];
}
