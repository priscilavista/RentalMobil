<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'transaksi';
    protected $fillable =
    [
        'id_transaksi','id_promo','id_customer','id_pegawai','id_driver','id_mobil','tanggal_transaksi','tanggal_mulai_sewa','tanggal_selesai_sewa','tanggal_pengembalian_mobil','durasi_sewa','subtotal_mobil','subtotal_driver','denda_sewa','total_transaksi','bukti_pembayaran','status_pembayaran','rating_driver', 'number_transaksi', 'cek_tanggal_transaksi', 'verif_transaksi', 'diskon', 'subtotal'
    ];
}
