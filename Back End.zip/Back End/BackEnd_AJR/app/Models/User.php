<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Carbon\Carbon;

class User extends Authenticatable
{
    use Notifiable, HasApiTokens;
    
    protected $table = 'pegawai';
    protected $fillable = 
    [
        'id_pegawai','id_role','nama_pegawai','alamat_pegawai','tanggal_lahir_pegawai','jenis_kelamin_pegawai','email_pegawai','no_telp_pegawai','foto_pegawai','password_pegawai', 'tanggal_mendaftar_pegawai', 'number_pegawai'
    ];

}