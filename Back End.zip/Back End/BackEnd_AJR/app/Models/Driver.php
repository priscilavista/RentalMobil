<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Driver extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'driver';
    protected $fillable =
    [
        'id_driver','nama_driver', 'alamat_driver', 'tanggal_lahir_driver', 'jenis_kelamin_driver', 'email_driver', 'no_telp_driver', 'bahasa_driver', 'foto_driver', 'berkas_sim_driver', 'berkas_surat_bebas_napza_driver', 'berkas_surat_kesjiwa_driver', 'berkas_surat_kesjasmani_driver', 'berkas_skck_driver', 'tarif_driver', 'status_driver', 'rating_performa_driver', 'password_driver', 'tanggal_mendaftar_driver', 'number_driver', 'status_driver2', 'temp_driver',
    ];
}
