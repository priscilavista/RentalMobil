<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Detail_Jadwal_Pegawai extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'detail_jadwal_pegawai';
    protected $fillable =
    [
        'id_jadwal_pegawai', 'id_pegawai'
    ];
}
