<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Brosur extends Model
{
    use HasFactory;
    public $timestamps = false;
    protected $table = 'brosur';
    protected $primaryKey = 'id_brosur';
    protected $fillable =
    [
        'nama_brosur', 'status_brosur'
    ];

    public function mobil()
    {
        return $this->hasMany(Mobil::class, 'id_brosur');
    }
   
}
