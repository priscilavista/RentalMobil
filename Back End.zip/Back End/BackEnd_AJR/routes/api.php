<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('login', 'Api\AuthController@login');

    //Brosur
    Route::get('brosur', 'Api\BrosurController@index');
    Route::get('brosurIndex', 'Api\BrosurController@indexBrosur');
    Route::get('brosurRead', 'Api\BrosurController@read');
    Route::get('brosurRemove', 'Api\BrosurController@remove');
    Route::get('brosurMobil/{id}', 'Api\BrosurController@mobil');
    Route::get('brosur/{id}', 'Api\BrosurController@show');
    Route::post('brosur', 'Api\BrosurController@store');
    Route::put('brosur/{id}', 'Api\BrosurController@update');
    Route::put('brosurDelete/{id}', 'Api\BrosurController@delete');
    Route::put('brosurDeleteinM/{id}', 'Api\BrosurController@deleteBinM');
    Route::put('brosurRecover/{id}', 'Api\BrosurController@recover');
    Route::delete('brosur/{id}', 'Api\BrosurController@destroy');
    Route::get('brosurCount', 'Api\BrosurController@count');

    //Customer
    Route::get('customer', 'Api\CustomerController@index');
    Route::get('customer/{id}', 'Api\CustomerController@show');
    Route::post('customer', 'Api\CustomerController@store');
    Route::put('customerTemp', 'Api\CustomerController@temp');
    Route::put('customer/{id}', 'Api\CustomerController@update');
    // Route::delete('brosur/{id}', 'Api\BrosurController@destroy');
    Route::put('customerEditPass/{id}', 'Api\CustomerController@editPassword');
    Route::get('customerCount', 'Api\CustomerController@count');

    //Detail Jadwal Pegawai
    Route::get('detailJadwalPegawai', 'Api\DetailJadwalPegawaiController@index');
    Route::get('detailJadwalPegawaiRead', 'Api\DetailJadwalPegawaiController@read');
    Route::get('detailJadwalPegawai/{id_pegawai}/{id_jadwal_pegawai}', 'Api\DetailJadwalPegawaiController@show');
    Route::post('detailJadwalPegawai', 'Api\DetailJadwalPegawaiController@store');
    Route::put('detailJadwalPegawai/{id_pegawai}/{id_jadwal_pegawai}', 'Api\DetailJadwalPegawaiController@update');
    Route::delete('detailJadwalPegawai/{id_pegawai}/{id_jadwal_pegawai}', 'Api\DetailJadwalPegawaiController@destroy');

    //Driver
    Route::get('driver', 'Api\DriverController@index');
    Route::get('driverRead', 'Api\DriverController@read');
    Route::get('driverRemove', 'Api\DriverController@remove');
    Route::get('driver/{id}', 'Api\DriverController@show');
    Route::post('driver', 'Api\DriverController@store');
    Route::put('driverTemp', 'Api\DriverController@temp');
    Route::put('driver/{id}', 'Api\DriverController@update');
    Route::delete('driver/{id}', 'Api\DriverController@destroy');
    Route::put('driverDelete/{id}', 'Api\DriverController@delete');
    Route::put('driverRecover/{id}', 'Api\DriverController@recover');
    Route::put('driverEditPass/{id}', 'Api\DriverController@editPassword');
    Route::get('driverCount', 'Api\DriverController@count');
    Route::put('driverBerkas/{id}', 'Api\DriverController@uploadBerkas');
    Route::put('driverImage/{id}', 'Api\DriverController@uploadImage');

    //Jadwal Pegawai
    Route::get('jadwalPegawai', 'Api\JadwalPegawaiController@index');
    Route::get('jadwalPegawai/{id}', 'Api\JadwalPegawaiController@show');
    Route::post('jadwalPegawai', 'Api\JadwalPegawaiController@store');
    Route::put('jadwalPegawaiTemp', 'Api\JadwalPegawaiController@temp');
    Route::put('jadwalPegawai/{id}', 'Api\JadwalPegawaiController@update');
    Route::delete('jadwalPegawai/{id}', 'Api\JadwalPegawaiController@destroy');

    //Mitra
    Route::get('mitra', 'Api\MitraController@index');
    Route::get('mitraRead', 'Api\MitraController@read');
    Route::get('mitraRemove', 'Api\MitraController@remove');
    Route::get('mitra/{id}', 'Api\MitraController@show');
    Route::post('mitra', 'Api\MitraController@store');
    Route::put('mitraTemp', 'Api\MitraController@temp');
    Route::put('mitra/{id}', 'Api\MitraController@update');
    Route::put('mitraDelete/{id}', 'Api\MitraController@delete');
    Route::put('mitraRecover/{id}', 'Api\MitraController@recover');
    Route::delete('mitra/{id}', 'Api\MitraController@destroy');
    Route::get('mitraCount', 'Api\MitraController@count');

    //Mobil
    Route::get('mobil', 'Api\MobilController@index');
    Route::get('mobilBrosur', 'Api\MobilController@indexForBrosur');
    Route::get('mobilReadM', 'Api\MobilController@readM');
    Route::get('mobilReadP', 'Api\MobilController@readP');
    Route::get('mobilKadaluwarsa', 'Api\MobilController@kadaluwarsa');
    Route::get('mobilRemove', 'Api\MobilController@remove');
    Route::get('mobil/{id}', 'Api\MobilController@show');
    Route::put('mobilTemp', 'Api\MobilController@temp');
    Route::post('mobil', 'Api\MobilController@store');
    Route::put('mobil/{id}', 'Api\MobilController@update');
    Route::delete('mobil/{id}', 'Api\MobilController@destroy');
    Route::put('mobilDelete/{id}', 'Api\MobilController@delete');
    Route::put('mobilRecover/{id}', 'Api\MobilController@recover');
    Route::put('mobilSetBrosur', 'Api\MobilController@setBrosur');
    Route::put('mobilDeleteBrosur/{id}', 'Api\MobilController@deleteBrosur');
    Route::get('mobilCount', 'Api\MobilController@count');
    Route::get('mobilReadMitra', 'Api\MobilController@readAllMitra');
    Route::get('mobilReadMitra/{id}', 'Api\MobilController@readMitra');
    Route::put('mobilImage/{id}', 'Api\MobilController@uploadImage');
    Route::get('mobilKontrakAkanHabis', 'Api\MobilController@kontrakAkanHabis');
    Route::get('mobilAvailable', 'Api\MobilController@available');

    //Pegawai
    Route::get('pegawai', 'Api\PegawaiController@index');
    Route::get('pegawaiRead', 'Api\PegawaiController@read');
    Route::get('pegawaiRemove', 'Api\PegawaiController@remove');
    Route::get('pegawai/{id}', 'Api\PegawaiController@show');
    Route::post('pegawai', 'Api\PegawaiController@store');
    Route::put('pegawaiTemp', 'Api\PegawaiController@temp');
    Route::put('pegawai/{id}', 'Api\PegawaiController@update');
    Route::delete('pegawai/{id}', 'Api\PegawaiController@destroy');
    Route::put('pegawaiDelete/{id}', 'Api\PegawaiController@delete');
    Route::put('pegawaiRecover/{id}', 'Api\PegawaiController@recover');
    Route::put('pegawaiEditPass/{id}', 'Api\PegawaiController@editPassword');
    Route::get('pegawaiCount', 'Api\PegawaiController@count');
    Route::put('pegawaiImage/{id}', 'Api\PegawaiController@uploadImage');
    
    //Promo
    Route::get('promo', 'Api\PromoController@index');
    Route::get('promoRead', 'Api\PromoController@read');
    Route::get('promoAktif', 'Api\PromoController@readAktif');
    Route::get('promoKadaluwarsa', 'Api\PromoController@kadaluwarsa');
    Route::get('promoRemove', 'Api\PromoController@remove');
    Route::get('promo/{id}', 'Api\PromoController@show');
    Route::post('promo', 'Api\PromoController@store');
    Route::put('promo/{id}', 'Api\PromoController@update');
    Route::put('promoDelete/{id}', 'Api\PromoController@delete');
    Route::put('promoRecover/{id}', 'Api\PromoController@recover');
    Route::delete('promo/{id}', 'Api\PromoController@destroy');

    //Role
    Route::get('role', 'Api\RoleController@index');
    Route::get('role/{id}', 'Api\RoleController@show');
    Route::post('role', 'Api\RoleController@store');
    Route::put('role/{id}', 'Api\RoleController@update');
    Route::delete('role/{id}', 'Api\RoleController@destroy');

    //Transaksi
    Route::get('transaksi', 'Api\TransaksiController@index');
    Route::get('transaksiBerlangsung', 'Api\TransaksiController@readBerlangsung');
    Route::get('transaksiSelesai', 'Api\TransaksiController@readSelesai');
    Route::get('transaksi/{id}', 'Api\TransaksiController@show');
    Route::post('transaksi', 'Api\TransaksiController@store');
    // Route::put('transaksi/{id}', 'Api\TransaksiController@update');
    // Route::delete('transaksi/{id}', 'Api\TransaksiController@destroy');
    Route::put('transaksiImage/{id}', 'Api\TransaksiController@uploadImage');
    Route::get('transaksiCount', 'Api\TransaksiController@count');
    Route::put('transaksiVerifTransaksi/{id}', 'Api\TransaksiController@verifTransaksi');
    Route::put('transaksiVerifPembayaran/{id}', 'Api\TransaksiController@verifPembayaran');
    Route::put('transaksiPengembalianMobil/{id}', 'Api\TransaksiController@pengembalianMobil');

Route::group(['middleware' => 'auth:api'], function() {
    
});
